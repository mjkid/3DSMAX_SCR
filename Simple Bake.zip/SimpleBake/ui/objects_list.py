from ..G import *
import bpy
from ..utils import find_closest_obj,show_message_box,find_3d_viewport
from bpy.utils import register_class,unregister_class
from bpy.types import Operator,PropertyGroup,UIList
from bpy.props import EnumProperty,StringProperty
def refresh_bake_objects_list(context):
	sbp=context.scene.SimpleBake_Props
	if sbp.global_mode=="PBR" and sbp.selected_s2a:
		if sbp.s2a_opmode !="automatch":
			if sbp.targetobj !=None:
				if sbp.targetobj.name not in bpy.context.scene.objects:
					sbp.targetobj=None
	if sbp.global_mode=="CyclesBake" and sbp.cycles_s2a:
		if sbp.s2a_opmode !="automatch":
			if sbp.targetobj_cycles !=None:
				if sbp.targetobj_cycles.name not in bpy.context.scene.objects:
					sbp.targetobj_cycles=None
	objects_list=sbp.objects_list
	gone=[]
	for li in objects_list:
		if li.obj_point==None:
			gone.append(li.name)
		elif li.obj_point.name not in context.scene.objects:
			gone.append(li.name)
		elif len(li.obj_point.users_scene) < 1:
			gone.append(li.name)
		elif sbp.selected_s2a or sbp.cycles_s2a:
			if sbp.s2a_opmode=="automatch" and sbp.auto_match_mode=="name":
				for o in sbp.objects_list:
					if o.obj_point !=None and not o.obj_point.name.lower().endswith("_high"):
						gone.append(o.name)
	for g in gone:
		objects_list.remove(objects_list.find(g))
	for i in objects_list:
		i.name=i.obj_point.name
class SIMPLEBAKE_UL_Objects_List(UIList):
	"""烘焙物体列表"""
	viable_high_low_bakes=[]
	def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
		sbp=context.scene.SimpleBake_Props
		custom_icon='OBJECT_DATAMODE'
		name=item.obj_point.name if item.obj_point !=None else "_?_"
		target_obj="???"
		if (sbp.selected_s2a or sbp.cycles_s2a) and item.obj_point !=None:
			if sbp.s2a_opmode=="automatch":
				if sbp.auto_match_mode=="name":
					custom_icon="SEQUENCE_COLOR_01"
					target_obj="???"
					for o in context.scene.objects:
						if name.lower().replace("_high","_low")==o.name.lower():
							target_obj=o.name
							custom_icon="SEQUENCE_COLOR_04"
							if name not in __class__.viable_high_low_bakes:
									__class__.viable_high_low_bakes.append(name)
					if target_obj=="???":
						if name in __class__.viable_high_low_bakes:
							__class__.viable_high_low_bakes.remove(name)
		if (sbp.selected_s2a or sbp.cycles_s2a) and item.obj_point !=None:
			if sbp.s2a_opmode=="automatch":
				if sbp.auto_match_mode=="position":
					co=find_closest_obj(context,name)
					if co !=None:
						custom_icon="SEQUENCE_COLOR_04"
						target_obj=co.name
						if name not in __class__.viable_high_low_bakes:
							__class__.viable_high_low_bakes.append(name)
					else:
						custom_icon="SEQUENCE_COLOR_01"
						target_obj="???"
						if name in __class__.viable_high_low_bakes:
							__class__.viable_high_low_bakes.remove(name)
		if self.layout_type in {'DEFAULT','COMPACT'}:
			col=layout.column()
			col.label(text=g(name),icon=custom_icon)
			if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
				col=layout.column()
				col.alignment='CENTER'
				col.label(text=g(" --> "))
				col=layout.column()
				icon="QUESTION" if target_obj=="???" else "CHECKMARK"
				col.label(text=g(target_obj),icon=icon)
		elif self.layout_type in {'GRID'}:
			layout.alignment='CENTER'
			layout.label(text="",icon=custom_icon)
class SimpleBake_OT_Add_Bake_Object(Operator):
	"""将选定物体添加到烘焙列表"""
	bl_idname="simplebake.add_bake_object";bl_label=g("Adds a bake object to the list")
	@classmethod
	def poll(cls,context):
		return len(context.selected_objects)
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		[obj.select_set(False) for obj in context.scene.objects if obj.type !="MESH"]
		if context.active_object==None:
			context.view_layer.objects.active=context.selected_objects[0]
		objs=context.selected_objects.copy()
		for obj in objs:
			if (sbp.selected_s2a or sbp.cycles_s2a):
				if sbp.s2a_opmode=="automatch" and sbp.auto_match_mode=="name":
					if not obj.name.lower().endswith("_high"):
						messages=([f"ERROR: Can't add object {obj.name}","You  have auto match high and low poly selected and","you are using name mode.","Only object names ending in \"_high\" can be added"])
						show_message_box(context,messages,"Errors occured",icon='ERROR')
						continue
			r=[o.name for o in sbp.objects_list if o.name==obj.name]
			if len(r)==0:
				n=sbp.objects_list.add()    
				n.obj_point=obj
				n.name=obj.name
		refresh_bake_objects_list(context)
		if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
			if len(SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes)<2:
				sbp.merged_bake=False
		return{'FINISHED'}
class SimpleBake_OT_Add_Bake_Object_By_Name(Operator):
	"""将指定物体添加到烘焙列表"""
	bl_idname="simplebake.add_bake_object_by_name";bl_label=g("Adds a bake object to the list")
	override_target_obj_name: StringProperty(default="")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		n=sbp.objects_list.add()
		obj=context.scene.objects[self.override_target_obj_name]
		n.obj_point=obj
		n.name=obj.name
		return{'FINISHED'}
class SimpleBake_OT_Remove_Bake_Object(Operator):
	"""从烘焙列表中删除选定物体"""
	bl_idname="simplebake.remove_bake_object";bl_label=g("Removes a bake object from the list")
	@classmethod
	def poll(cls,context):
		return context.scene.SimpleBake_Props.objects_list
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		objects_list=sbp.objects_list
		index=sbp.objects_list_index
		name=sbp.objects_list[index].name
		objects_list.remove(index)
		sbp.objects_list_index=min(max(0,index - 1),len(objects_list) - 1)
		refresh_bake_objects_list(context)
		if name in SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes:
			SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes.remove(name)
		if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
			if len(SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes)<2:
				sbp.merged_bake=False
		return{'FINISHED'}
class SimpleBake_OT_Clear_Bake_Objects_List(Operator):
	"""清除物体列表"""
	bl_idname="simplebake.clear_bake_objects_list";bl_label=g("Clears the bake object list")
	@classmethod
	def poll(cls,context):
		return True
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		sbp.objects_list.clear()
		refresh_bake_objects_list(context)
		SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes=[]
		return{'FINISHED'}
class SimpleBake_OT_Move_Bake_Object_List(Operator):
	"""移动列表中的物体"""
	bl_idname="simplebake.move_bake_object_list";bl_label=g("Moves an item in the bake objects list")
	direction: bpy.props.EnumProperty(items=(('UP',g('Up'),""),('DOWN',g('Down'),""),))
	@classmethod
	def poll(cls,context):
		return context.scene.SimpleBake_Props.objects_list
	def move_index(self,context):
		sbp=context.scene.SimpleBake_Props
		index=sbp.objects_list_index
		list_length=len(sbp.objects_list) - 1
		new_index=index + (-1 if self.direction=='UP' else 1)
		sbp.objects_list_index=max(0,min(new_index,list_length))
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		objects_list=sbp.objects_list
		index=sbp.objects_list_index
		neighbor=index + (-1 if self.direction=='UP' else 1)
		objects_list.move(neighbor,index)
		self.move_index(context)
		refresh_bake_objects_list(context)
		return{'FINISHED'}
class SimpleBake_OT_Refresh_Bake_Object_List(Operator):
	"""刷新列表以删除物体"""
	bl_idname="simplebake.refresh_bake_object_list";bl_label=g("Refresh the bake objects list")
	@classmethod
	def poll(cls,context):
		return True
	def execute(self,context):
		refresh_bake_objects_list(context)
		return{'FINISHED'}
class SimpleBake_OT_Highlight_Bake_Objects(Operator):
	"""在视口中高亮显示选定物体"""
	bl_idname="simplebake.highlight_bake_objects";bl_label=g("Highlights bake objects in the viewport on this screen")
	@classmethod
	def update_object_list_from_selectd(cls):
		sbp=bpy.context.scene.SimpleBake_Props
		if (o:=bpy.context.active_object):
			if (i:=sbp.objects_list.find(o.name))!=-1:
				if sbp.objects_list_index !=i:
					sbp.objects_list_index=i
	@classmethod
	def poll(cls,context):
		sbp=context.scene.SimpleBake_Props
		return not sbp.highlight_on
	@classmethod
	def set_timer(cls):
		bpy.app.timers.register(cls.col_bake_objects,first_interval=1.0)
	@classmethod
	def col_bake_objects(cls):
		sbp=bpy.context.scene.SimpleBake_Props
		cls.update_object_list_from_selectd()
		if not sbp.highlight_on:
			return None
		any_shading=False
		for space in find_3d_viewport():
			if space.shading.type=="SOLID":
				any_shading=True
		if not any_shading:
			return 0.2
		sbp=bpy.context.scene.SimpleBake_Props
		def set_col(obj_names,col):
			for o_name in obj_names:
				if (o:=bpy.data.objects.get(o_name)):
					if o.color !=col:
						if "SB_orig_col" not in o:
							o["SB_orig_col"]=o.color
						o.color=col
		bake_objs=[o.name for o in sbp.objects_list]
		all_objs=([o.name for o in bpy.context.scene.objects if
					 o.name not in bake_objs and
					 o.type=="MESH" and
					 "SB_auto_cage" not in o])
		set_col(all_objs,(1,1,1,1))
		c=sbp.highlight_col
		set_col(bake_objs,(c.r,c.g,c.b,1.0))
		if not sbp.highlight_on:
			return None
		else:
			return 0.2
	@classmethod
	def set_display(cls,context):
		for space in find_3d_viewport():
			space.shading.color_type="OBJECT"
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		sbp.highlight_on=True
		__class__.set_timer()
		__class__.col_bake_objects()
		__class__.set_display(context)
		return{'FINISHED'}
class SimpleBake_OT_Remove_Highlight(Operator):
	"""删除视口中选定物体的高亮显示"""
	bl_idname="simplebake.remove_highlight";bl_label=g("Removes the highlights for bake objects in the viewport on this screen")
	@classmethod
	def poll(cls,context):
		sbp=context.scene.SimpleBake_Props
		return sbp.highlight_on
	def uncol_bake_objects(self,context):
		sbp=context.scene.SimpleBake_Props
		bpy.ops.simplebake.refresh_bake_object_list()
		obj_names=[o.name for o in sbp.objects_list]
		for o_name in obj_names:
			if (o:=bpy.data.objects.get(o_name)):
				if "SB_orig_col" in o:
					o.color=o["SB_orig_col"]
					del o["SB_orig_col"]
	def unset_display(self,context):
		screen=bpy.context.window.screen
		for area in screen.areas:
			if area.type=='VIEW_3D':
				for space in area.spaces:
					if space.type=='VIEW_3D':
						space.shading.color_type="MATERIAL"
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		self.uncol_bake_objects(context)
		self.unset_display(context)
		sbp.highlight_on=False
		return{'FINISHED'}
classes=([SIMPLEBAKE_UL_Objects_List,SimpleBake_OT_Add_Bake_Object,SimpleBake_OT_Add_Bake_Object_By_Name,SimpleBake_OT_Remove_Bake_Object,SimpleBake_OT_Clear_Bake_Objects_List,SimpleBake_OT_Move_Bake_Object_List,SimpleBake_OT_Refresh_Bake_Object_List,SimpleBake_OT_Highlight_Bake_Objects,SimpleBake_OT_Remove_Highlight])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
