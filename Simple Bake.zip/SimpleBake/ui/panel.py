from ..G import *
import bpy,os
from pathlib import Path
from bpy.utils import register_class,unregister_class
from bpy.types import Panel,Operator
from ..utils import SBConstants,pbr_selections_to_list,specials_selection_to_list,is_blend_saved,get_udim_tiles,conflicting_addons
from .objects_list import SIMPLEBAKE_UL_Objects_List
from .channel_packing_list import SIMPLEBAKE_UL_CPTexList
from ..background_and_progress import BackgroundBakeTasks,BakeInProgress
try:
	from ..auto_update import VersionControl
except:
	VersionControl=None
from ..bake_operators.pbr_bake_support_operators import has_convertible_shaders
from ..messages import print_message
from .. import __package__ as base_package
space=""
region=""
context=""
cat=""
TOGGLES=True
ALIGN=False
SCALE=1.3
def read_settings():
	global space,region,context,cat,TOGGLES,ALIGN,SCALE
	p=Path(bpy.utils.script_path_user())
	p=p.parents[1]
	p=p / "data" / "SimpleBake" / "settings"
	filename="panel_location.txt"
	content=""
	try:
		with open(str(p / filename),'r') as file:
			content=file.read()
	except Exception as e:
		content="renderpanel"
	if content=="renderpanel":
		space='PROPERTIES'
		region='WINDOW'
		context="render"
		cat=""
	else:
		space='VIEW_3D'
		region='UI'
		context=""
		cat='SimpleBake'
	filename="toggles.txt"
	try:
		with open(str(p / filename),'r') as file:
			content=file.read()
	except Exception as e:
		content="toggles"
	TOGGLES=True if content=="toggles" else False
read_settings()
def monkey_tip_formatter(text,max_length=32):
	words=g(text).split()
	segments=[]
	current_segment=""
	for word in words:
		if len(current_segment) + len(word) + 1 > max_length:
			segments.append(current_segment)
			current_segment=word
		else:
			if current_segment:
				current_segment +=" "
			current_segment +=word
	if current_segment:
		segments.append(current_segment)
	return segments
def monkey_tip(context,message_lines,box):
	sbp=context.scene.SimpleBake_Props
	row=box.row(align=ALIGN)
	row.alert=True
	row.prop(sbp,"showtips",text="",icon="TRIA_DOWN" if sbp.showtips else "TRIA_RIGHT",icon_only=True,emboss=False)
	row.label(text=g(f'{"Tip" if sbp.showtips else "Tip available"}'),icon="MONKEY")
	row.alignment='CENTER'
	if sbp.showtips:
		for line in message_lines:
			row=box.row(align=ALIGN)
			row.alignment='CENTER'
			row.scale_y=0.5
			row.label(text=line)
def decals_tips(context,box):
	sbp=context.scene.SimpleBake_Props
	message_lines=["PBR DECALS MODE"]
	message_lines.extend(monkey_tip_formatter("Add the decal objects to the list,and specify your  target object in the Target Object box. If using the 'Copy objects  and apply bakes' option,a suitable decals material will be created"))
	monkey_tip(context,message_lines,box)
	row=box.row(align=ALIGN)
	row.label(text="")
def standard_s2a_tips(context,box):
	sbp=context.scene.SimpleBake_Props
	message_lines=["STANDARD BAKE TO TARGET MODE"]
	message_lines.extend(monkey_tip_formatter("Add source objects to the list and specify  the target object in the target box"))
	monkey_tip(context,message_lines,box)
def auto_match_high_low_tips(context,box):
	sbp=context.scene.SimpleBake_Props
	if sbp.auto_match_mode=="name":
		message_lines=["AUTO MATCH HIGH/LOW"]
		message_lines.append("NAME MODE")
		message_lines.extend(monkey_tip_formatter("Only objects with \"_high\" as a suffix to their name can be added to the  list. Each object's icon indicates if a corresponding \"_low\" object for  baking can be found in the scene. Cage objects are also auto detected with  the suffix \"_cage\""))
		monkey_tip(context,message_lines,box)
	if sbp.auto_match_mode=="position":
		message_lines=["AUTO MATCH HIGH/LOW"]
		message_lines.append("POSITION MODE")
		message_lines.extend(monkey_tip_formatter("Add your high poly objects to the  list Low poly detected by position (<0.5  BU) Each object's icon indicates if  a corresponding low poly object for  baking can be found in the  scene 	"))
		monkey_tip(context,message_lines,box)
	row=box.row(align=ALIGN)
	row.label(text="")
def denoise_options(box):
	C=bpy.context
	sbp=C.scene.SimpleBake_Props
	row=box.row(align=ALIGN)
	row.scale_y=SCALE
	row.prop(sbp,"rundenoise",text=g("Denoise (Compositor)"),toggle=TOGGLES)
	if not sbp.save_bakes_external:
		row.enabled=False
	row=box.row(align=ALIGN)
	row.scale_y=SCALE
	row.prop(C.scene.cycles,"use_denoising",text=g("Denoise (Cycles)"),toggle=TOGGLES)
	if C.scene.cycles.use_denoising:
		row=box.row(align=ALIGN)
		row.prop(C.scene.cycles,"denoiser",text=g("denoiser"))
		row=box.row(align=ALIGN)
		row.prop(C.scene.cycles,"denoising_input_passes",text=g("denoising_input_passes"))
		row=box.row(align=ALIGN)
		row.prop(C.scene.cycles,"denoising_prefilter",text=g("denoising_prefilter"))
def check_for_render_inactive_modifiers(context):
	sbp=context.scene.SimpleBake_Props
	objects=[i.obj_point for i in sbp.objects_list if i.obj_point !=None]
	for obj in objects:
		for mod in obj.modifiers:
			if mod.show_render and not mod.show_viewport:
				return True
	if sbp.selected_s2a and sbp.targetobj !=None:
		for mod in sbp.targetobj.modifiers:
			if mod.show_render and not mod.show_viewport:
				return True
	if sbp.cycles_s2a and sbp.targetobj_cycles !=None:
		for mod in sbp.targetobj_cycles.modifiers:
			if mod.show_render and not mod.show_viewport:
				return True
	return False
def check_for_viewport_inactive_modifiers(context):
	sbp=context.scene.SimpleBake_Props
	objects=[i.obj_point for i in sbp.objects_list if i.obj_point !=None]
	for obj in objects:
		for mod in obj.modifiers:
			if mod.show_viewport and not mod.show_render:
				return True
	if sbp.selected_s2a and sbp.targetobj !=None:
		for mod in sbp.targetobj.modifiers:
			if mod.show_viewport and not mod.show_render:
				return True
	if sbp.cycles_s2a and sbp.targetobj_cycles !=None:
		for mod in sbp.targetobj_cycles.modifiers:
			if mod.show_viewport and not mod.show_render:
				return True
	return False
def disable_row_if_udims(context,row,box):
	sbp=context.scene.SimpleBake_Props
	if bpy.context.mode !='OBJECT':
		return False
	objects_list=[]
	if sbp.selected_s2a:
		if (o:=sbp.targetobj):
			objects_list=[sbp.targetobj.name]
	elif sbp.cycles_s2a:
		if (o:=sbp.targetobj_cycles):
			objects_list=[sbp.targetobj_cycles.name]
	else:
		objects_list=[i.name for i in sbp.objects_list]
	for obj_name in objects_list:
		result=get_udim_tiles(context,obj_name,threshold=0.001)
		if result["total_tiles"]>1:
			row.enabled=False
			row=box.row(align=ALIGN)
			row.alert=True
			row.alignment='CENTER'
			row.scale_y=0.5
			GL(row,"Bake objects have UDIMs!",)
			row=box.row(align=ALIGN)
			row.alert=True
			row.alignment='CENTER'
			row.scale_y=0.5
			GL(row,"Can only bake in background if",)
			row=box.row(align=ALIGN)
			row.alert=True
			row.alignment='CENTER'
			row.scale_y=0.5
			row.label(text=g("\"Export Bakes\" also turned on"))
def disable_row_if_image_sequence(context,row,box):
	sbp=context.scene.SimpleBake_Props
	if sbp.bake_sequence:
		row.enabled=False
		row=box.row(align=ALIGN)
		row.alert=True
		row.alignment='CENTER'
		row.scale_y=0.5
		GL(row,"Image sequence selected",)
		row=box.row(align=ALIGN)
		row.alert=True
		row.alignment='CENTER'
		row.scale_y=0.5
		GL(row,"Unfortunately,this can only be",)
		row=box.row(align=ALIGN)
		row.alert=True
		row.alignment='CENTER'
		row.scale_y=0.5
		GL(row,"baked in the foreground",)
def check_for_convertible_shaders(context):
	sbp=context.scene.SimpleBake_Props
	bake_objects=[i.obj_point.name for i in sbp.objects_list]
	if sbp.selected_s2a and sbp.s2a_opmode=="decals" and sbp.targetobj !=None:
		bake_objects.append(sbp.targetobj.name)
	mats=[]
	for obj_name in bake_objects:
		if not (o:=context.scene.objects.get(obj_name)):
			continue
		for slot in o.material_slots:
			if slot.material !=None:
				mats.append(slot.material.name)
	result=False
	mats=set(list(mats))
	for m_name in mats:
		if has_convertible_shaders(m_name):
			result=True
	return result
class SIMPLEBAKE_PT_main_panel(Panel):
	bl_label=BT;bl_space_type=f"{space}";bl_region_type=f"{region}";bl_context=f"{context}";bl_category=f"{cat}"
	bl_options={"DEFAULT_CLOSED"}
	def draw_header_preset(S,_):S.layout.operator("preferences.addon_show",icon='SETTINGS',emboss=1,depress=1,text="").module=__package__.split('.')[0]
	def draw_header(S,_):S.layout.operator("wm.url_open",icon_value=I("A"),text="").url=BL+SP

	def draw_global_mode_buttons(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.scale_y=1.5 
		row.prop_enum(sbp,"global_mode",SBConstants.PBR,text=g("PBR Bake"))
		row.prop_enum(sbp,"global_mode",SBConstants.CYCLESBAKE,text=g("Cycles Bake"))

		row=box.row(align=ALIGN)
		row.operator("simplebake.panel_hide_all",icon='PROP_OFF',text=g("Hide all"))
		row.operator("simplebake.panel_show_all",icon='PROP_ON',text=g("Show all"))
	def draw_presets(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"presets_show",text=g("Settings presets"),icon="PROP_ON" if sbp.presets_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.presets_show:
			row=box.row(align=ALIGN)
			row.alignment="CENTER"
			row.label(text=g("Global Presets"),icon="WORLD_DATA")
			row=box.row(align=ALIGN)
			col=row.column()
			col.template_list("SIMPLEBAKE_UL_Presets_List","Presets List",sbp,"presets_list",sbp,"presets_list_index")
			col=row.column()
			col.operator("simplebake.preset_refresh",text="",icon="FILE_REFRESH")
			col.operator("simplebake.preset_load",text="",icon="CHECKMARK")
			col.operator("simplebake.preset_delete",text="",icon="CANCEL")
			row=box.row(align=ALIGN)
			row.prop(sbp,"preset_name",text=g("Name: "))
			row.operator("simplebake.preset_save",text="",icon="FUND")
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"preset_load_clear_obj",toggle=TOGGLES,text=g("Replace bake objects list with preset"))
			row=box.row(align=ALIGN)
			row.label(text="")
			row=box.row(align=ALIGN)
			row.alignment="CENTER"
			row.label(text=g("Blend File Presets"),icon="FILE_BLEND")
			row=box.row(align=ALIGN)
			col=row.column()
			col.template_list("SIMPLEBAKE_UL_Local_Presets_List","Local Presets List",sbp,"local_presets_list",sbp,"local_presets_list_index")
			col=row.column()
			col.operator("simplebake.local_preset_refresh",text="",icon="FILE_REFRESH")
			col.operator("simplebake.local_preset_load",text="",icon="CHECKMARK")
			col.operator("simplebake.local_preset_delete",text="",icon="CANCEL")
			row=box.row(align=ALIGN)
			row.prop(sbp,"local_preset_name",text=g("Name: "))
			row.operator("simplebake.local_preset_save",text="",icon="FUND")
	def draw_objects_list(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"bake_objects_show",text=g("Bake objects"),icon="PROP_ON" 
				 if sbp.bake_objects_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.bake_objects_show:
			row=box.row(align=ALIGN)
			col=row.column()
			col.template_list("SIMPLEBAKE_UL_Objects_List","Bake Objects List",sbp,"objects_list",sbp,"objects_list_index")
			col=row.column()
			col.scale_x=0.32
			col.operator("simplebake.highlight_bake_objects",text="",icon="LIGHT_SPOT")
			col.operator("simplebake.remove_highlight",text="",icon="SHADING_BBOX")
			col.prop(sbp,"highlight_col",text="")
			row=box.row(align=ALIGN)
			row.operator('simplebake.add_bake_object',text=g('Add'),icon="PRESET_NEW")
			row.operator('simplebake.remove_bake_object',text=g('Remove'),icon="CANCEL")
			row.operator('simplebake.clear_bake_objects_list',text=g('Clear'),icon="MATPLANE")
			row=box.row(align=ALIGN)
			row.operator('simplebake.move_bake_object_list',text=g('Up'),icon="TRIA_UP").direction="UP"
			row.operator('simplebake.move_bake_object_list',text=g('Down'),icon="TRIA_DOWN").direction="DOWN"
			row.operator('simplebake.refresh_bake_object_list',text=g('Refresh'),icon="FILE_REFRESH")
			if sbp.highlight_on:
				message_lines=monkey_tip_formatter("Objects are highlighted when viewport set to \"Solid\" shading. Must be re-enabled after Blender restart")
				monkey_tip(context,message_lines,box)
			if sbp.global_mode==SBConstants.PBR:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"selected_s2a",toggle=TOGGLES,text=g("Bake to target"))
				col=row.column()
				col.prop(sbp,"isolate_objects",toggle=TOGGLES,text=g("Isolate objects"))
				if(sbp.selected_s2a):
					row=box.row(align=ALIGN)
					row.alignment="RIGHT"
					row.prop(sbp,"s2a_opmode",text=g("Bake to target mode"))
					if sbp.s2a_opmode in ["single","decals"]:
						row=box.row(align=ALIGN)
						split=row.split(factor=0.25)
						split.alignment="LEFT"
						split.label(text=g("Target"))
						split.prop(sbp,"targetobj",text="")
						row=box.row(align=ALIGN)
						split=row.split(factor=0.25)
						split.alignment="LEFT"
						split.label(text=g("Cage (optional)"))
						split.prop(context.scene.render.bake,"cage_object",text="")
						if sbp.targetobj !=None:
							t=[o.name for o in context.scene.objects if "SB_auto_cage" in o and o["SB_auto_cage"]==sbp.targetobj.name]
							if len(t)>0: row.enabled=False
						row=box.row(align=ALIGN)
						row.scale_y=SCALE
						row.operator("simplebake.auto_cage",icon='ADD',text=g("Auto-generate cage"))
						row.operator("simplebake.remove_auto_cage",icon='REMOVE',text=g("Remove auto-generated cage"))
						if context.scene.render.bake.cage_object !=None:
							if 'SB_AUTO_CAGE' in context.scene.render.bake.cage_object.modifiers:
								row=box.row(align=ALIGN)
								row.scale_y=SCALE
								row.prop(sbp,"auto_cage_extrusion",text=g("Auto generated cage extrusion"))
						if sbp.s2a_opmode=="decals":
							decals_tips(context,box)
						if sbp.s2a_opmode=="single":
							standard_s2a_tips(context,box)
					if sbp.s2a_opmode=="automatch":
						row=box.row(align=ALIGN)
						row.alignment="RIGHT"
						row.prop(sbp,"auto_match_mode",text=g("Auto match mode"))
						auto_match_high_low_tips(context,box)
					row=box.row(align=ALIGN)
					row.alignment="RIGHT"
					row.prop(sbp,"cage_smooth_hard",text=g("Auto extruded cage type"))
					if context.scene.render.bake.cage_object !=None:
						row.enabled=False
					row=box.row(align=ALIGN)
					row.use_property_split=True
					row.prop(sbp,"cage_extrusion",text=g("Cage Extrusion"))
					if context.scene.render.bake.cage_object !=None:
						row.enabled=False
					row=box.row(align=ALIGN)
					row.use_property_split=True
					row.prop(sbp,"ray_distance",text=g("Ray Distance"))
					row=box.row(align=ALIGN)
					row.use_property_split=True
					row.prop(sbp,"cage_and_ray_multiplier",text=g("Multiplier"))
			if sbp.global_mode==SBConstants.CYCLESBAKE:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"cycles_s2a",text=g("Bake to target"),toggle=TOGGLES)
				col=row.column()
				col.prop(sbp,"isolate_objects",toggle=TOGGLES,text=g("Isolate objects"))
				if sbp.cycles_s2a:
					row=box.row(align=ALIGN)
					row.alignment="RIGHT"
					row.prop(sbp,"s2a_opmode",text=g("Bake to target mode"))
					if sbp.s2a_opmode in ["single"]:
						row=box.row(align=ALIGN)
						split=row.split(factor=0.25)
						split.alignment="LEFT"
						split.label(text=g("Target"))
						split.prop(sbp,"targetobj_cycles",text="")
						row=box.row(align=ALIGN)
						split=row.split(factor=0.25)
						split.alignment="LEFT"
						split.label(text=g("Cage (optional)"))
						split.prop(context.scene.render.bake,"cage_object",text="")
						if sbp.targetobj_cycles !=None:
							t=[o.name for o in context.scene.objects if "SB_auto_cage" in o and o["SB_auto_cage"]==sbp.targetobj_cycles.name]
							if len(t)>0: row.enabled=False
						row=box.row(align=ALIGN)
						row.scale_y=SCALE
						row.operator("simplebake.auto_cage",icon='ADD',text=g("Auto-generate cage"))
						row.operator("simplebake.remove_auto_cage",icon='REMOVE',text=g("Remove auto-generated cage"))
						if context.scene.render.bake.cage_object !=None:
							if 'SB_AUTO_CAGE' in context.scene.render.bake.cage_object.modifiers:
								row=box.row(align=ALIGN)
								row.scale_y=SCALE
								row.prop(sbp,"auto_cage_extrusion",text=g("Auto generated cage extrusion"))
						standard_s2a_tips(context,box)
					if sbp.s2a_opmode in ["automatch"]:
						row=box.row(align=ALIGN)
						row.alignment="RIGHT"
						row.prop(sbp,"auto_match_mode",text=g("Auto match mode"))
						auto_match_high_low_tips(context,box)
					row=box.row(align=ALIGN)
					row.alignment="RIGHT"
					row.prop(sbp,"cage_smooth_hard",text=g("Auto extruded cage type"))
					if context.scene.render.bake.cage_object !=None:
						row.enabled=False
					row=box.row(align=ALIGN)
					row.use_property_split=True
					row.prop(sbp,"cage_extrusion",text=g("Cage Extrusion"))
					if context.scene.render.bake.cage_object !=None:
						row.enabled=False
					row=box.row(align=ALIGN)
					row.use_property_split=True
					row.prop(sbp,"ray_distance",text=g("Ray Distance"))
					row=box.row(align=ALIGN)
					row.use_property_split=True
					row.prop(sbp,"cage_and_ray_multiplier",text=g("Multiplier"))
			if check_for_render_inactive_modifiers(context):
				message_lines=["One or more selected objects","has a modifier enabled for","render (and so baking),but disabled in","viewport. May cause unexpected results"]
				monkey_tip(context,message_lines,box)
			if check_for_viewport_inactive_modifiers(context):
				message_lines=["One or more selected objects","has a modifier enabled in the","viewport,but disabled for","render (and so baking).","May cause unexpected results"]
				monkey_tip(context,message_lines,box)
	def draw_pbr_settings(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"pbr_settings_show",text=g("PBR Bakes"),icon="PROP_ON"
				 if sbp.pbr_settings_show else "PROP_OFF",icon_only=True,emboss=False)
		if sbp.pbr_settings_show:
			row=box.row(align=ALIGN)
			col=row.column()
			col.prop(sbp,"selected_col",toggle=TOGGLES,text=g("selected_col"))
			col=row.column()
			col.prop(sbp,"selected_metal",toggle=TOGGLES,text=g("selected_metal"))
			row.scale_y=SCALE
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"selected_rough",toggle=TOGGLES,text=g("Roughness/Glossy"))
			row.prop(sbp,"selected_normal",toggle=TOGGLES,text=g("selected_normal"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"selected_trans",toggle=TOGGLES,text=g("selected_trans"))
			col=row.column()
			col.prop(sbp,"selected_transrough",toggle=TOGGLES,text=g("Transmission Roughness"))
			if bpy.app.version >=(4,0,0):col.enabled=False
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"selected_clearcoat",toggle=TOGGLES,text=g("selected_clearcoat"))
			row.prop(sbp,"selected_clearcoat_rough",toggle=TOGGLES,text=g("selected_clearcoat_rough"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"selected_emission",toggle=TOGGLES,text=g("selected_emission"))
			row.prop(sbp,"selected_emission_strength",toggle=TOGGLES,text=g("selected_emission_strength"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"selected_specular",toggle=TOGGLES,text=g("selected_specular"))
			col=row.column()
			col.prop(sbp,"selected_alpha",toggle=TOGGLES,text=g("selected_alpha"))
			if sbp.selected_s2a==True and sbp.s2a_opmode=="decals":
				col.enabled=False
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"selected_sss",toggle=TOGGLES,text=g("selected_sss"))
			col=row.column()
			col.prop(sbp,"selected_bump",toggle=TOGGLES,text=g("selected_bump"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"selected_displacement",toggle=TOGGLES,text=g("selected_displacement"))
			col=row.column()
			col.label(text="")
			row=box.row(align=ALIGN)
			row.label(text="")
			row.scale_y=0.2
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.operator("simplebake.selectall_pbr",icon='ADD',text=g("Select All"))
			row.operator("simplebake.selectnone_pbr",icon='REMOVE',text=g("Select None"))
			row.operator("simplebake.autodetect_pbr_channels",icon='LIGHT',text=g("Attempt to auto-detect"))
			if sbp.selected_col or sbp.selected_rough or sbp.selected_normal:
				row=box.row(align=ALIGN)
				row.scale_y=0.5
				row.label(text=g("Extra Options:"))
			t=False
			if sbp.selected_col and sbp.s2a_opmode !="decals":
				t=True
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"multiply_diffuse_ao",text=g("Diffuse option"))
				col.enabled=True if sbp.save_bakes_external else False
				if sbp.multiply_diffuse_ao=="diffusexao":
					col=row.column()
					col.prop(sbp,"multiply_diffuse_ao_percent",text=g("AO Mix %"))
			if sbp.selected_rough:
				t=True
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"rough_glossy_switch",text=g("Rough/Glossy"))
				row.enabled=True if sbp.save_bakes_external else False
			if sbp.selected_normal:
				t=True
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"normal_format_switch",text=g("Normal format"))
				row.enabled=True if sbp.save_bakes_external else False
			if not sbp.save_bakes_external and t:
				message_lines=monkey_tip_formatter("Extra options above are not available because you are not exporting your bakes. Enable the Export Bakes  option below to access the extra options")
				monkey_tip(context,message_lines,box)
			if check_for_convertible_shaders(context):
				message_lines=monkey_tip_formatter("WARNING: Some materials on your bake objects use non-PBR shader nodes (e.g.,Diffuse,Glossy). SimpleBake will TRY to match them for PBR,but results may vary. It's recommended to use the 'Attempt to auto-detect' button,as you may not expect the PBR maps needed after conversion. You will always get the best results from reworking your materials to be based around the Principled BSDF")
				monkey_tip(context,message_lines,box)
	def draw_cyclesbake_settings(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"cyclesbake_settings_show",text=g("CyclesBake"),icon="PROP_ON" if sbp.cyclesbake_settings_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.cyclesbake_settings_show:
			cscene=context.scene.cycles
			cbk=context.scene.render.bake
			row=box.row(align=ALIGN)
			row.prop(cscene,"bake_type",text=g("bake_type"))
			if cscene.bake_type=='NORMAL':
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(cbk,"normal_space",text=g("Space"))
				sub=col.column()
				sub.prop(cbk,"normal_r",text=g("Swizzle R"))
				sub.prop(cbk,"normal_g",text=g("Swizzle G"))
				sub.prop(cbk,"normal_b",text=g("Swizzle B"))
			elif cscene.bake_type=='COMBINED':
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(cbk,"use_pass_direct",toggle=TOGGLES,text=g("use_pass_direct"))
				col=row.column()
				col.prop(cbk,"use_pass_indirect",toggle=TOGGLES,text=g("use_pass_indirect"))
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.active=cbk.use_pass_direct or cbk.use_pass_indirect
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(cbk,"use_pass_diffuse",toggle=TOGGLES,text=g("use_pass_diffuse"))
				col=row.column()
				col.prop(cbk,"use_pass_glossy",toggle=TOGGLES,text=g("use_pass_glossy"))
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(cbk,"use_pass_transmission",toggle=TOGGLES,text=g("use_pass_transmission"))
				col=row.column()
				col.prop(cbk,"use_pass_emit",toggle=TOGGLES,text=g("use_pass_emit"))
			elif cscene.bake_type in {'DIFFUSE','GLOSSY','TRANSMISSION'}:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(cbk,"use_pass_direct",toggle=TOGGLES,text=g("use_pass_direct"))
				col=row.column()
				col.prop(cbk,"use_pass_indirect",toggle=TOGGLES,text=g("use_pass_indirect"))
				col=row.column()
				col.prop(cbk,"use_pass_color",toggle=TOGGLES,text=g("use_pass_color"))
			row=box.row(align=ALIGN)
			col=row.column()
			col.prop(context.scene.cycles,"samples",text=g("samples"))
			if (sbp.global_mode==SBConstants.CYCLESBAKE and 
					context.scene.cycles.bake_type !="NORMAL"):
				row=box.row(align=ALIGN)
				row.prop(sbp,"cyclesbake_cs",text=g("Colour Space"))
			denoise_options(box)
	def draw_specials_settings(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"specials_show",text=g("Special bakes"),icon="PROP_ON" if sbp.specials_show else "PROP_OFF",icon_only=False,emboss=False)
		need_denoise_options=False
		if sbp.specials_show:
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"selected_col_mats",toggle=TOGGLES,text=g("selected_col_mats"))
			if sbp.selected_s2a or sbp.cycles_s2a:
				col.enabled=False
			col=row.column()
			col.prop(sbp,"selected_col_vertex",toggle=TOGGLES,text=g("selected_col_vertex"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"selected_curvature",toggle=TOGGLES,text=g("selected_curvature"))
			col=row.column()
			col.prop(sbp,"selected_thickness",toggle=TOGGLES,text=g("selected_thickness"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"selected_ao",toggle=TOGGLES,text=g("selected_ao"))
			if sbp.global_mode==SBConstants.PBR and sbp.multiply_diffuse_ao=="diffusexao":
				col.enabled=False
			col=row.column()
			col.prop(sbp,"selected_lightmap",toggle=TOGGLES,text=g("selected_lightmap"))
			if sbp.selected_s2a or sbp.cycles_s2a:
				col.enabled=False
			if sbp.selected_ao or sbp.selected_thickness or sbp.selected_lightmap:
				row=box.row(align=ALIGN)
				row.scale_y=0.5
				row.label(text=g("Extra options:"))
			if sbp.selected_ao or sbp.selected_thickness:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"ao_sample_count",text=g("AO Sample Count"))
				if sbp.global_mode==SBConstants.PBR:
					need_denoise_options=True
			if sbp.selected_lightmap and sbp.global_mode==SBConstants.PBR:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(context.scene.cycles,"samples",text=g("Lightmap Sample Count"))
				need_denoise_options=True
			if sbp.selected_lightmap:    
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"lightmap_apply_colman",text=g("Lightmap apply colour management"))
				if not sbp.save_bakes_external: row.enabled=False
			if need_denoise_options:
				row=box.row(align=ALIGN)
				denoise_options(box)
			if (sbp.selected_lightmap or sbp.selected_ao or sbp.selected_thickness) and sbp.global_mode==SBConstants.PBR:
				message_lines=monkey_tip_formatter(f"Sample count and denoise are not  normally relevant for PBR Bake,but they are for  {SBConstants.LIGHTMAP},{SBConstants.AO} and {SBConstants.THICKNESS}")
				monkey_tip(context,message_lines,box)
			if sbp.selected_lightmap and sbp.global_mode==SBConstants.CYCLESBAKE:
				message_lines=monkey_tip_formatter("Lightmap will have sample  count and denoise settings that you have set for CyclesBake above")
				monkey_tip(context,message_lines,box)
			if (sbp.selected_ao or sbp.selected_thickness) and sbp.global_mode==SBConstants.CYCLESBAKE:
				message_lines=["AO and thickness will have","denoise settings that","you have set for CyclesBake above"]
				monkey_tip(context,message_lines,box)
			if sbp.selected_s2a or sbp.cycles_s2a:
				message_lines=["Lightmap is unavailable when","baking to target object for now"]
				monkey_tip(context,message_lines,box)
			if sbp.selected_thickness or sbp.selected_curvature or sbp.selected_lightmap or sbp.selected_ao:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.operator("simplebake.import_special_mats",icon='MATERIAL',text=g("Import specials materials for editing"))
	def draw_texture_settings(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"textures_show",text=g("Texture settings"),icon="PROP_ON"
				 if sbp.textures_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.textures_show:
			if False:
				pass
			else:
				row=box.row(align=ALIGN)
				row.label(text=g("Bake at:"))
				row.scale_y=0.5
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"imgwidth",text=g("Bake width"))
				row.prop(sbp,"imgheight",text=g("Bake height"))
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.operator("simplebake.decrease_texture_res",icon="TRIA_DOWN",text="-1k")
				row.operator("simplebake.increase_texture_res",icon="TRIA_UP",text="+1k")
				row=box.row(align=ALIGN)
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.label(text=g("Output at:"))
				row.scale_y=0.5
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"outputwidth",text=g("Output Width"))
				row.prop(sbp,"outputheight",text=g("Output Height"))
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.operator("simplebake.decrease_output_res",icon="TRIA_DOWN",text="-1k")
				row.operator("simplebake.increase_output_res",icon="TRIA_UP",text="+1k")
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.alignment="RIGHT"
				row.prop(context.scene.render.bake,"margin",text=g("Bake Margin"))
				try:
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					row.alignment="RIGHT"
					row.prop(context.scene.render.bake,"margin_type",text=g("Margin Type"))
				except:
					pass
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"everything32bitfloat",toggle=TOGGLES,text=g("All internal 32bit float"))
				col=row.column()
				col.prop(sbp,"use_alpha",toggle=TOGGLES,text=g("Transparent background"))
				if sbp.export_file_format=="JPEG" or not sbp.clear_image:
					col.enabled=False
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"merged_bake",toggle=TOGGLES,text=g("Multiple objects to one texture set"))
			col=row.column()
			col.prop(sbp,"clear_image",toggle=TOGGLES,text=g("Clear existing bake image before bake"))
			if sbp.merged_bake:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"merged_bake_name",text=g("Texture set name"))
			if len(sbp.objects_list) < 2 and sbp.merged_bake or ((sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode!="automatch"):
				message_lines=["You are baking multiple objects to one","texture set,but have fewer then 2","in the bake list. This is OK,but","might not be what you wanted"]
				monkey_tip(context,message_lines,box)
	def draw_export_settings(self,context,box):
		row=box.row(align=ALIGN)
		sbp=context.scene.SimpleBake_Props
		row.prop(sbp,"export_show",text=g("Export settings"),icon="PROP_ON" if sbp.export_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.export_show:
			if not is_blend_saved():
				row=box.row(align=ALIGN)
				GL(row,"Unavailable - Blend file not saved",)
				return True
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"save_bakes_external",toggle=TOGGLES,text=g("Export bakes"))
			col=row.column()
			col.prop(sbp,"save_obj_external",toggle=TOGGLES,text=g("Export mesh"))
			if sbp.save_bakes_external or sbp.save_obj_external:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"export_path",text=g("Export Path"))
				col=row.column()
				col.operator("simplebake.export_path_to_blend_location",text="",icon="UV_SYNC_SELECT")
				row=box.row(align=ALIGN)
				row.prop(sbp,"export_folder_per_object",toggle=TOGGLES,text=g("Sub-folder per object"))
				row.scale_y=SCALE
			if sbp.save_bakes_external:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				if(sbp.global_mode==SBConstants.PBR):
					row.prop(sbp,"apply_col_man_to_col",toggle=TOGGLES,text=g("Export diffuse with col management settings"))
					if not sbp.selected_col:
						row.enabled=False
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				if sbp.export_file_format=="OPEN_EXR":
					pass
				elif sbp.export_file_format=="JPEG" or sbp.export_file_format=="TARGA":
					pass
				else:
					row.prop(sbp,"everything_16bit",toggle=TOGGLES,text=g("All exports 16bit"))
				if(sbp.global_mode==SBConstants.CYCLESBAKE):
					row.prop(sbp,"export_cycles_col_space",toggle=TOGGLES,text=g("Export with col management settings"))
					if context.scene.cycles.bake_type=="NORMAL":
						row.enabled=False 
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"export_file_format",text=g("Format"))
				if sbp.export_file_format=="OPEN_EXR":
					col=row.column()
					col.prop(sbp,"exr_codec_export",text=g("Codec"))
				if sbp.export_file_format=="JPEG":
					col=row.column()
					col.prop(sbp,"jpeg_quality",slider=True,text=g("JPEG quality"))
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"keep_internal_after_export",toggle=TOGGLES,text=g("Keep internal images after export"))
			if sbp.save_obj_external:
				row=box.row(align=ALIGN)
				row.prop(sbp,"export_mesh_individual_or_combined",toggle=TOGGLES,text=g("Mesh objects"))
				row.scale_y=SCALE
				row=box.row(align=ALIGN)
				row.prop(sbp,"export_format",text=g("Export format"))
				if sbp.export_format=="fbx":
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"apply_mods_on_mesh_export",toggle=TOGGLES,text=g("Apply object modifiers"))
					col=row.column()
					col.prop(sbp,"apply_transformation",toggle=TOGGLES,text=g("Apply transformation"))
					if sbp.export_mesh_individual_or_combined=="combined":
						row=box.row(align=ALIGN)
						row.scale_y=SCALE
						row.prop(sbp,"fbx_name",toggle=TOGGLES,text=g("FBX name"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					row.prop(sbp,"fbx_preset_name",toggle=TOGGLES,text=g("FBX preset"))
				if sbp.export_format=="gltf":
					if sbp.export_mesh_individual_or_combined=="combined":
						row=box.row(align=ALIGN)
						row.scale_y=SCALE
						row.prop(sbp,"gltf_name",toggle=TOGGLES,text=g("GLTF name"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					row.prop(sbp,"gltf_preset_name",toggle=TOGGLES,text=g("GLTF Export Preset"))
			if sbp.everything32bitfloat and sbp.save_bakes_external and sbp.export_file_format !="OPEN_EXR":
				message_lines=["You are creating all images as 32bit float.","You may want to export to EXR","to preserve your 32bit image(s)"]
				monkey_tip(context,message_lines,box)
			if sbp.export_file_format=="OPEN_EXR" and sbp.save_bakes_external:
				message_lines=["Note: EXR files cannot be exported","with colour management settings.","EXR doesn't support them. Even","Blender defaults will be ignored"]
				monkey_tip(context,message_lines,box)
	def draw_uv_settings(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"uv_show",text=g("UV settings"),icon="PROP_ON" if sbp.uv_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.uv_show:
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"new_uv_option",toggle=TOGGLES,text=g("New UV Map(s)"))
			if not sbp.new_uv_option:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"auto_detect_udims",toggle=TOGGLES,text=g("Auto detect UDIMs"))
			if sbp.auto_detect_udims:
				message_lines=monkey_tip_formatter("UDIM tiles are detected when UVs extend beyond standard UV space. Objects with and without UDIM tiles can be baked  together. When using 'Multiple objects to one texture set,' if any object has UDIM tiles,all objects will be baked to that UDIM set")
				monkey_tip(context,message_lines,box)
			def multi_object_options(box):
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"new_uv_method",text=g("New UV Method"))
				if sbp.new_uv_method in ["SmartUVProject_Atlas","SmartUVProject_Individual"]:
						row=box.row(align=ALIGN)
						row.alignment="RIGHT"
						row.scale_y=SCALE
						row.prop(sbp,"unwrapmargin",text=g("UV Unwrap Margin"))
						row=box.row(align=ALIGN)
						row.scale_y=SCALE
						row.prop(sbp,"uvcorrectaspect",toggle=TOGGLES,text=g("Correct aspect"))
				else:
					row=box.row(align=ALIGN)
					row.alignment="RIGHT"
				n=int(''.join(c for c in bpy.app.version_string if c.isdigit()))
				if sbp.new_uv_method in ["CombineExisting"] and n >=360:
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					row.prop(sbp,"average_uv_size",text=g("Average UV island size"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvp_rotate",toggle=TOGGLES,text=g("Rotate"))
					col=row.column()
					col.prop(sbp,"uvp_scale",toggle=TOGGLES,text=g("Scale"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvp_lock_pinned",toggle=TOGGLES,text=g("Lock pinned"))
					col=row.column()
					col.prop(sbp,"uvp_merge_overlapping",toggle=TOGGLES,text=g("Merge overlapping"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvpackmargin",toggle=TOGGLES,text=g("Pack Margin"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvp_shape_method",toggle=TOGGLES,text=g("Shape method"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvp_rotation_method",toggle=TOGGLES,text=g("Rotation method"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvp_margin_method",toggle=TOGGLES,text=g("Margin method"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvp_lock_method",toggle=TOGGLES,text=g("Lock method"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					col=row.column()
					col.prop(sbp,"uvp_pack_to",toggle=TOGGLES,text=g("Pack to"))
			def single_object_options(box):
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					row.alignment="RIGHT"
					row.label(text=g("Smart UV Project: "))
					row.prop(sbp,"unwrapmargin",toggle=TOGGLES,text=g("UV Unwrap Margin"))
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					row.alignment="RIGHT"
					row.prop(sbp,"uvcorrectaspect",text=g("Correct aspect"))
			if sbp.new_uv_option:
				objects=[obj.name for obj in sbp.objects_list]
				viable_high_low=SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes
				if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch" and len(viable_high_low) >1:
					multi_object_options(box)
				elif (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch" and len(viable_high_low)==1:
					single_object_options(box)
				elif (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="decals":
					single_object_options(box)
				elif len(objects) >1 and not (sbp.selected_s2a or sbp.cycles_s2a):
					multi_object_options(box)
				elif len(objects)==1:
					single_object_options(box)
				else:
					row=box.row(align=ALIGN)
					GL(row,"No objects selected for bake",)
			if not sbp.new_uv_option:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"prefer_existing_sbmap",toggle=TOGGLES,text=g("Prefer existing UVs called SimpleBake"))
			if sbp.new_uv_option:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"move_new_uvs_to_top",toggle=TOGGLES,text=g("Move new UVs to top"))
			col=row.column()
			col.prop(sbp,"restore_orig_uv_map",toggle=TOGGLES,text=g("Restore original UVs"))
			if sbp.new_uv_option and sbp.restore_orig_uv_map and not sbp.copy_and_apply:
				message_lines=["Generating new UVs,but restoring originals","after bake. Baked textures won't align with the","original UVs. Manually change active UV map ","after bake"]
			if sbp.new_uv_option and sbp.new_uv_method=="SmartUVProject_Individual" and sbp.merged_bake:
				message_lines=["Current settings will unwrap objects","individually but bake to one texture set","Bakes will be on top of each other!"]
				monkey_tip(context,message_lines,box)
			if not sbp.new_uv_option  and sbp.merged_bake:
				message_lines=monkey_tip_formatter("ALERT: You are baking multiple objects to one  texture set with existing UVs. You will need to  manually make sure those UVs don't overlap!")
				monkey_tip(context,message_lines,box)
			if sbp.new_uv_option and not sbp.save_obj_external and not sbp.copy_and_apply and sbp.bgbake=="bg":
				message_lines=["You are baking in background with new UVs,but","not exporting FBX or using 'Copy Objects and Apply Bakes'","You will recieve the baked textures on import,but you will","have no access to an object with the new UV map!"]
				monkey_tip(context,message_lines,box)
	def draw_other_settings(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"other_show",text=g("Other settings"),icon="PROP_ON" if sbp.other_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.other_show:
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"batch_name",text=g("Batch name"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"bake_sequence",toggle=TOGGLES,text=g("Image sequence"))
			if sbp.bake_sequence:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"bake_sequence_start_frame",text=g("Start"))
				row.prop(sbp,"bake_sequence_end_frame",text=g("End"))
				message_lines=monkey_tip_formatter("NOTE: If you haven't added %FRAME% to your image format string in the SimpleBake addon preferences,it  will be added automatically to the end of the names of your baked images")
				monkey_tip(context,message_lines,box)
			dt=False
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			t="Copy objects and apply bakes"
			t=f"{t} (after import)" if sbp.bgbake=="bg" else t
			row.prop(sbp,"copy_and_apply",text=g(t),toggle=TOGGLES)
			if not sbp.keep_internal_after_export:
				dt=True
				row.enabled=False
			if sbp.copy_and_apply:
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				t="Hide source objects after bake"
				t=f"{t} (after import)" if sbp.bgbake=="bg" else t
				col.prop(sbp,"hide_source_objects",text=t,toggle=TOGGLES)
				if sbp.selected_s2a or sbp.cycles_s2a:
					t="Hide cage object after bake"
					t=f"{t} (after import)" if sbp.bgbake=="bg" else t
					col=row.column()
					col.prop(sbp,"hide_cage_object",text=t,toggle=TOGGLES)
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				col=row.column()
				col.prop(sbp,"create_glTF_node",toggle=TOGGLES,text=g("Create glTF settings"))
				if sbp.create_glTF_node:
					col=row.column()
					col.prop(sbp,"glTF_selection",text="",toggle=TOGGLES)
				if sbp.global_mode==SBConstants.CYCLESBAKE:
					row=box.row(align=ALIGN)
					row.scale_y=SCALE
					row.prop(sbp,"cyclesbake_copy_and_apply_mat_format",text=g("Material"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"apply_bakes_to_original",text=g("Apply bakes to original objects"),toggle=TOGGLES)
			if sbp.bgbake=="bg":
				row.enabled=False
			if not sbp.keep_internal_after_export:
				dt=True
				row.enabled=False
			if dt:
				message_lines=monkey_tip_formatter("'Copy objects and apply bakes' and 'Apply bakes to original objects' aren't available as you have chosen not to keep bakes internally after export. Turn that back on under 'Export Settings' to use these options")
				monkey_tip(context,message_lines,box)
			if sbp.apply_bakes_to_original:
				message_lines=["Be careful when applying bakes to","original objects. Original materials won't","be deleted,BUT they will have no users","and may be purged on next save"]
				monkey_tip(context,message_lines,box)
			if sbp.apply_bakes_to_original and sbp.restore_orig_uv_map:
				message_lines=["You are restoring your original UVs","after bake,but also applying the baked","textures to original objects. The textures","may not look right with original UVs"]
				monkey_tip(context,message_lines,box)
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			col=row.column()
			col.prop(sbp,"no_force_32bit_normals",toggle=TOGGLES,text=g("Don't force high bit-depth normal maps"))
			if sbp.global_mode==SBConstants.PBR:
				col=row.column()
				col.prop(sbp,"boosted_sample_count",toggle=TOGGLES,text=g("Boosted sample count (AO and Bevel)"))
			if context.preferences.addons["cycles"].preferences.has_active_device():
				row=box.row(align=ALIGN)
				row.prop(context.scene.cycles,"device",text=g("device"))
			else:
				row=box.row(align=ALIGN)
				GL(row,"No valid GPU device in Blender Preferences. Using CPU.",)
			if context.preferences.addons["cycles"].preferences.compute_device_type=="OPTIX" and context.preferences.addons["cycles"].preferences.has_active_device():
				message_lines=["Other users have reported problems baking","with GPU and OptiX. This is a Blender issue","If you encounter problems bake with CPU"]
				monkey_tip(context,message_lines,box)
			if (sbp.global_mode==SBConstants.PBR and sbp.copy_and_apply and
				len(pbr_selections_to_list(context))==0 and len(specials_selection_to_list(context)) > 0):
				message_lines=(["You are baking only special maps (no primary)","while using 'Copy objects and apply bakes'","Special maps will be in the new object(s)","material(s),but disconnected"])
				monkey_tip(context,message_lines,box)
	def draw_admin_settings(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"admin_settings_show",text=g("Utilities"),icon="PROP_ON" if sbp.admin_settings_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.admin_settings_show:
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.alert=True
			row.operator("simplebake.purge_settings",text=g("x-- SETTINGS --x"),icon="ERROR")
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.alert=True
			row.operator("simplebake.restorematerials",text=g("x-- MATERIALS --x"),icon="ERROR")
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.alert=True
			row.operator("simplebake.purge_images",text=g("X-- IMAGES --X"),icon="ERROR")
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.alert=True
			row.operator("simplebake.purge_objects",text=g("X-- OBJECTS --X"),icon="ERROR")
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.label(text=g("Find and replace"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"findreplace_find",toggle=TOGGLES,text=g("Find"))
			row.prop(sbp,"findreplace_replace",toggle=TOGGLES,text=g("Replace"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"findreplace_type",toggle=TOGGLES,text=g("Data type"))
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.prop(sbp,"limit_findandreplace_to_sb",text=g("Limit to SB data"),toggle=TOGGLES)
			row=box.row(align=ALIGN)
			row.scale_y=SCALE
			row.operator("simplebake.findandreplace",text=g("Find and replace"),icon="VIEWZOOM")
	def draw_channel_packing(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.prop(sbp,"channelpacking_show",text=g("Channel packing"),icon="PROP_ON" if sbp.channelpacking_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.channelpacking_show:
			if not is_blend_saved():
				row=box.row(align=ALIGN)
				GL(row,"Unavailable - Blend file not saved",)
			elif not sbp.save_bakes_external:
				row=box.row(align=ALIGN)
				GL(row,"Unavailable - You must be exporting your bakes",)
			else:
				row=box.row(align=ALIGN)
				col=row.column()
				col.template_list("SIMPLEBAKE_UL_CPTexList","CP Textures List",sbp,"cp_list",sbp,"cp_list_index")
				col=row.column()
				col.operator("simplebake.cptex_delete",text="",icon="CANCEL")
				col.operator("simplebake.cptex_set_defaults",text="",icon="MONKEY")
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"cp_name",text=g("Name: "))
				row=box.row(align=ALIGN)
				row.scale_y=SCALE
				row.prop(sbp,"channelpackfileformat",text=g("Format"))
				if sbp.channelpackfileformat=="OPEN_EXR":
					row.prop(sbp,"exr_codec_cpts",text=g("Codec"))
				if sbp.channelpackfileformat=="PNG":
					row.prop(sbp,"png_compression",text=g("Compression"))
				row=box.row(align=ALIGN)
				row.scale_y=0.7
				row.prop(sbp,"cptex_R",text="R")
				row=box.row(align=ALIGN)
				row.scale_y=0.7
				row.prop(sbp,"cptex_G",text="G")
				row=box.row(align=ALIGN)
				row.scale_y=0.7
				row.prop(sbp,"cptex_B",text="B")
				row=box.row(align=ALIGN)
				row.scale_y=0.7
				row.prop(sbp,"cptex_A",text="A")
				cp_list=sbp.cp_list
				current_name=sbp.cp_name 
				if current_name in cp_list:
					index=cp_list.find(current_name)
					cpt=cp_list[index]
					if cpt.R !=sbp.cptex_R  or cpt.G !=sbp.cptex_G  or cpt.B !=sbp.cptex_B  or cpt.A !=sbp.cptex_A  or cpt.file_format !=sbp.channelpackfileformat  or cpt.exr_codec !=sbp.exr_codec_cpts  or cpt.png_compression !=sbp.png_compression:
							row=box.row(align=ALIGN)
							row.alert=True
							text=g(f"Update {current_name} (!!not saved!!)")
							row.operator("simplebake.cptex_add",text=text,icon="ADD")
					else:
						text=g(f"Editing {current_name}")
						row=box.row(align=ALIGN)
						row.label(text=text)
						row.alignment='CENTER'
				else:
					row=box.row(align=ALIGN)
					text=g("Add new (!!not saved!!)")
					row.alert=True
					row.operator("simplebake.cptex_add",text=text,icon="ADD")
				if sbp.cptex_R==""  or sbp.cptex_G==""  or sbp.cptex_B==""  or sbp.cptex_A=="":
						row.enabled=False
				row=box.row(align=ALIGN)
				row.prop(sbp,"del_cptex_components",toggle=TOGGLES,text=g("Delete bakes after channel pack"))
				row.scale_y=SCALE
				if sbp.copy_and_apply or sbp.apply_bakes_to_original:
					row.enabled=False
				prefs=context.preferences.addons[base_package].preferences
				if not prefs.use_old_channel_packing:
					message_lines=monkey_tip_formatter("Currently using the new method for channel packing. This works better with PNG and TGA,but doesn't work for EXR (and hence why you cannot select it). If  you need EXR,enable the old method in SimpleBake addon preferences")
					monkey_tip(context,message_lines,box)
	def draw_bake_buttons(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.scale_y=1.5
		row.prop_enum(sbp,"bgbake","fg",text=g("Foreground"))
		row.prop_enum(sbp,"bgbake","bg",text=g("Background"))
		row=box.row(align=ALIGN)
		prefs=context.preferences.addons[base_package].preferences
		if prefs.check_for_conflicting_addons and not prefs.disable_other_addons2:
			enabled_addons=[addon.module for addon in bpy.context.preferences.addons]
			for ea in enabled_addons:
				for ca in conflicting_addons:
					if ca in ea:
						row=box.row(align=ALIGN)
						row.scale_y=0.5
						row.alignment='CENTER'
						row.alert=True
						GL(row,"CANNOT PROCEED TO BAKE","ERROR")
						row=box.row(align=ALIGN)
						row.scale_y=0.5
						row.alignment='CENTER'
						row.alert=True
						row.label(text=g(f"Addon '{ea}'"))
						row=box.row(align=ALIGN)
						row.scale_y=0.5
						row.alignment='CENTER'
						row.alert=True
						GL(row,f"conflicts with SimpleBake",)
						row=box.row(align=ALIGN)
						row.scale_y=0.5
						row.alignment='CENTER'
						row.alert=True
						GL(row,f"and will cause Blender to crash!",)
						row=box.row(align=ALIGN)
						row.scale_y=0.5
						row.alignment='CENTER'
						row.alert=True
						row.label(text=g(f"Disable {ea} first"))
						return False
		disable_if_is=False
		disable_if_udims=False
		bg_name=False
		op=""
		text=""
		icon=""
		if sbp.bgbake=="fg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="decals":
			op="simplebake.decals_operation"
			icon='RENDER_RESULT'
			text=g("Bake! (Decals)")
		elif sbp.bgbake=="bg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="decals":
			op="simplebake.decals_operation_background"
			icon='RENDER_RESULT'
			text=g("Bake! (Decals) (Background)")
			bg_name=True
			disable_if_is=True
			disable_if_udims=True if not sbp.save_bakes_external else disable_if_udims
		elif sbp.bgbake=="fg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
			op="simplebake.automatch_operation"
			icon='RENDER_RESULT'
			text=g("Bake! (Auto Match)")
		elif sbp.bgbake=="bg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
			op="simplebake.automatch_operation_background"
			icon='RENDER_RESULT'
			text=g("Bake! (Auto Match) (Background)")
			bg_name=True
			disable_if_is=True
			disable_if_udims=True if not sbp.save_bakes_external else disable_if_udims
		elif sbp.bgbake=="fg" and sbp.global_mode==SBConstants.PBR and not sbp.selected_s2a:
			op="simplebake.bake_operation_pbr"
			icon='RENDER_RESULT'
			text=g("Bake!")
		elif sbp.bgbake=="bg" and sbp.global_mode==SBConstants.PBR and not sbp.selected_s2a:
			op="simplebake.bake_operation_pbr_background"
			icon='RENDER_RESULT'
			text=g("Bake! (in background)")
			bg_name=True
			disable_if_is=True
			disable_if_udims=True if not sbp.save_bakes_external else disable_if_udims
		elif sbp.bgbake=="fg" and sbp.global_mode==SBConstants.PBR and sbp.selected_s2a:
			op="simplebake.bake_operation_pbrs2a"
			icon='RENDER_RESULT'
			text=g("Bake! (to target)")
		elif sbp.bgbake=="bg" and sbp.global_mode==SBConstants.PBR and sbp.selected_s2a:
			op="simplebake.bake_operation_pbrs2a_background"
			icon='RENDER_RESULT'
			text=g("Bake! (in background)")
			bg_name=True
			disable_if_is=True
			disable_if_udims=True if not sbp.save_bakes_external else disable_if_udims
		elif sbp.bgbake=="fg" and sbp.global_mode==SBConstants.CYCLESBAKE and not sbp.cycles_s2a:
			op="simplebake.bake_operation_cyclesbake"
			icon='RENDER_RESULT'
			text=g("Bake!")
		elif sbp.bgbake=="bg" and sbp.global_mode==SBConstants.CYCLESBAKE and not sbp.cycles_s2a:
			op="simplebake.bake_operation_cyclesbake_background"
			icon='RENDER_RESULT'
			text=g("Bake! (in background)")
			bg_name=True
			disable_if_is=True
			disable_if_udims=True if not sbp.save_bakes_external else disable_if_udims
		elif sbp.bgbake=="fg" and sbp.global_mode==SBConstants.CYCLESBAKE and sbp.cycles_s2a:
			op="simplebake.bake_operation_cyclesbake_s2a"
			icon='RENDER_RESULT'
			text=g("Bake! (to target)")
		elif sbp.bgbake=="bg" and sbp.global_mode==SBConstants.CYCLESBAKE and sbp.cycles_s2a:
			op="simplebake.bake_operation_cyclesbake_s2a_background"
			icon='RENDER_RESULT'
			text=g("Bake! (in background)")
			bg_name=True
			disable_if_is=True
			disable_if_udims=True if not sbp.save_bakes_external else disable_if_udims
		row=box.row(align=ALIGN)
		if sbp.bake_sequence:
			row.operator("simplebake.image_sequence",icon='RENDER_RESULT',text=g("Bake,image sequence")).cmd=op
		else:
			row.operator(op,icon=icon,text=text)
		if disable_if_is: disable_row_if_image_sequence(context,row,box)
		if disable_if_udims: disable_row_if_udims(context,row,box)
		if BakeInProgress.is_baking:
			row.enabled=False
		row.scale_y=2
		if bg_name:
			row=box.row(align=ALIGN)
			row.prop(sbp,"bgbake_name",text=g("Name: "))
		if space=='VIEW_3D':
			message_lines=monkey_tip_formatter("WARNING: Based on my testing,Blender crashes WAY more when  SimpleBake is displayed in the N-Panel. I haven't been able to find out  why Use with extreme caution!")
			monkey_tip(context,message_lines,box)
	def draw_fg_bake_status(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.scale_y=0.5
		row.alignment='CENTER'
		row.alert=True
		row.label(text=g("FOREGROUND BAKE"))
		row=box.row(align=ALIGN)
		row.scale_y=0.5
		row.alignment='CENTER'
		row.alert=True
		row.label(text=g("IN PROGRESS"))
		row=box.row(align=ALIGN)
		row.scale_y=0.5
		row.alignment='CENTER'
		row.label(text=g("Please wait"))
		row=box.row(align=ALIGN)
		row.alignment='CENTER'
		GL(row,f"{sbp.percent_complete}% complete",)
	def draw_background_bakes(self,context,box):
		sbp=context.scene.SimpleBake_Props
		active=BackgroundBakeTasks.active_tasks
		queued=BackgroundBakeTasks.queued_tasks
		completed=BackgroundBakeTasks.completed_tasks
		row=box.row(align=ALIGN)
		row.prop(sbp,"bg_status_show",text=g("Background bakes"),icon="PROP_ON" if sbp.bg_status_show else "PROP_OFF",icon_only=False,emboss=False)
		if sbp.bg_status_show:
			row=box.row(align=ALIGN)
			row.label(text=g("Completed:"))
			for bgt in completed:
				row=box.row(align=ALIGN)
				row.scale_y=0.7
				GL(row,f"{bgt.name} - finished","GHOST_ENABLED")
				row.operator("simplebake.import_bgbake",icon='IMPORT',text="").pid=str(bgt.pid)
				row.operator("simplebake.discard_bgbake",icon="CANCEL",text="").pid=str(bgt.pid)
			row=box.row(align=ALIGN)
			row.label(text=g("Active:"))
			for bgt in active:
				row=box.row(align=ALIGN)
				row.scale_y=0.7
				GL(row,f"{bgt.name} - baking in progress {BackgroundBakeTasks.get_bgbake_status(bgt)}%","GHOST_DISABLED")
				row.operator("simplebake.kill_active_bgbake",icon="CANCEL",text="").pid=str(bgt.pid)
			row=box.row(align=ALIGN)
			row.label(text=g("Queued:"))
			for bgt in queued:
				row=box.row(align=ALIGN)
				row.scale_y=0.7
				row.label(text=g(f"{bgt.name} - queued"),icon="GHOST_DISABLED")
				row.operator("simplebake.delete_queued_bgbake",icon='CANCEL',text="").id=bgt.id
	def draw_sketchfab_upload(self,context,box):
		sbp=context.scene.SimpleBake_Props
		row=box.row(align=ALIGN)
		row.operator("simplebake.sketchfab_upload",icon='IMPORT',text=g("Sketchfab Upload"))
		return True
	def draw(self,context):
		sbp=context.scene.SimpleBake_Props
		layout=self.layout
		DH(self,context,layout)
		if (not BakeInProgress.is_baking) or space=='VIEW_3D':
			box=layout.box()
			self.draw_global_mode_buttons(context,box)
			box=layout.box()
			self.draw_presets(context,box)
			box=layout.box()
			self.draw_objects_list(context,box)
			if sbp.global_mode==SBConstants.PBR:
				box=layout.box()
				self.draw_pbr_settings(context,box)
			if sbp.global_mode==SBConstants.CYCLESBAKE:
				box=layout.box()
				self.draw_cyclesbake_settings(context,box)
			box=layout.box()
			self.draw_specials_settings(context,box)
			box=layout.box()
			self.draw_texture_settings(context,box)
			box=layout.box()
			self.draw_export_settings(context,box)
			box=layout.box()
			self.draw_uv_settings(context,box)
			box=layout.box()
			self.draw_other_settings(context,box)
			if sbp.global_mode==SBConstants.PBR:
				box=layout.box()
				self.draw_channel_packing(context,box)
			box=layout.box()
			self.draw_admin_settings(context,box)
			box=layout.box()
			self.draw_bake_buttons(context,box)
		else:
			box=layout.box()
			self.draw_fg_bake_status(context,box)
		box=layout.box()
		self.draw_background_bakes(context,box)
		prefs=context.preferences.addons[base_package].preferences
		if prefs.apikey !="":
			box=layout.box()
			self.draw_sketchfab_upload(context,box)
def UPG(s,_):
	if len(P().C.strip()):
		for i in [j for j in CL if hasattr(j,"bl_category")]:bpy.utils.unregister_class(i);i.bl_category=P().C;bpy.utils.register_class(i)
CL=(SIMPLEBAKE_PT_main_panel,)
classes=([SIMPLEBAKE_PT_main_panel])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
