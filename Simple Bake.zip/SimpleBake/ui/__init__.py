from . import panel,panel_operators,objects_list,channel_packing_list,preferences,presets_list,presets_list_local
def register():
	objects_list.register()
	panel.register()
	panel_operators.register()
	channel_packing_list.register()
	preferences.register()
	presets_list.register()
	presets_list_local.register()
def unregister():
	objects_list.unregister()
	panel.unregister()
	panel_operators.unregister()
	channel_packing_list.unregister()
	preferences.unregister()
	presets_list.unregister()
	presets_list_local.unregister()
