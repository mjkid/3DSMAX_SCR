from ..G import *
import bpy,os
from pathlib import Path
from bpy.utils import register_class,unregister_class
from bpy.types import Panel,AddonPreferences,Operator
from bpy.props import StringProperty,BoolProperty,EnumProperty,IntProperty
from .. import __package__ as base_package
from .panel import SIMPLEBAKE_PT_main_panel,read_settings,UPG
import webbrowser
try:
	from ..auto_update import VersionControl
except:
	VersionControl=None
from ..utils import SBConstants,clean_file_name,get_cs_list
panel_loc_just_changed=False
class SimpleBake_Preferences(AddonPreferences):
	bl_idname=base_package
	apikey: StringProperty(name="Sketchfab API Key: ")
	img_name_format: StringProperty(name="Image format string",default="%OBJ%_%BATCH%_%BAKEMODE%_%BAKETYPE%")
	des="在适当的地方缩写图像名称中的分辨率（例如“2K”而不是“2048x2048”）"
	abbr_res: BoolProperty(description=des,default=True)
	diffuse_alias: StringProperty(name=SBConstants.PBR_DIFFUSE,default=SBConstants.PBR_DIFFUSE)
	diffuse_cs: EnumProperty(name="",items=get_cs_list,default=19)
	metal_alias: StringProperty(name=SBConstants.PBR_METAL,default=SBConstants.PBR_METAL)
	metal_cs: EnumProperty(name="",items=get_cs_list,default=16)
	roughness_alias: StringProperty(name=SBConstants.PBR_ROUGHNESS,default=SBConstants.PBR_ROUGHNESS)
	roughness_cs: EnumProperty(name="",items=get_cs_list,default=16)
	glossy_alias: StringProperty(name=SBConstants.PBR_GLOSSY,default=SBConstants.PBR_GLOSSY)
	glossy_cs: EnumProperty(name="",items=get_cs_list,default=16)
	normal_alias: StringProperty(name=SBConstants.PBR_NORMAL,default=SBConstants.PBR_NORMAL)
	normal_cs: EnumProperty(name="",items=get_cs_list,default=16)
	transmission_alias: StringProperty(name=SBConstants.PBR_TRANSMISSION,default=SBConstants.PBR_TRANSMISSION)
	transmission_cs: EnumProperty(name="",items=get_cs_list,default=16)
	clearcoat_alias: StringProperty(name=SBConstants.PBR_CLEARCOAT,default=SBConstants.PBR_CLEARCOAT)
	clearcoat_cs: EnumProperty(name="",items=get_cs_list,default=16)
	clearcoatrough_alias: StringProperty(name=SBConstants.PBR_CLEARCOAT_ROUGH,default=SBConstants.PBR_CLEARCOAT_ROUGH)
	clearcoatrough_cs: EnumProperty(name="",items=get_cs_list,default=16)
	emission_alias: StringProperty(name=SBConstants.PBR_EMISSION,default=SBConstants.PBR_EMISSION)
	emission_cs: EnumProperty(name="",items=get_cs_list,default=19)
	specular_alias: StringProperty(name=SBConstants.PBR_SPECULAR,default=SBConstants.PBR_SPECULAR)
	specular_cs: EnumProperty(name="",items=get_cs_list,default=16)
	alpha_alias: StringProperty(name=SBConstants.PBR_ALPHA,default=SBConstants.PBR_ALPHA)    
	alpha_cs: EnumProperty(name="",items=get_cs_list,default=16)
	sss_alias: StringProperty(name=SBConstants.PBR_SSS,default=SBConstants.PBR_SSS)
	sss_cs: EnumProperty(name="",items=get_cs_list,default=16)
	bump_alias: StringProperty(name=SBConstants.PBR_BUMP,default=SBConstants.PBR_BUMP)
	bump_cs: EnumProperty(name="",items=get_cs_list,default=16)
	displacement_alias: StringProperty(name=SBConstants.PBR_DISPLACEMENT,default=SBConstants.PBR_DISPLACEMENT)
	displacement_cs: EnumProperty(name="",items=get_cs_list,default=16)
	ao_alias: StringProperty(name=SBConstants.AO,default=SBConstants.AO)
	ao_cs: EnumProperty(name="",items=get_cs_list,default=16)
	curvature_alias: StringProperty(name=SBConstants.CURVATURE,default=SBConstants.CURVATURE)
	curvature_cs: EnumProperty(name="",items=get_cs_list,default=16)
	thickness_alias: StringProperty(name=SBConstants.THICKNESS,default=SBConstants.THICKNESS)
	thickness_cs: EnumProperty(name="",items=get_cs_list,default=16)
	vertexcol_alias: StringProperty(name=SBConstants.VERTEXCOL,default=SBConstants.VERTEXCOL)
	vertexcol_cs: EnumProperty(name="",items=get_cs_list,default=16)
	colid_alias: StringProperty(name=SBConstants.COLOURID,default=SBConstants.COLOURID)
	colid_cs: EnumProperty(name="",items=get_cs_list,default=16)
	lightmap_alias: StringProperty(name=SBConstants.LIGHTMAP,default=SBConstants.LIGHTMAP)
	lightmap_cs: EnumProperty(name="",items=get_cs_list,default=16)
	no_update_check: BoolProperty(default=1,description="不要自动检查简单烘焙的更新。保持当前安装版本")
	ungroup_all_node_groups: BoolProperty(default=False,description="解压缩所有节点组。如果材质中的节点设置非常不寻常,则使用此选项。(例如,隐藏在节点组内的“材质输出”节点)。这将损害性能,但可以避免与具有质量嵌套节点组的某些材质生成碰撞")
	skip_pbr_nodes_check: BoolProperty(default=False,description="烘焙PBR(漫反射BSDF、光泽BSDF等)时跳过对无效PBR节点的检查不建议")
	use_old_channel_packing: BoolProperty(default=False,description="使用通道打包的旧合成器方法")
	disable_auto_smooth_for_split_normals: BoolProperty(default=True,description="在为具有自定义分割法向的物体烘焙法向映射时,自动平滑选项会导致问题。此选项将导致简单烘焙禁用烘焙的自动平滑,以阻止法向映射中的奇怪伪影")
	pbr_sample_count: IntProperty(default=2,description="覆盖用于PBR烘焙的采样数量。默认值为2,这通常适用于所有PBR烘焙,因为它们被烘焙为自发光(即不可能有噪点")
	panel_location: EnumProperty(name="Panel location",default=1,items=[ ("renderpanel","Render Panel","在“渲染属性”面板(摄影机图标)上显示简单烘焙)" ),("npanel","N-Panel","在3D视口中的N面板(也称为属性面板)上显示简单烘焙" ) ])
	togglesorboxes: EnumProperty(name="Toggles or tickboxes",default=0,items=[ ("toggles","Use toggles","更改简单烘焙面板上选项的外观(切换)" ),("tickboxes","Use tickboxes","更改简单烘焙面板(复选框)上选项的外观)" ) ])
	solidshadingonbake: BoolProperty(default=True,description="建议在烘焙过程中只使用实体粉碎,以提高性能并减少碰撞的机会")
	saveonbake: BoolProperty(default=True,description="在任何烘焙操作之前保存Blend文件")
	disable_other_addons2: BoolProperty(default=False,description="烘焙时禁用其他插件以防止碰撞")
	check_for_conflicting_addons: BoolProperty(default=True,description="检查已知与简单烘焙碰撞的插件,并防止烘焙")
	Y:bpy.props.EnumProperty(name="Language",items=[("A","英文",""),("B","中文",""),("C","中英",""),("D","英中","")],default=YYY,update=UPL)
	C:bpy.props.StringProperty(name="Category",description="选择面板类别的名称",default=TB,update=UPG)

	@classmethod
	def reset_img_string(cls,context):
		prefs=context.preferences.addons[base_package].preferences
		prefs.property_unset("img_name_format")
		bpy.ops.wm.save_userpref()
	@classmethod
	def reset_aliases(cls,context):
		prefs=context.preferences.addons[base_package].preferences
		prefs.property_unset("diffuse_alias")
		prefs.property_unset("metal_alias")  
		prefs.property_unset("roughness_alias")  
		prefs.property_unset("normal_alias")  
		prefs.property_unset("transmission_alias")  
		prefs.property_unset("clearcoat_alias")  
		prefs.property_unset("clearcoatrough_alias")  
		prefs.property_unset("emission_alias")
		prefs.property_unset("specular_alias")  
		prefs.property_unset("alpha_alias")
		prefs.property_unset("bump_alias")
		prefs.property_unset("displacement_alias")
		prefs.property_unset("sss_alias")
		prefs.property_unset("ao_alias") 
		prefs.property_unset("curvature_alias") 
		prefs.property_unset("thickness_alias") 
		prefs.property_unset("vertexcol_alias") 
		prefs.property_unset("colid_alias") 
		prefs.property_unset("lightmap_alias")
		prefs.property_unset("diffuse_cs")
		prefs.property_unset("metal_cs")  
		prefs.property_unset("roughness_cs")  
		prefs.property_unset("normal_cs")  
		prefs.property_unset("transmission_cs")  
		prefs.property_unset("clearcoat_cs")  
		prefs.property_unset("clearcoatrough_cs")  
		prefs.property_unset("emission_cs")
		prefs.property_unset("specular_cs")  
		prefs.property_unset("alpha_cs")
		prefs.property_unset("bump_cs")
		prefs.property_unset("displacement_cs")
		prefs.property_unset("sss_cs")
		prefs.property_unset("ao_cs") 
		prefs.property_unset("curvature_cs") 
		prefs.property_unset("thickness_cs") 
		prefs.property_unset("vertexcol_cs") 
		prefs.property_unset("colid_cs") 
		prefs.property_unset("lightmap_cs") 
		bpy.ops.wm.save_userpref() 
	def get_alias_dict(self):
		alias_dict={}
		alias_dict[SBConstants.PBR_DIFFUSE]=clean_file_name(self.diffuse_alias)
		alias_dict[SBConstants.PBR_METAL]=clean_file_name(self.metal_alias)
		alias_dict[SBConstants.PBR_ROUGHNESS]=clean_file_name(self.roughness_alias)
		alias_dict[SBConstants.PBR_GLOSSY]=clean_file_name(self.glossy_alias)
		alias_dict[SBConstants.PBR_NORMAL]=clean_file_name(self.normal_alias)
		alias_dict[SBConstants.PBR_TRANSMISSION]=clean_file_name(self.transmission_alias)
		alias_dict[SBConstants.PBR_CLEARCOAT]=clean_file_name(self.clearcoat_alias)
		alias_dict[SBConstants.PBR_CLEARCOAT_ROUGH]=clean_file_name(self.clearcoatrough_alias)
		alias_dict[SBConstants.PBR_EMISSION]=clean_file_name(self.emission_alias)
		alias_dict[SBConstants.PBR_SPECULAR]=clean_file_name(self.specular_alias)
		alias_dict[SBConstants.PBR_ALPHA]=clean_file_name(self.alpha_alias)
		alias_dict[SBConstants.PBR_SSS]=clean_file_name(self.sss_alias)
		alias_dict[SBConstants.PBR_BUMP]=clean_file_name(self.bump_alias)
		alias_dict[SBConstants.PBR_DISPLACEMENT]=clean_file_name(self.displacement_alias)
		alias_dict[SBConstants.AO]=clean_file_name(self.ao_alias)
		alias_dict[SBConstants.CURVATURE]=clean_file_name(self.curvature_alias)
		alias_dict[SBConstants.THICKNESS]=clean_file_name(self.thickness_alias)
		alias_dict[SBConstants.VERTEXCOL]=clean_file_name(self.vertexcol_alias)
		alias_dict[SBConstants.COLOURID]=clean_file_name(self.colid_alias)
		alias_dict[SBConstants.LIGHTMAP]=clean_file_name(self.lightmap_alias)
		return alias_dict
	def get_cs_dict(self):
		cs_dict={}
		cs_dict[SBConstants.PBR_DIFFUSE]=self.diffuse_cs
		cs_dict[SBConstants.PBR_METAL]=self.metal_cs
		cs_dict[SBConstants.PBR_ROUGHNESS]=self.roughness_cs
		cs_dict[SBConstants.PBR_GLOSSY]=self.glossy_cs
		cs_dict[SBConstants.PBR_NORMAL]=self.normal_cs
		cs_dict[SBConstants.PBR_TRANSMISSION]=self.transmission_cs
		cs_dict[SBConstants.PBR_CLEARCOAT]=self.clearcoat_cs
		cs_dict[SBConstants.PBR_CLEARCOAT_ROUGH]=self.clearcoatrough_cs
		cs_dict[SBConstants.PBR_EMISSION]=self.emission_cs
		cs_dict[SBConstants.PBR_SPECULAR]=self.specular_cs
		cs_dict[SBConstants.PBR_ALPHA]=self.alpha_cs
		cs_dict[SBConstants.PBR_SSS]=self.sss_cs
		cs_dict[SBConstants.PBR_BUMP]=self.bump_cs
		cs_dict[SBConstants.PBR_DISPLACEMENT]=self.displacement_cs
		cs_dict[SBConstants.AO]=self.ao_cs
		cs_dict[SBConstants.CURVATURE]=self.curvature_cs
		cs_dict[SBConstants.THICKNESS]=self.thickness_cs
		cs_dict[SBConstants.VERTEXCOL]=self.vertexcol_cs
		cs_dict[SBConstants.COLOURID]=self.colid_cs
		cs_dict[SBConstants.LIGHTMAP]=self.lightmap_cs
		return cs_dict
	def draw(self,context):
		sbp=context.scene.SimpleBake_Props
		layout=self.layout
		DH(self,context,layout)
		layout.prop(P(),"C",text=g("Category"))
		box=layout.box()
		row=box.row()
		row.scale_y=2
		row.operator("simplebake.release_notes",icon="MOD_WAVE",text=g("View the SimpleBake Release Notes"))
		if VersionControl !=None:
			if not VersionControl.at_current:
				row=box.row()
				row.scale_y=2
				row.alert=True
				if VersionControl.just_updated:
					GL(row,f"Please restart Blender",)
				else:
					GL(row,f"Version {VersionControl.current_version_str} of SimpleBake is available!",)
					row.operator("simplebake.auto_update",icon="MOD_WAVE",text=g("Update"))
			row=box.row()
			row.scale_y=2
			row.operator("simplebake.rollback_update",icon="FILE_REFRESH",text=g("Rollback to previous version of SimpleBake"))
			box=layout.box()
			row=box.row()
			row.scale_y=2
			row.operator("simplebake.support",icon="HELP",text=g("Open the SimpleBake Support Page"))
			box=layout.box()
			row=box.row()
			row.scale_y=2
			row.operator("simplebake.discord",icon="OUTLINER_OB_LIGHT",text=g("Open the SimpleBake Discord"))
		box=layout.box()
		row=box.row()
		GL(row,"Enter your Sketchfab API key below. Don't forget to click \"Save Preferences\" after.","INFO")
		row=box.row()
		row.prop(self,"apikey",text=g("Sketchfab API Key: "))
		box=layout.box()
		row=box.row()
		GL(row,"Format for baked image names. Valid variables are:",)
		row=box.row()
		GL(row,"%OBJ% (object name or 'MergedBake')",)
		row.scale_y=0.5
		row=box.row()
		GL(row,"%BATCH% (batch name)",)
		row.scale_y=0.5
		row=box.row()
		GL(row,"%BAKEMODE% (pbr or cycles bake)",)
		row.scale_y=0.5
		row=box.row()
		GL(row,"%BAKETYPE% (diffuse,emission etc.)",)
		row.scale_y=0.5
		row=box.row()
		GL(row,"%RESOLUTION% (e.g. 1024x1024)",)
		row.scale_y=0.5
		row=box.row()
		GL(row,"%FRAME% (Current frame number e.g. 0002 when baking an Image Sequence)",)
		row.scale_y=0.5
		row=box.row()
		row.prop(self,"img_name_format",text=g("Image format string"))
		row=box.row()
		row.prop(self,"abbr_res",text=g("Abbreviate resolution"))
		row=box.row()
		row.operator("simplebake.default_imgname_string",text=g("Restore image string to default"))
		box=layout.box()
		row=box.row()
		GL(row,"Aliases and colour space settings for PBR bake types",)
		row=box.row()
		GL(row,"WARNING: Sketchfab looks for certain values. Changing these may break SF Upload",)
		row=box.row()
		col=row.column()
		col.prop(self,"diffuse_alias",text=g("diffuse_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"diffuse_cs",text=g("diffuse_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"metal_alias",text=g("metal_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"metal_cs",text=g("metal_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"sss_alias",text=g("sss_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"sss_cs",text=g("sss_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"roughness_alias",text=g("roughness_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"roughness_cs",text=g("roughness_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"glossy_alias",text=g("glossy_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"glossy_cs",text=g("glossy_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"transmission_alias",text=g("transmission_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"transmission_cs",text=g("transmission_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"clearcoat_alias",text=g("clearcoat_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"clearcoat_cs",text=g("clearcoat_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"clearcoatrough_alias",text=g("clearcoatrough_alias"))  
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"clearcoatrough_cs",text=g("clearcoatrough_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"emission_alias",text=g("emission_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"emission_cs",text=g("emission_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"specular_alias",text=g("specular_alias")) 
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"specular_cs",text=g("specular_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"alpha_alias",text=g("alpha_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"alpha_cs",text=g("alpha_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"normal_alias",text=g("normal_alias")) 
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"normal_cs",text=g("normal_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"bump_alias",text=g("bump_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"bump_cs",text=g("bump_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"displacement_alias",text=g("displacement_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"displacement_cs",text=g("displacement_cs"))
		box=layout.box()
		row=box.row()
		GL(row,"Aliases for special bake types",)
		row=box.row()
		col=row.column()
		col.prop(self,"ao_alias",text=g("ao_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"ao_cs",text=g("ao_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"curvature_alias",text=g("curvature_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"curvature_cs",text=g("curvature_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"thickness_alias",text=g("thickness_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"thickness_cs",text=g("thickness_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"vertexcol_alias",text=g("vertexcol_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"vertexcol_cs",text=g("vertexcol_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"colid_alias",text=g("colid_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"colid_cs",text=g("colid_cs"))
		row=box.row()
		col=row.column()
		col.prop(self,"lightmap_alias",text=g("lightmap_alias"))
		col=row.column()
		col.alignment='RIGHT'
		col.prop(self,"lightmap_cs",text=g("lightmap_cs"))
		box=layout.box()
		row=box.row()
		row.operator("simplebake.restore_default_aliases",text=g("Restore all aliases and colour space settings to default"))
		box=layout.box()
		row=box.row()
		GL(row,"Tweaks and Misc Options",)
		row=box.row()
		row.prop(self,"solidshadingonbake",text=g("Solid shading on bake"))
		row=box.row()
		row.prop(self,"saveonbake",text=g("Save blend file prior to bake"))
		row=box.row()
		row.prop(self,"no_update_check",text=g("Don't check for SimpleBake updates on Blender start"))
		row=box.row()
		row.prop(self,"ungroup_all_node_groups",text=g("Unpack ALL node groups in materials"))
		row=box.row()
		row.prop(self,"skip_pbr_nodes_check",text=g("Skip check for invalid nodes for PBR bake (NOT RECOMMENDED)"))
		row=box.row()
		row.prop(self,"use_old_channel_packing",text=g("Use the old method for channel packing"))
		row=box.row()
		row.prop(self,"disable_auto_smooth_for_split_normals",text=g("Disable auto-smooth for custom split normals"))
		row=box.row()
		row.prop(self,"pbr_sample_count",text=g("Override PBR sample count"))
		row=box.row()
		row.prop(self,"disable_other_addons2",text=g("DEBUG: Disable other addons on bake"))
		row=box.row()
		row.prop(self,"check_for_conflicting_addons",text=g("Check for conflicting addons"))
		row=box.row()
		row=box.row()
		row.alert=True
		row.scale_y=0.5
		GL(row,"WARNING: Based on my testing,Blender crashes WAY more when SimpleBake",)
		row=box.row()
		row.alert=True
		row.scale_y=0.5
		GL(row,"is displayed in the N-Panel. I haven't been able to find out why",)
		row=box.row()
		row.alert=True
		row.scale_y=0.5
		GL(row,"Use with extreme caution!",)
		row=box.row()
		row.scale_y=1.4
		split=row.split(factor=0.2)
		col=split.column()
		col.label(text=g("Panel location"))
		col=split.column()
		col.prop(self,"panel_location",text="")
		col=split.column()
		col.operator("simplebake.change_panel_location",text=g("Change"))
		global panel_loc_just_changed
		if panel_loc_just_changed:
			row=box.row()
			row.alert=True
			GL(row,"Restart Blender for changes to take effect",)
		row=box.row()
		row.scale_y=1.4
		split=row.split(factor=0.2)
		col=split.column()
		GL(col,"Toggles or tickboxes",)
		col=split.column()
		col.prop(self,"togglesorboxes",text="")
		col=split.column()
		col.operator("simplebake.change_panel_toggles",text=g("Change"))
class SimpleBake_OT_change_panel_location(Operator):
	"""更改简单烘焙面板的位置"""
	bl_idname="simplebake.change_panel_location";bl_label=g("Change")
	def execute(self,context):
		prefs=context.preferences.addons[base_package].preferences
		p=Path(bpy.utils.script_path_user())
		p=p.parents[1]
		p=p / "data" / "SimpleBake" / "settings"
		savename="panel_location.txt"
		if not os.path.isdir(str(p)):
			os.makedirs(str(p))
		content=prefs.panel_location
		with open(str(p / savename),'w') as file:
			file.write(content)
		global panel_loc_just_changed
		panel_loc_just_changed=True
		return {'FINISHED'}
class SimpleBake_OT_change_panel_toggles(Operator):
	"""更改简单烘焙面板的位置"""
	bl_idname="simplebake.change_panel_toggles";bl_label=g("Change")
	def execute(self,context):
		prefs=context.preferences.addons[base_package].preferences
		p=Path(bpy.utils.script_path_user())
		p=p.parents[1]
		p=p / "data" / "SimpleBake" / "settings"
		savename="toggles.txt"
		if not os.path.isdir(str(p)):
			os.makedirs(str(p))
		content=prefs.togglesorboxes
		with open(str(p / savename),'w') as file:
			file.write(content)
		read_settings()
		unregister_class(SIMPLEBAKE_PT_main_panel)
		register_class(SIMPLEBAKE_PT_main_panel)
		self.report({'INFO'},"已进行更改")
		return {'FINISHED'}
class SimpleBake_OT_restore_default_aliases(Operator):
	"""重置图像名称别名"""
	bl_idname="simplebake.restore_default_aliases";bl_label=g("Restore all aliases and colour space settings to default")
	def execute(self,context):
		SimpleBake_Preferences.reset_aliases(context)
		return {'FINISHED'} 
class SimpleBake_OT_default_imgname_string(Operator):
	"""将图像名称字符串重置为默认值(与Sketchfab兼容"""
	bl_idname="simplebake.default_imgname_string";bl_label=g("Restore image string to default")
	def execute(self,context):
		SimpleBake_Preferences.reset_img_string(context)
		return {'FINISHED'} 
class SimpleBake_OT_Release_Notes(Operator):
	"""查看简单烘焙发行说明"""
	bl_idname="simplebake.release_notes";bl_label=g("View the SimpleBake Release Notes")
	def execute(self,context):
		webbrowser.open('http://www.toohey.co.uk/SimpleBake/releasenotes4.html',new=2)
		return {'FINISHED'}  
class SimpleBake_OT_Support(Operator):
	"""打开简单烘焙支持页面"""
	bl_idname="simplebake.support";bl_label=g("Open the SimpleBake Support Page")
	def execute(self,context):
		webbrowser.open('http://www.toohey.co.uk/SimpleBake/support',new=2)
		return {'FINISHED'}
class SimpleBake_OT_Discord(Operator):
	"""打开简单烘焙 纷争网"""
	bl_idname="simplebake.discord";bl_label=g("Open the SimpleBake Discord")
	def execute(self,context):
		webbrowser.open('https://discord.gg/ux9adAM2ZZ',new=2)
		return {'FINISHED'}
classes=([SimpleBake_Preferences,SimpleBake_OT_Release_Notes,SimpleBake_OT_Support,SimpleBake_OT_restore_default_aliases,SimpleBake_OT_default_imgname_string,SimpleBake_OT_Discord,SimpleBake_OT_change_panel_location,SimpleBake_OT_change_panel_toggles])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
