from ..G import *
import bpy
from bpy.utils import register_class,unregister_class
from bpy.types import Operator,PropertyGroup,UIList
from bpy.props import EnumProperty
def find_existing_local_presets(context):
	"""
	Returns a list of all existing SimpleBake local presets
	"""
	sbp=context.scene.SimpleBake_Props
	existing_presets=[]
	for k in list(sbp.keys()):
		if k.startswith("SB_local_preset_"):
			existing_presets.append(k.replace("SB_local_preset_",""))
	return existing_presets
def del_preset(context,all=False,friendly_name=""):
	"""
	Deletes either a specified preset or all presets
	"""
	sbp=context.scene.SimpleBake_Props
	del_list=[]
	name="SB_local_preset_" if all else f"SB_local_preset_{friendly_name}"
	for k in list(sbp.keys()):
		if k==name:
			del_list.append(k)
	for d in del_list:
		del sbp[d]
class SIMPLEBAKE_UL_Local_Presets_List(UIList):
	"""用户界面列表"""
	def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
		custom_icon='PACKAGE'
		if self.layout_type in {'DEFAULT','COMPACT'}:
			layout.label(text=g(item.name),icon=custom_icon)
		elif self.layout_type in {'GRID'}:
			layout.alignment='CENTER'
			layout.label(text="",icon=custom_icon) 
class SimpleBake_OT_local_preset_refresh(Operator):
	"""刷新局部简单烘焙预设列表"""
	bl_idname="simplebake.local_preset_refresh";bl_label=g("Local Refresh")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		sbp.local_presets_list.clear()
		for preset in find_existing_local_presets(context):
			i=sbp.local_presets_list.add()
			i.name=preset
		return {'FINISHED'} 
class SimpleBake_OT_local_preset_delete(Operator):
	"""删除选定的简单烘焙预设"""
	bl_idname="simplebake.local_preset_delete";bl_label=g("Delete local preset")
	@classmethod
	def poll(cls,context):
		sbp=context.scene.SimpleBake_Props
		try:
			sbp.local_presets_list[sbp.local_presets_list_index].name
			return True
		except:
			return False
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		index=sbp.local_presets_list_index
		item=sbp.local_presets_list[index]
		del_preset(context,friendly_name=item.name)
		bpy.ops.simplebake.local_preset_refresh()
		return {'FINISHED'} 
classes=([SIMPLEBAKE_UL_Local_Presets_List,SimpleBake_OT_local_preset_refresh,SimpleBake_OT_local_preset_delete])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
