from ..G import *
import bpy
from bpy.utils import register_class,unregister_class
from bpy.types import Operator,Macro
import uuid,sys
from .common_bake_support import CommonBakePrepandFinish,common_prestart,clean_up_after_bg_spawn
from ..utils import (pbr_selections_to_list,specials_selection_to_list,SBConstants,force_to_object_mode)
from ..background_and_progress import BakeInProgress,BakeProgress,BackgroundBakeTasks
from ..material_management import SimpleBake_OT_Material_Backup as MatManager
from .pbr_bake_support_operators import sample_nodes_present
from .specials_bake_operators import add_specials_to_macro_s2a
from ..messages import print_message
from .. import __package__ as base_package
def determine_cage_settings(context,op,lo,MACRO):
	sbp=context.scene.SimpleBake_Props
	if context.scene.render.bake.cage_object !=None:
		op.properties.use_cage=True
		op.properties.cage_object=context.scene.render.bake.cage_object.name
	elif sbp.cage_smooth_hard=="smooth":
		op.properties.use_cage=True
		op.properties.cage_extrusion=(sbp.cage_extrusion * sbp.cage_and_ray_multiplier)
	elif sbp.cage_smooth_hard=="hard":
		op.properties.use_cage=False
		op.properties.cage_extrusion=(sbp.cage_extrusion * sbp.cage_and_ray_multiplier)
	return True
def set_bake_op_settings(context,op,bake_mode,s2a=True):
	sbp=context.scene.SimpleBake_Props
	if s2a:
		op.properties.use_selected_to_active=True
	op.properties.use_clear=False
	op.properties.target="IMAGE_TEXTURES"
	op.properties.margin=context.scene.render.bake.margin
	try: op.properties.margin_type=context.scene.render.bake.margin_type
	except:pass
	op.properties.type="NORMAL" if bake_mode==SBConstants.PBR_NORMAL else "EMIT"
	op.properties.max_ray_distance=(sbp.ray_distance * sbp.cage_and_ray_multiplier)
def image_post_processing(context,MACRO,bake_mode,bake_operation_id):
	sbp=context.scene.SimpleBake_Props
	MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="根据需要缩放图像"
	op=MACRO.define("SIMPLEBAKE_OT_scale_images_if_needed")
	op.properties.bake_operation_id=bake_operation_id
	op=MACRO.define("SIMPLEBAKE_OT_pack_baked_images")
	op.properties.bake_operation_id=bake_operation_id
	op.properties.bake_mode=bake_mode
	if sbp.save_bakes_external:
		op=MACRO.define("SIMPLEBAKE_OT_save_images_externally")
		op.properties.bake_operation_id=bake_operation_id
		op.properties.bake_mode=bake_mode
	if sbp.rough_glossy_switch==SBConstants.PBR_GLOSSY:
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="反转粗糙度以创建光泽"
		op=MACRO.define("SIMPLEBAKE_OT_invert_roughness_to_glossy")
		op.properties.bake_operation_id=bake_operation_id
	if sbp.normal_format_switch==SBConstants.NORMAL_DIRECTX:
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="从OpenGL映射创建DirectX法向"
		op=MACRO.define("SIMPLEBAKE_OT_create_directx_normal")
		op.properties.bake_operation_id=bake_operation_id
class SimpleBake_OT_Decals_Operation_Background(Operator):
	"""开始烘焙操作"""
	bl_idname="simplebake.decals_operation_background";bl_description="开始贴花背景烘焙";bl_label=g("Bake (Background)")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		prefs=context.preferences.addons[base_package].preferences
		if not common_prestart(context,decals=True):
			return {'CANCELLED'}
		start_command="bpy.ops.simplebake.decals_operation()"
		bg_bake_id=str(uuid.uuid4())
		def append_to_bg_hide_list(obj,bg_bake_id):
			if "SB_BG_HIDE" in obj:
				existing=obj["SB_BG_HIDE"]
				existing.append(bg_bake_id)
				obj["SB_BG_HIDE"]=existing
			else:
				obj["SB_BG_HIDE"]=[bg_bake_id]
		if sbp.hide_source_objects:
			for obj in sbp.objects_list:
				o=obj.obj_point
				append_to_bg_hide_list(o,bg_bake_id)
			if sbp.targetobj !=None:
				append_to_bg_hide_list(sbp.targetobj,bg_bake_id)
		if sbp.hide_cage_object and context.scene.render.bake.cage_object !=None:
			append_to_bg_hide_list(context.scene.render.bake.cage_object,bg_bake_id)
		BackgroundBakeTasks(sbp.bgbake_name,sbp.copy_and_apply,start_command,bg_bake_id)
		clean_up_after_bg_spawn(context)
		return{'FINISHED'}
class SimpleBake_OT_Decals_Macro(Macro):
	bl_idname="simplebake.decals_macro";bl_options={'BLOCKING','INTERNAL'};bl_label=g("Go")
	@classmethod
	def clean(cls):
		try:
			bpy.utils.unregister_class(cls)
		except:
			pass
		bpy.utils.register_class(cls)
class SimpleBake_OT_Decals_Operation(Operator):
	"""开始PBR贴花烘焙"""
	bl_idname="simplebake.decals_operation";bl_description="开始贴花烘焙";bl_label=g("Bake")
	hl_matches={}
	def modal(self,context,event):
		sbp=context.scene.SimpleBake_Props
		if event.type=='TIMER':
			if not BakeInProgress.is_baking:
				context.window_manager.event_timer_remove(self._timer)
		return {'PASS_THROUGH'}
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		prefs=context.preferences.addons[base_package].preferences
		self.in_background=True if "--background" in sys.argv or sbp.fake_background else False
		if not self.in_background:
			if not common_prestart(context,decals=True):
				return {'CANCELLED'}
		orig_objects_list=[i.obj_point for i in sbp.objects_list]
		force_to_object_mode(context)
		bake_modes=pbr_selections_to_list(context)
		MACRO=SimpleBake_OT_Decals_Macro
		MACRO.clean()
		bake_operation_id=str(uuid.uuid4())
		mode=SBConstants.PBRS2A_DECALS
		BakeProgress(mode,len(orig_objects_list))
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="普通烘焙准备开始"
		MACRO.define("SIMPLEBAKE_OT_common_bake_prep")
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="预烘焙开始"
		if not bpy.app.version >=(4,1,0):
			MACRO.define("SIMPLEBAKE_OT_pbr_pre_bake_old")
		MACRO.define("SIMPLEBAKE_OT_remove_reroutes")
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="PBR特定烘焙准备开始"
		op=MACRO.define("SIMPLEBAKE_OT_pbr_specific_bake_prep_and_finish")
		op.properties.mode="prepare"
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="处理UV"
		op=MACRO.define("SIMPLEBAKE_OT_process_uvs")
		op.properties.pbrtarget_only=True
		boost_needed=False
		for o in orig_objects_list:
			boost_needed=True if sample_nodes_present(context,o.name) else boost_needed
		for bake_mode in bake_modes:
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="烘焙图像创建(目标物体)"
			op=MACRO.define("SIMPLEBAKE_OT_bake_image")
			op.properties.bake_operation_id=bake_operation_id
			op.properties.this_bake=bake_mode
			op.properties.target_object_name=sbp.targetobj.name
			op.properties.global_mode=SBConstants.PBRS2A
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="材质备份(S2A源物体)"
			op=MACRO.define("SIMPLEBAKE_OT_material_backup")
			op.properties.target_object_name=sbp.targetobj.name
			op.properties.mode=MatManager.MODE_WORKING_BACKUP
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="物体准备(自动匹配低点)"
			op=MACRO.define("SIMPLEBAKE_OT_prepare_object_mats_pbr")
			op.properties.bake_operation_id=bake_operation_id
			op.properties.target_name=sbp.targetobj.name
			op.properties.this_bake=bake_mode
			op.properties.only_bake_image_node=True
			for obj in orig_objects_list:
				MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="材质备份(贴花物体)"
				op=MACRO.define("SIMPLEBAKE_OT_material_backup")
				op.properties.target_object_name=obj.name
				op.properties.mode=MatManager.MODE_WORKING_BACKUP
				MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="材质准备(贴花物体)"
				op=MACRO.define("SIMPLEBAKE_OT_prepare_object_mats_pbr")
				op.properties.bake_operation_id=bake_operation_id
				op.properties.target_name=obj.name
				op.properties.this_bake=bake_mode
				op.properties.no_bake_image_node=True
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="选择S2A自动匹配设置的物体"
			op=MACRO.define("SIMPLEBAKE_OT_select_selected_to_active")
			op.properties.mode=SBConstants.PBRS2A
			if sbp.isolate_objects:
				op=MACRO.define("SIMPLEBAKE_OT_select_only_this")
				op.properties.target_object_name=sbp.targetobj.name
				op.properties.isolate_s2a=True
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="开始烘焙操作"
			def do_bake():
				op=MACRO.define("SIMPLEBAKE_OT_set_sample_count")
				op.properties.sample_count=sbp.boosted_sample_count if boost_needed else prefs.pbr_sample_count
				op=MACRO.define("OBJECT_OT_bake")
				set_bake_op_settings(context,op,bake_mode)
				determine_cage_settings(context,op,sbp.targetobj.name,MACRO)
				op=MACRO.define("SIMPLEBAKE_OT_update_progress")
			do_bake()
			image_post_processing(context,MACRO,bake_mode,bake_operation_id)
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="材质恢复(工作模式)"
			op=MACRO.define("SIMPLEBAKE_OT_material_backup")
			op.properties.mode=MatManager.MODE_WORKING_RESTORE
		bake_operation_id="DECALSBASE_" + bake_operation_id
		for bake_mode in bake_modes:
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="烘焙图像创建(目标物体)"
			op=MACRO.define("SIMPLEBAKE_OT_bake_image")
			op.properties.bake_operation_id=bake_operation_id
			op.properties.this_bake=bake_mode
			op.properties.target_object_name=sbp.targetobj.name
			op.properties.global_mode=SBConstants.PBR
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="材质备份(S2A源物体)"
			op=MACRO.define("SIMPLEBAKE_OT_material_backup")
			op.properties.target_object_name=sbp.targetobj.name
			op.properties.mode=MatManager.MODE_WORKING_BACKUP
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="物体准备(自动匹配低点)"
			op=MACRO.define("SIMPLEBAKE_OT_prepare_object_mats_pbr")
			op.properties.bake_operation_id=bake_operation_id
			op.properties.target_name=sbp.targetobj.name
			op.properties.this_bake=bake_mode
			op=MACRO.define("SIMPLEBAKE_OT_select_only_this")
			op.properties.target_object_name=sbp.targetobj.name
			if sbp.isolate_objects:
				op.properties.isolate=True
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="开始烘焙操作(非S2A)"
			def do_bake():
				op=MACRO.define("SIMPLEBAKE_OT_set_sample_count")
				op.properties.sample_count=sbp.boosted_sample_count if boost_needed else prefs.pbr_sample_count
				op=MACRO.define("OBJECT_OT_bake")
				set_bake_op_settings(context,op,bake_mode,s2a=False)
				op=MACRO.define("SIMPLEBAKE_OT_update_progress")
			do_bake()
			image_post_processing(context,MACRO,bake_mode,bake_operation_id)
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="材质恢复(工作模式)"
			op=MACRO.define("SIMPLEBAKE_OT_material_backup")
			op.properties.mode=MatManager.MODE_WORKING_RESTORE
		if len(specials_selection_to_list(context))> 0:
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="向宏队列添加特殊项"
			add_specials_to_macro_s2a(MACRO,context,bake_operation_id)
		if sbp.copy_and_apply or sbp.save_obj_external or sbp.apply_bakes_to_original or self.in_background:
			op=MACRO.define("SIMPLEBAKE_OT_copy_and_apply")
			op.properties.target_object_name=sbp.targetobj.name
			op.properties.bake_operation_id=bake_operation_id
			op.properties.global_mode=SBConstants.PBRS2A
			op.properties.decals_override=True
		if sbp.apply_bakes_to_original:
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="将烘焙应用于原始物体"
			op=MACRO.define("SIMPLEBAKE_OT_apply_bakes_to_original")
			op.properties.bake_operation_id=bake_operation_id
		if sbp.save_obj_external:
			MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="从外部保存网格物体"
			op=MACRO.define("SIMPLEBAKE_OT_save_objects_externally")
			op.properties.bake_operation_id=bake_operation_id
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="PBR专用烘焙拉直"
		op=MACRO.define("SIMPLEBAKE_OT_pbr_specific_bake_prep_and_finish")
		op.properties.mode="finish"
		MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="普通烘焙拉直"
		op=MACRO.define("SIMPLEBAKE_OT_common_bake_finishing")
		op.properties.bake_operation_id=bake_operation_id
		cp_op="SIMPLEBAKE_OT_channel_packing_old" if prefs.use_old_channel_packing else "SIMPLEBAKE_OT_channel_packing"
		op=MACRO.define(cp_op)
		op.properties.bake_operation_id=bake_operation_id
		op.properties.global_mode="BaseObject"
		op=MACRO.define(cp_op)
		op.properties.bake_operation_id=bake_operation_id.replace("DECALSBASE_","")
		op.properties.global_mode="Decals"
		BakeInProgress.is_baking=True
		context.window_manager.modal_handler_add(self)
		self._timer=context.window_manager.event_timer_add(1,window=context.window)
		bpy.ops.simplebake.decals_macro('INVOKE_DEFAULT')
		return {'RUNNING_MODAL'}
classes=([SimpleBake_OT_Decals_Operation,SimpleBake_OT_Decals_Macro,SimpleBake_OT_Decals_Operation_Background])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
