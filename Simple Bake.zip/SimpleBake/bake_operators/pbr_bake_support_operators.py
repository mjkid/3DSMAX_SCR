from ..G import *
import bpy,numpy as np,os
from pathlib import Path
import tempfile,shutil
from bpy.utils import register_class,unregister_class
from bpy.types import Operator
from bpy.props import StringProperty,BoolProperty
from ..utils import SBConstants,pbr_selections_to_list,select_only_this,force_to_object_mode,blender_refresh,object_list_to_names_list
from ..material_management import SimpleBake_OT_Material_Backup as MatManager
from ..messages import print_message
from ..background_and_progress import BakeInProgress as Bip
from .. import __package__ as base_package
convertable_shaders=["ShaderNodeBsdfDiffuse","ShaderNodeBsdfGlass","ShaderNodeBsdfAnisotropic","ShaderNodeEmission","ShaderNodeBsdfTransparent","ShaderNodeSubsurfaceScattering","ShaderNodeBsdfRefraction","ShaderNodeBsdfToon","ShaderNodeBsdfTranslucent","ShaderNodeBsdfSheen"]
def sample_nodes_present(context,obj_name):
	seeking=["ShaderNodeBevel","ShaderNodeAmbientOcclusion"]
	def hunt(node_tree):
		result=False
		if hasattr(node_tree,"nodes"):
			nodes=node_tree.nodes
			for n in nodes:
				if n.bl_idname in seeking and len(n.outputs[0].links)>0:
					result=True
					return result
				if n.bl_idname=="ShaderNodeGroup":
					result=hunt(n.node_tree)
					if result:
						return True
		return result
	obj=context.scene.objects[obj_name]
	for slot in obj.material_slots:
		mat=slot.material
		result=hunt(mat.node_tree)
		if result:
			return True
	return False
def create_node_group_dummy_nodes(node,node_tree):
	nodes=node_tree.nodes
	col_input_sockets=[s for s in node.inputs if s.bl_idname=="NodeSocketColor" and len(s.links)==0]
	int_input_sockets=[s for s in node.inputs if s.bl_idname in ["NodeSocketInt","NodeSocketIntFactor"] and len(s.links)==0]
	float_input_sockets=[s for s in node.inputs if s.bl_idname in ["NodeSocketFloatFactor","NodeSocketFloat"] and len(s.links)==0]
	vector_input_sockets=[s for s in node.inputs if s.bl_idname in ["NodeSocketVector","NodeSocketVectorXYZ"] and len(s.links)==0]
	bool_input_sockets=[s for s in node.inputs if s.bl_idname=="NodeSocketBool" and len(s.links)==0]
	for s in col_input_sockets:
		val=s.default_value
		rgb=node_tree.nodes.new("ShaderNodeRGB")
		rgb.outputs[0].default_value=val
		node_tree.links.new(rgb.outputs[0],s)
	for s in float_input_sockets:
		val=s.default_value
		vnode=node_tree.nodes.new("ShaderNodeValue")
		vnode.outputs[0].default_value=val
		node_tree.links.new(vnode.outputs[0],s)
	for s in int_input_sockets:
		val=s.default_value
		vnode=node_tree.nodes.new("ShaderNodeValue")
		vnode.outputs[0].default_value=val
		node_tree.links.new(vnode.outputs[0],s)
	for s in vector_input_sockets:
		x=s.default_value[0]
		y=s.default_value[1]
		z=s.default_value[2]
		vnode=node_tree.nodes.new("ShaderNodeCombineXYZ")
		vnode.inputs[0].default_value=x
		vnode.inputs[1].default_value=y
		vnode.inputs[2].default_value=z
		node_tree.links.new(vnode.outputs[0],s)
	for s in bool_input_sockets:
		val=s.default_value
		vnode=node_tree.nodes.new("ShaderNodeValue")
		vnode.outputs[0].default_value=1 if val else 0
		node_tree.links.new(vnode.outputs[0],s)
	return True
def has_node_groups(context,mat_name):
	if not (mat:=bpy.data.materials.get(mat_name)):
		print(f"错误找不到材质 {mat_name}")
	node_tree=mat.node_tree
	nodes=node_tree.nodes
	prefs=context.preferences.addons[base_package].preferences
	ungroup_all=prefs.ungroup_all_node_groups
	result=False
	node_group_nodes=[n for n in nodes if n.bl_idname=="ShaderNodeGroup"]
	for n in node_group_nodes:
		ss=[s for s in n.outputs if s.bl_idname=="NodeSocketShader"
				and len(s.links)>0]
		if len(ss)>0 or ungroup_all: result=True
	return result
def has_convertible_shaders(mat_name):
	if not (m:=bpy.data.materials.get(mat_name)):
		print(f"错误找不到材质 {mat_name}")
		return False
	node_tree=m.node_tree
	result=[False]
	def check_nodes(node_tree):
		if not hasattr(node_tree,"nodes"):
			return False
		nodes=node_tree.nodes
		for n in nodes:
			if n.bl_idname in convertable_shaders and len(n.outputs[0].links)>0:
				result[0]=True
			if n.bl_idname=="ShaderNodeGroup":
				check_nodes(n.node_tree)
	check_nodes(node_tree)
	return result[0]
def process_socket(tnode_name,tnode_sname,pnode_name,pnode_sname,nodes,node_tree):
	if not (tnode:=nodes.get(tnode_name)):
		print(f"找不到节点 {tnode_name}")
		return False
	if not (pnode:=nodes.get(pnode_name)):
		print(f"找不到节点 {pnode_name}")
		return False
	tnode_socket=tnode.inputs.get(tnode_sname)
	pnode_socket=pnode.inputs.get(pnode_sname)
	if len(tnode_socket.links)>0:
		from_socket=tnode_socket.links[0].from_socket
		node_tree.links.new(from_socket,pnode_socket)
	else:
		pnode_socket.default_value=tnode_socket.default_value
def swap_shaders_for_p(mat_name):
	to_del=[]
	if not (mat:=bpy.data.materials.get(mat_name)):
		print(f"错误：材质 {mat_name} 未找到")
		return False
	node_tree=mat.node_tree
	nodes=node_tree.nodes
	rel_nodes=[n.name for n in nodes if n.bl_idname in convertable_shaders]
	for t_name in rel_nodes:
		if not (tnode:=nodes.get(t_name)):
			continue #Couldn't find this one,skip
		if len(tnode.outputs[0].links)==0:
			continue
		pnode=nodes.new(type='ShaderNodeBsdfPrincipled')
		pnode.location=tnode.location
		if tnode.bl_idname=="ShaderNodeBsdfDiffuse":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			process_socket(t_name,"Roughness",pnode.name,"Roughness",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeBsdfGlass":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			process_socket(t_name,"Roughness",pnode.name,"Roughness",nodes,node_tree)
			process_socket(t_name,"IOR",pnode.name,"IOR",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			pnode.inputs["Transmission Weight"].default_value=1.0
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeBsdfAnisotropic":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			process_socket(t_name,"Roughness",pnode.name,"Roughness",nodes,node_tree)
			process_socket(t_name,"Anisotropy",pnode.name,"Anisotropic",nodes,node_tree)
			process_socket(t_name,"Rotation",pnode.name,"Anisotropic Rotation",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			process_socket(t_name,"Tangent",pnode.name,"Tangent",nodes,node_tree)
			pnode.inputs["Metallic"].default_value=1.0
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeEmission":
			process_socket(t_name,"Color",pnode.name,"Emission Color",nodes,node_tree)
			process_socket(t_name,"Strength",pnode.name,"Emission Strength",nodes,node_tree)
			pnode.inputs["Base Color"].default_value=(0,0,0,1)
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeBsdfTransparent":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			pnode.inputs["Alpha"].default_value=0
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeSubsurfaceScattering":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			process_socket(t_name,"Scale",pnode.name,"Subsurface Scale",nodes,node_tree)
			process_socket(t_name,"Radius",pnode.name,"Subsurface Radius",nodes,node_tree)
			process_socket(t_name,"IOR",pnode.name,"IOR",nodes,node_tree)
			process_socket(t_name,"Roughness",pnode.name,"Roughness",nodes,node_tree)
			process_socket(t_name,"Anisotropy",pnode.name,"Subsurface Anisotropy",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			pnode.inputs["Subsurface Weight"].default_value=1
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeBsdfRefraction":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			process_socket(t_name,"Roughness",pnode.name,"Roughness",nodes,node_tree)
			process_socket(t_name,"IOR",pnode.name,"IOR",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			pnode.inputs["Transmission Weight"].default_value=1.0
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeBsdfToon":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			pnode.inputs["Roughness"].default_value=1.0
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeBsdfTranslucent":
			process_socket(t_name,"Color",pnode.name,"Emission Color",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			pnode.inputs["Subsurface Weight"].default_value=1.0
			pnode.inputs["Subsurface Radius"].default_value=(1,1,1)
			to_del.append(t_name)
		if tnode.bl_idname=="ShaderNodeBsdfSheen":
			process_socket(t_name,"Color",pnode.name,"Base Color",nodes,node_tree)
			process_socket(t_name,"Roughness",pnode.name,"Sheen Roughness",nodes,node_tree)
			process_socket(t_name,"Roughness",pnode.name,"Roughness",nodes,node_tree)
			process_socket(t_name,"Normal",pnode.name,"Normal",nodes,node_tree)
			pnode.inputs["Sheen Weight"].default_value=1.0
			pnode.inputs["Roughness"].default_value=1.0
			to_del.append(t_name)
		for name in to_del:
			if (n:=nodes.get(name)):
				output_dest_socket=n.outputs[0].links[0].to_socket
				node_tree.links.new(pnode.outputs[0],output_dest_socket)
				nodes.remove(n)
	return True
class SimpleBake_OT_PBR_Pre_Bake(Operator):
	"""主备份和删除节点组"""
	bl_idname="simplebake.pbr_pre_bake";bl_label=g("Pre bake for PBR (remove node groups)")
	override_target_object_name: StringProperty(default="")
	def pop_node_group(self,context,mat_name):
		material=bpy.data.materials[mat_name]
		node_tree=material.node_tree
		found_object=None
		for obj in context.scene.objects:
			if material.name in [slot.material.name for slot in obj.material_slots if slot.material]:
				found_object=obj
				break
		if not found_object:
			return False
		context.view_layer.objects.active=found_object
		for obj in context.selected_objects:
			obj.select_set(False)
		found_object.select_set(True)
		found_space=None
		found_area=None
		found_screen=None
		for screen in bpy.data.screens:
			for area in screen.areas:
				if area.type=='NODE_EDITOR':
					for space in area.spaces:
						if space.type=='NODE_EDITOR' and space.tree_type=='ShaderNodeTree':
							found_space=space
							found_screen=screen
							found_area=area
							break
					if found_space:
						break
			if found_space:
				break
		if not found_space or not found_area or not found_screen:
			return False
		found_space.node_tree=node_tree
		prefs=context.preferences.addons[base_package].preferences
		ungroup_all=prefs.ungroup_all_node_groups
		for n in list(node_tree.nodes):
			ss=[s for s in n.outputs if s.bl_idname=="NodeSocketShader"
				and len(s.links)>0]
			if n.bl_idname=="ShaderNodeGroup" and (len(ss)>0 or ungroup_all) and n.select==False:
				create_node_group_dummy_nodes(n,node_tree)
				n.select=True
			else:
				if n.select==True:
					n.select=False
		override_context={'area': found_area,'screen': found_screen,'space_data': found_space,'region': found_area.regions[-1],'window': context.window,'edit_tree': node_tree,'blend_data': context.blend_data,'scene': context.scene,'view_layer': context.view_layer,'active_object': found_object}
		with context.temp_override(**override_context):
			bpy.ops.node.group_ungroup()
		blender_refresh()
		return True
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		bpy.ops.simplebake.refresh_bake_object_list()
		if self.override_target_object_name !="":
			objs=[context.scene.objects[self.override_target_object_name]]
		else:
			objs=[l.obj_point for l in sbp.objects_list]
		for obj in objs:
			bpy.ops.simplebake.material_backup(target_object_name=obj.name,mode=MatManager.MODE_MASTER_BACKUP)
		force_to_object_mode(context)
		mats=[]
		for o in objs:
			for slot in o.material_slots:
				if slot.material !=None:
					mats.append(slot.material.name)
		mats=list(set(mats))
		result=False
		for m_name in mats:
			result=True if has_node_groups(context,m_name) else result
			result=True if has_convertible_shaders(m_name) else result
		if not result:
			print_message(context,"No node groups or convertible shaders are in play. Proceeding to bake")
			return{'FINISHED'}
		else:
			print_message(context,"Node groups or convertible shaders detected. Proceeding to remove them")
		for m_name in mats:
			mat=bpy.data.materials[m_name]
			while has_node_groups(context,m_name):
				self.pop_node_group(context,m_name)
		for m_name in mats:
			swap_shaders_for_p(m_name)
		return {'FINISHED'}
class SimpleBake_OT_PBR_Pre_Bake_Old(Operator):
	"""PBR的预烘焙操作(删除节点组"""
	bl_idname="simplebake.pbr_pre_bake_old";bl_label=g("Pre bake for PBR (remove node groups) OLD VERSION")
	_timer=None
	original_uitype=None
	slot_index=0
	object_index=0
	ready_to_bake=False
	@classmethod
	def go_to_bake(cls):
		pass
	def modal(self,context,event):
		sbp=context.scene.SimpleBake_Props
		if event.type=='TIMER':
			if self.__class__.ready_to_bake:
				wm=context.window_manager
				wm.event_timer_remove(self._timer)
				self.go_to_bake()
				return {'FINISHED'}
			if self.__class__.object_index > len(sbp.objects_list)-1:
				context.area.ui_type=self.__class__.original_uitype
				self.__class__.ready_to_bake=True
				return {'RUNNING_MODAL'}
			obj=sbp.objects_list[self.__class__.object_index].obj_point
			if context.active_object !=obj:
				select_only_this(context,obj)
				return {'RUNNING_MODAL'}
			l=len(obj.material_slots)
			if self.__class__.slot_index==l:
				self.__class__.slot_index=0
				self.__class__.object_index +=1
				print_message(context,f"Finished popping node groups for object '{obj.name}'")
				return {'RUNNING_MODAL'}
			elif obj.active_material_index==self.__class__.slot_index:
				mat=obj.material_slots[self.__class__.slot_index].material
				if mat==None:
					self.__class__.slot_index +=1
					return {'RUNNING_MODAL'}
				print_message(context,f"Popping node groups for material '{mat.name}' in slot {obj.active_material_index} on object '{obj.name}'")
				node_tree=mat.node_tree
				nodes=node_tree.nodes
				for node in nodes:
					node.select=False
				for node in nodes:
					if node.bl_idname=="ShaderNodeGroup":
						prefs=context.preferences.addons[base_package].preferences
						if prefs.ungroup_all_node_groups:
							ss=[True]
						else:
							ss=[s for s in node.outputs if s.bl_idname=="NodeSocketShader" and len(s.links)>0]
						if len(ss)>0:
							create_node_group_dummy_nodes(node,node_tree)
							node.select=True
							nodes.active=node
							bpy.ops.node.group_ungroup('INVOKE_DEFAULT')
							break
				if not has_node_groups(context,mat):
					self.__class__.slot_index +=1
				return {'RUNNING_MODAL'}
			else:
				obj.active_material_index=self.__class__.slot_index
				return {'RUNNING_MODAL'}
		return {'PASS_THROUGH'}
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		print_message(context,"Falling back to old method for ungrouping node groups (Blender 4.0 bug)")
		bpy.ops.simplebake.refresh_bake_object_list()
		force_to_object_mode(context)
		objs=[l.obj_point for l in sbp.objects_list]
		ngs_present=False
		for obj in objs:
			for slot in obj.material_slots:
				if slot.material !=None:
					if has_node_groups(context,slot.material.name):
						ngs_present=True
		for obj in objs:
			for slot in obj.material_slots:
				if slot.material !=None:
					if "SB_master_dup" in slot.material: del slot.material["SB_master_dup"]
		for obj in objs:
			bpy.ops.simplebake.material_backup(target_object_name=obj.name,mode=MatManager.MODE_MASTER_BACKUP)
		if not ngs_present:
			print_message(context,"No node groups are in play. Proceeding to bake")
			self.go_to_bake()
			return{'FINISHED'}
		print_message(context,"Going to process materials to remove node groups")
		self.__class__.original_uitype=context.area.ui_type
		self.__class__.slot_index=0
		self.__class__.object_index=0
		self.__class__.ready_to_bake=False
		context.area.ui_type="ShaderNodeTree"
		wm=context.window_manager
		self._timer=wm.event_timer_add(0.1,window=context.window)
		wm.modal_handler_add(self)
		return {'RUNNING_MODAL'}
class SimpleBake_OT_Invert_Roughness_To_Glossy(Operator):
	"""所有烘焙类型共享的准备工作"""
	bl_idname="simplebake.invert_roughness_to_glossy";bl_description="反转粗糙度映射以创建光泽映射";bl_label=g("Invert")
	bake_operation_id: StringProperty()
	bake_mode: StringProperty(default="")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		print_message(context,"Creating glossy image from roughness")
		input_images=([i for i in bpy.data.images if
			"SB_bake_operation_id" in i and
			i["SB_bake_operation_id"]==self.bake_operation_id and
			(("SB_glossy_converted" in i and i["SB_glossy_converted"]==False) or
			"SB_glossy_converted" not in i) and
			"SB_this_bake" in i and i["SB_this_bake"]==SBConstants.PBR_GLOSSY])
		if self.bake_mode !="":
			input_images=[i for i in input_images if "SB_this_bake" in i and i["SB_this_bake"]==self.bake_mode]
		if len(input_images)==0:
			return {'FINISHED'}
		for input_image in input_images:
			external_path=input_image.filepath
			tiled=True if "<UDIM>" in external_path else False
			if tiled:
				tiles_nums=[t.number for t in input_image.tiles]
				for tile_num in tiles_nums:
					i=bpy.data.images.load(external_path.replace("<UDIM>",str(tile_num)))
					i.colorspace_settings.name=input_image.colorspace_settings.name
					w,h=i.size
					pixel_data=np.zeros((w,h,4),'f')
					i.pixels.foreach_get(pixel_data.ravel())
					pixel_data[:,:,:3]=1.0 - pixel_data[:,:,:3]
					i.pixels.foreach_set(pixel_data.ravel())
					i.update()
					i.save()
					bpy.data.images.remove(i)
			else:
				w,h=input_image.size
				pixel_data=np.zeros((w,h,4),'f')
				input_image.pixels.foreach_get(pixel_data.ravel())
				pixel_data[:,:,:3]=1.0 - pixel_data[:,:,:3]
				input_image.pixels.foreach_set(pixel_data.ravel())
				input_image.save()
			input_image.update()
			input_image["SB_glossy_converted"]=True
		return {'FINISHED'}
class SimpleBake_OT_Create_Directx_Normal(Operator):
	"""所有烘焙类型共享的准备工作"""
	bl_idname="simplebake.create_directx_normal";bl_description="翻转Y以创建DirectX法向映射";bl_label=g("Create")
	bake_operation_id: StringProperty()
	bake_mode: StringProperty(default="")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		print_message(context,"Creating DirectX normal maps")
		input_images=([i for i in bpy.data.images if
			"SB_bake_operation_id" in i and
			i["SB_bake_operation_id"]==self.bake_operation_id and
			(("SB_directx_converted" in i and i["SB_directx_converted"]==False) or
			"SB_directx_converted" not in i) and
			"SB_this_bake" in i and i["SB_this_bake"]==SBConstants.PBR_NORMAL])
		if self.bake_mode !="":
			input_images=[i for i in input_images if "SB_this_bake" in i and i["SB_this_bake"]==self.bake_mode]
		if len(input_images)==0:
			return {'FINISHED'}
		print_message(context,f"DirectX conversation needed for {input_images}")
		for input_image in input_images:
			external_path=input_image.filepath
			tiled=True if "<UDIM>" in external_path else False
			if tiled:
				tiles_nums=[t.number for t in input_image.tiles]
				for tile_num in tiles_nums:
					i=bpy.data.images.load(external_path.replace("<UDIM>",str(tile_num)))
					i.colorspace_settings.name=input_image.colorspace_settings.name
					w,h=i.size
					pixel_data=np.zeros((w,h,4),'f')
					i.pixels.foreach_get(pixel_data.ravel())
					pixel_data[:,:,1]=1.0 - pixel_data[:,:,1]
					i.pixels.foreach_set(pixel_data.ravel())
					i.save()
					bpy.data.images.remove(i)
			else:
				w,h=input_image.size
				pixel_data=np.zeros((w,h,4),'f')
				input_image.pixels.foreach_get(pixel_data.ravel())
				pixel_data[:,:,1]=1.0 - pixel_data[:,:,1]
				input_image.pixels.foreach_set(pixel_data.ravel())
				input_image.save()
			input_image.update()
			input_image["SB_directx_converted"]=True
		return {'FINISHED'}
class SimpleBake_OT_PBR_Specific_Bake_Prep_And_Finish(Operator):
	"""PBR烘焙的准备和精加工"""
	bl_idname="simplebake.pbr_specific_bake_prep_and_finish";bl_description="PBR烘焙类型的准备或完成";bl_label=g("Prepare or Finish")
	mode: StringProperty()
	orig_sample_count=0
	def finish(self,context):
		context.scene.cycles.samples=self.__class__.orig_sample_count
	def prepare(self,context):
		sbp=context.scene.SimpleBake_Props
		self.__class__.orig_sample_count=context.scene.cycles.samples        
		if not sbp.selected_s2a:
			context.scene.render.bake.use_selected_to_active=False
	def execute(self,context):
		if self.mode=="prepare":
			self.prepare(context)
		elif self.mode=="finish":
			self.finish(context)
		return {'FINISHED'}
class SimpleBake_OT_Remove_Reroutes(Operator):
	bl_idname="simplebake.remove_reroutes";bl_label=g("Remove")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		bpy.ops.simplebake.refresh_bake_object_list()
		force_to_object_mode(context)
		objs=[l.obj_point for l in sbp.objects_list]
		for obj in objs:
			for matslot in obj.material_slots:
				mat=matslot.material
				print_message(context,f"Removing reroute nodes for material {mat.name}")
				node_tree=mat.node_tree
				nodes=node_tree.nodes
				reroute_nodes=[n for n in nodes if n.bl_idname=="NodeReroute"]
				for node in reroute_nodes:
					if len(node.inputs[0].links)==0:
						nodes.remove(node)
						continue
					origin_socket=node.inputs[0].links[0].from_socket
					output_links=[l for l in node.outputs[0].links]
					for l in output_links:
						dest_socket=l.to_socket
						node_tree.links.new(origin_socket,dest_socket)
				[nodes.remove(n) for n in nodes if n.bl_idname=="NodeReroute"]
		return {'FINISHED'}
class SimpleBake_OT_Multiply_AO(Operator):
	"""环境遮蔽多重扩散"""
	bl_idname="simplebake.multiply_ao";bl_description="将漫反射乘以环境遮蔽";bl_label=g("Multiply")
	bake_operation_id: StringProperty()
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		diffuse_images=[i for i in bpy.data.images  if 	"SB_bake_operation_id" in i  and i["SB_bake_operation_id"]==self.bake_operation_id  and 	"SB_this_bake" in i  and i["SB_this_bake"]==SBConstants.PBR_DIFFUSE]
		ao_images=[i for i in bpy.data.images  if 	"SB_bake_operation_id" in i  and i["SB_bake_operation_id"]==self.bake_operation_id  and 	"SB_this_bake" in i  and i["SB_this_bake"]==SBConstants.AO]
		paired={}
		for d in diffuse_images:
			o=d["SB_bake_object"]
			matched=[a for a in ao_images if "SB_bake_object" in a and a["SB_bake_object"]==o]
			assert(len(matched)==1),f"Didn't find exactly one matching AO image for {d.name}"
			paired[d]=matched[0]
		path=os.path.dirname(__file__) + "/../resources/multiply.blend/Scene/"
		if "SBCompositing_Multiply" in bpy.data.scenes:
			bpy.data.scenes.remove(bpy.data.scenes["SBCompositing_Multiply"])
		bpy.ops.wm.append(filename="SBCompositing_Multiply",directory=path)
		s=bpy.data.scenes["SBCompositing_Multiply"]
		s.render.resolution_x=diffuse_images[0].size[0]
		s.render.resolution_y=diffuse_images[0].size[1]
		nodes=s.node_tree.nodes
		for d in paired:
			s.render.image_settings.file_format=d.file_format
			s.render.image_settings.color_depth=d["SB_bit_depth"]
			s.render.image_settings.color_mode=d["SB_channels"]
			s.view_settings.view_transform=d["SB_view_transform"]
			tiles_nums=[t.number for t in d.tiles]
			for tile_num in tiles_nums:
				path_d=d.filepath.replace("<UDIM>",str(tile_num))
				path_ao=paired[d].filepath.replace("<UDIM>",str(tile_num))
				img_d=bpy.data.images.load(path_d.replace("<UDIM>",str(tile_num)))
				img_ao=bpy.data.images.load(path_ao.replace("<UDIM>",str(tile_num)))
				nodes["Base"].image=img_d
				nodes["Multiplant"].image=img_ao
				bpy.ops.render.render(use_viewport=False,scene=s.name)
				render_result_image=bpy.data.images["Render Result"]
				if os.path.exists(bpy.path.abspath(path_d)):
					os.remove(bpy.path.abspath(path_d))
				path_d=bpy.path.abspath(path_d)
				render_result_image.save_render(path_d.replace("<UDIM>",str(tile_num)),scene=s)
				bpy.data.images.remove(img_d)
				bpy.data.images.remove(img_ao)
			d.reload() #We've updated 1 or more tiles and Blender still has them in the buffer'
			d.save()
		[bpy.data.scenes.remove(s) for s in bpy.data.scenes if s.name=="SBCompositing_Multiply"]
		return {'FINISHED'}
class SimpleBake_OT_autodetect_pbr_channels(Operator):
	bl_idname="simplebake.autodetect_pbr_channels";bl_label=g("Autodetect");bl_description="尝试根据应用于选定烘焙物体的材质来识别必要的映射。如果您的材质杂乱无章(例如,断开连接的节点未连接到材质输出),则可能会建议使用比所需更多的映射。它不应该建议比必要的映射少"
	default_values={"Base Color": (0.8,0.8,0.8,1),"Metallic": 0.0,"Roughness": 0.5,"Alpha": 1.0,"Subsurface Weight": 0.0,"Transmission Weight": 0.0,"Coat Weight": 0.0,"Coat Roughness": 0.0,"Emission Color": (1,1,1,1),"Emission Strength": 0.0,"Specular IOR Level": 0.5}
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		bpy.ops.simplebake.sidestep_geo_nodes()
		bpy.ops.simplebake.selectnone_pbr()
		o_names=object_list_to_names_list(context)
		bpy.ops.simplebake.pbr_pre_bake()
		if sbp.selected_s2a and sbp.targetobj!=None and sbp.s2a_opmode=="decals":
			bpy.ops.simplebake.pbr_pre_bake(override_target_object_name=sbp.targetobj.name)
			o_names.append(sbp.targetobj.name)
		mat_names=[]
		for name in o_names:
			o=context.scene.objects.get(name)
			if o!=None:
				for slot in o.material_slots:
					if slot.material !=None:
						mat_names.append(slot.material.name)
		found_socket_names=[]
		def check_node_tree(node_tree):
			nodes=node_tree.nodes
			for n in nodes:
				if n.bl_idname=="ShaderNodeGroup":
					check_node_tree(n.node_tree)
				if n.bl_idname=="ShaderNodeBsdfPrincipled" and len(n.outputs[0].links)>0:
					for i in n.inputs:
						if len(i.links)>0:
							test=None
							from_n=i.links[0].from_node
							if i.bl_idname in ["NodeSocketFloatFactor","NodeSocketFloat"]:
								if from_n.bl_idname=="ShaderNodeValue":
									test=round(from_n.outputs[0].default_value,1)
							if i.bl_idname=="NodeSocketColor":
								if from_n.bl_idname=="ShaderNodeRGB":
									dv=from_n.outputs[0].default_value
									test=(round(dv[0],1),round(dv[1],1),round(dv[2],1),round(dv[3],1))
							if test!=None and i.name in self.default_values and test==self.default_values[i.name]:
								pass
							else:
								found_socket_names.append(i.name)
						else:
							test=None
							if i.bl_idname=="NodeSocketColor":
								dv=i.default_value
								test=(round(dv[0],1),round(dv[1],1),round(dv[2],1),round(dv[3],1))
							elif i.bl_idname in ["NodeSocketFloatFactor","NodeSocketFloat"]:
								test=round(i.default_value,1)
							if test!=None and i.name in self.default_values and test !=self.default_values[i.name]:
								found_socket_names.append(i.name)
				if n.bl_idname=="ShaderNodeBump" and len(n.outputs[0].links)>0:
					found_socket_names.append("Bump")
		for name in mat_names:
			m=bpy.data.materials.get(name)
			if m!=None:
				check_node_tree(m.node_tree)
				mos=[n for n in m.node_tree.nodes if n.bl_idname=="ShaderNodeOutputMaterial" and n.is_active_output==True]
				for mo in mos:
					if len(mo.inputs["Displacement"].links)>0:
						found_socket_names.append("Displacement")
		sbp.selected_col=True if "Base Color" in found_socket_names else sbp.selected_col
		sbp.selected_metal=True if "Metallic" in found_socket_names else sbp.selected_metal
		sbp.selected_rough=True if "Roughness" in found_socket_names else sbp.selected_rough
		sbp.selected_trans=True if "Transmission Weight" in found_socket_names else sbp.selected_trans
		sbp.selected_clearcoat=True if "Coat Weight" in found_socket_names else sbp.selected_clearcoat
		sbp.selected_clearcoat_rough=True if "Coat Roughness" in found_socket_names else sbp.selected_clearcoat_rough
		sbp.selected_emission=True if "Emission Color" in found_socket_names else sbp.selected_emission
		sbp.selected_emission_strength=True if "Emission Strength" in found_socket_names else sbp.selected_emission_strength
		sbp.selected_specular=True if "Specular IOR Level" in found_socket_names else sbp.selected_specular
		sbp.selected_sss=True if "Subsurface Weight" in found_socket_names else sbp.selected_sss
		sbp.selected_alpha=True if "Alpha" in found_socket_names else sbp.selected_alpha
		sbp.selected_normal=True if "Normal" in found_socket_names else sbp.selected_normal
		sbp.selected_bump=True if "Bump" in found_socket_names else sbp.selected_bump
		sbp.selected_displacement=True if "Displacement" in found_socket_names else sbp.selected_displacement
		bpy.ops.simplebake.material_backup(mode="working_restore")
		bpy.ops.simplebake.material_backup(mode="master_restore")
		bpy.ops.simplebake.reverse_geo_nodes_sidestep()
		return {'FINISHED'}
class SimpleBake_OT_Sidestep_Geo_Nodes(Operator):
	bl_idname="simplebake.sidestep_geo_nodes";bl_label=g("Go");bl_description="用应用代理的几何节点替换物体"
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		object_names=[i.name for i in sbp.objects_list]
		if sbp.selected_s2a and sbp.targetobj !=None:
			object_names.append(sbp.targetobj.name)
			sbp.targetobj["SB_sidestepd_orig_target"]=True
		if sbp.cycles_s2a and sbp.targetobj_cycles !=None:
			object_names.append(sbp.targetobj_cycles.name)
			sbp.targetobj_cycles["SB_sidestepd_orig_target"]=True
		print_message(context,f"Sidestep operation called for:")
		for i in object_names:
			print_message(context,i)
		new_objects=[]
		for obj_name in object_names:
			obj=bpy.data.objects.get(obj_name)
			if not obj:
				continue
			geo_modifiers=[mod for mod in obj.modifiers if mod.type=='NODES']
			if not geo_modifiers:
				continue
			orig_name=obj.name
			i=sbp.objects_list.find(orig_name)
			if i!=-1:
				sbp.objects_list.remove(i)
			new_obj=obj.copy()
			new_obj.data=obj.data.copy()
			bpy.context.collection.objects.link(new_obj)
			obj.hide_render=True
			new_obj["SB_proxy_bake_object"]=orig_name
			obj["SB_replaced_orig_name"]=orig_name
			new_objects.append(new_obj)
			obj.name=f"SB_sidestepd"
			new_obj.name=orig_name
			if "SB_sidestepd_orig_target" not in new_obj:
				bpy.ops.simplebake.add_bake_object_by_name(override_target_obj_name=f"{new_obj.name}")
			else:
				if sbp.selected_s2a:
					sbp.targetobj=new_obj
				if sbp.cycles_s2a:
					sbp.targetobj_cycles=new_obj
			new_obj.hide_render=False
		for new_obj in new_objects:
			for mod in new_obj.modifiers:
				try:
					if mod.show_render:
						bpy.context.view_layer.objects.active=new_obj
						bpy.ops.object.modifier_apply(modifier=mod.name)
					else:
						new_obj.modifiers.remove(mod)
				except Exception as e:
					new_obj.modifiers.remove(mod)
		for new_obj in new_objects:
			materials_to_remove=[]
			for i,mat_slot in enumerate(new_obj.material_slots):
				material_used=False
				for poly in new_obj.data.polygons:
					if poly.material_index==i:
						material_used=True
						break
				if not material_used:
					materials_to_remove.append(i)
			override={'object': new_obj,'active_object': new_obj,'selected_objects': [new_obj],'selected_editable_objects': [new_obj],'window': bpy.context.window,'screen': bpy.context.screen,'area': None,'region': None}
			for area in bpy.context.screen.areas:
				if area.type=='PROPERTIES':
					override['area']=area
					for region in area.regions:
						if region.type=='WINDOW':
							override['region']=region
					for space in area.spaces:
						if space.type=='PROPERTIES' and space.context=='MATERIAL':
							override['space_data']=space
							break
					break
			for index in reversed(materials_to_remove):
				new_obj.active_material_index=index
				with bpy.context.temp_override(**override):
					bpy.ops.object.material_slot_remove()
		return {'FINISHED'}
class SimpleBake_OT_Reverse_Geo_Nodes_Sidestep(Operator):
	bl_idname="simplebake.reverse_geo_nodes_sidestep";bl_label=g("Go");bl_description="反转具有几何节点的物体的侧步"
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		to_del=[]
		for o in context.scene.objects:
			if "SB_proxy_bake_object" in o:
				i=sbp.objects_list.find(o.name)
				if i!=-1:
					sbp.objects_list.remove(i)
				o.name="SB_to_del"
				to_del.append(o.name)
		for o in context.scene.objects:
			if "SB_replaced_orig_name" in o:
				o.name=o["SB_replaced_orig_name"]
				if sbp.objects_list.find(o.name)==-1 and "SB_sidestepd_orig_target" not in o:
					bpy.ops.simplebake.add_bake_object_by_name(override_target_obj_name=f"{o.name}")
				o.hide_render=False
				del o["SB_replaced_orig_name"]
		for td in to_del:
			if o:=bpy.data.objects.get(td):
				bpy.data.objects.remove(o)
		for o in context.scene.objects:
			if "SB_sidestepd_orig_target" in o:
				sbp.targetobj=o
				del o["SB_sidestepd_orig_target"]
		return {'FINISHED'}
classes=([SimpleBake_OT_Invert_Roughness_To_Glossy,SimpleBake_OT_Create_Directx_Normal,SimpleBake_OT_PBR_Specific_Bake_Prep_And_Finish,SimpleBake_OT_PBR_Pre_Bake,SimpleBake_OT_PBR_Pre_Bake_Old,SimpleBake_OT_Remove_Reroutes,SimpleBake_OT_Multiply_AO,SimpleBake_OT_autodetect_pbr_channels,SimpleBake_OT_Sidestep_Geo_Nodes,SimpleBake_OT_Reverse_Geo_Nodes_Sidestep])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
