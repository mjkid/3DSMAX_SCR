from ..G import *
import bpy 
from bpy.utils import register_class,unregister_class
from bpy.types import Operator
from bpy.props import StringProperty
from ..utils import SBConstants
from ..messages import print_message
class SimpleBake_OT_CyclesBake_Specific_Bake_Prep_And_Finish(Operator):
	"""PBR烘焙的准备和精加工"""
	bl_idname="simplebake.cyclesbake_specific_bake_prep_and_finish";bl_description="烘焙类型循环的准备或完成";bl_label=g("Prepare or Finish")
	mode: StringProperty()
	orig_sample_count=0
	orig_object_render_vis={}
	def finish(self,context):
		print_message(context,"CyclesBake specific bake finishing actions")
		for obj in context.scene.objects:
			if obj.name in __class__.orig_object_render_vis:
				obj.hide_render=__class__.orig_object_render_vis[obj.name]
	def prepare(self,context):
		print_message(context,"CyclesBake specific bake prep actions")
		for obj in context.scene.objects:
			__class__.orig_object_render_vis[obj.name]=obj.hide_render
	def execute(self,context):
		if self.mode=="prepare":
			self.prepare(context)
		elif self.mode=="finish":
			self.finish(context)
		return {'FINISHED'}
classes=([SimpleBake_OT_CyclesBake_Specific_Bake_Prep_And_Finish])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
