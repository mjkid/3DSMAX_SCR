from .G import *
import bpy
from bpy.utils import register_class,unregister_class
from bpy.types import Operator
from bpy.props import StringProperty,BoolProperty
import os
from pathlib import Path
from zipfile import ZipFile
import webbrowser
from . import sketchfabapi
from .utils import get_base_folder_patho,clean_file_name,is_blend_saved
from .messages import print_message
def get_file_name():
	fullpath=bpy.data.filepath
	pathelements=os.path.split(fullpath)
	return pathelements[1]
class SimpleBake_OT_Sketchfab_Upload(Operator):
	"""将选定的简单烘焙生成的物体上传到Sketchfab"""
	bl_idname="simplebake.sketchfab_upload";bl_description="将选定的简单烘焙生成的物体上传到Sketchfab。必须保存Blend文件。您只能上传使用简单烘焙的“复制物体并应用烘焙”选项创建的物体。在视口中选择这些物体,然后单击上传";bl_label=g("Upload")
	@classmethod
	def poll(cls,context):
		if not is_blend_saved():
			return False
		if context.mode !="OBJECT":
			return False
		sbp=context.scene.SimpleBake_Props
		objs_list=context.selected_objects
		r=[o for o in objs_list if "SB_bake_operation_id" in o]
		if len(objs_list)==0: return False
		elif len(r)==len(objs_list): return True
		else: return False
	def execute(self,context):
		print_message(context,"Sketchfab Upload Beginning")
		objs_list=context.selected_objects
		images_imgs=[]
		for obj in objs_list:
			nodes=obj.material_slots[0].material.node_tree.nodes
			for node in nodes:
				if node.bl_idname=="ShaderNodeTexImage":
					images_imgs.append(node.image)
		f=get_base_folder_patho(context) / "SFUpload"
		if not os.path.isdir(str(f)):
			os.mkdir(str(f))
		writtenfilenames_strlist=[]
		for img in images_imgs:
			if img.filepath=="":
				img.file_format="PNG"
				img.filepath=str(f / clean_file_name(img.name)) + ".png"
				img.save()
				writtenfilenames_strlist.append(Path(img.filepath).parts[-1])
				img.filepath=""
			else:
				op=img.filepath
				off=img.file_format
				img.pack()
				img.file_format="PNG"
				img.filepath=str(f / clean_file_name(img.name)) + ".png"
				img.save()
				writtenfilenames_strlist.append(Path(img.filepath).parts[-1])
				img.unpack(method="REMOVE")
				img.filepath=op
				img.file_format=off
		bpy.ops.object.select_all(action="DESELECT")
		for obj in objs_list:
			obj.select_set(state=True)
		filename=get_file_name().replace(".blend","")
		bpy.ops.export_scene.fbx(filepath=str(f / f"{filename}.fbx"),check_existing=False,use_selection=True,use_mesh_modifiers=True,use_mesh_modifiers_render=True,path_mode="STRIP")
		zip_path=str(f / f"{filename}.zip")
		zip=ZipFile(str(zip_path),mode="w")
		for fn in writtenfilenames_strlist:
			zip.write(str(f / fn),arcname=fn)
		zip.write(str(f / f"{filename}.fbx"),arcname=f"{filename}.fbx")
		zip.close()
		preferences=context.preferences
		addon_prefs=preferences.addons[__package__].preferences
		apikey=addon_prefs.apikey
		upload_url=sketchfabapi.upload(zip_path,get_file_name(),apikey)
		if not upload_url:
			print_message(context,"Upload to Sketchfab failed. See console messages for details")
			return False
		else:
			webbrowser.open(upload_url,new=0,autoraise=True)
			print_message(context,"Upload complete. Your web broswer should have opened.")
		return {'FINISHED'}
classes=([SimpleBake_OT_Sketchfab_Upload])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
