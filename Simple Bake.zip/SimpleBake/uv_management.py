from .G import *
import bpy 
from bpy.utils import register_class,unregister_class
from bpy.types import Operator
from bpy.props import FloatProperty,EnumProperty,BoolProperty,StringProperty
from .utils import SBConstants,select_only_this
from .messages import print_message
from .bake_operators.common_bake_support import match_high_low_objects
def rearrange_uvs(obj):
	uvs=obj.data.uv_layers
	orig_active_name=uvs.active.name
	orig_active_render_name=[uv.name for uv in uvs if uv.active_render][0]
	while uvs[0].name !="SimpleBake":
		name=uvs[0].name
		uvs.active=uvs[0]
		uvs.new()
		uvs.remove(uvs[0])
		uvs[-1].name=name
	uvs.active=uvs[orig_active_name]
	uvs[orig_active_render_name].active_render=True
def pack_uvs(self,context):
	sbp=context.scene.SimpleBake_Props
	bpy.ops.uv.select_all(action="SELECT")
	if sbp.new_uv_method=="CombineExisting" and self.average_islands:
		bpy.ops.uv.average_islands_scale()
	n=int(''.join(c for c in bpy.app.version_string if c.isdigit()))
	if n >=360:
		bpy.ops.uv.pack_islands("EXEC_DEFAULT",udim_source=sbp.uvp_pack_to,rotate=sbp.uvp_rotate,rotate_method=sbp.uvp_rotation_method,scale=sbp.uvp_scale,merge_overlap=sbp.uvp_merge_overlapping,margin_method=sbp.uvp_margin_method,margin=sbp.uvpackmargin,pin=sbp.uvp_lock_pinned,pin_method=sbp.uvp_lock_method,shape_method=sbp.uvp_shape_method)
	else:
		bpy.ops.uv.pack_islands(rotate=True,margin=sbp.uvpackmargin)
	bpy.ops.object.mode_set(mode="OBJECT",toggle=False)
class SimpleBake_OT_Process_UVs(Operator):
	"""开始烘焙操作"""
	bl_idname="simplebake.process_uvs";bl_description="在烘焙物体上准备UV映射";bl_label=g("Prepare UVs")
	pbrtarget_only: BoolProperty(default=False)
	cyclesbake_target_only: BoolProperty(default=False)
	def smart_project_to_atlas(self,context):
		sbp=context.scene.SimpleBake_Props
		print_message(context,"Smart projecting all objects to atlas map")
		bpy.ops.object.select_all(action="DESELECT")
		for obj in self.bake_objects:
			obj.select_set(state=True)
		if context.active_object==None:
			context.view_layer.objects.active=self.bake_objects[0]
		for obj in self.bake_objects:
			if("SimpleBake" in obj.data.uv_layers):
				obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake"])
			obj.data.uv_layers.new(name="SimpleBake")
			obj.data.uv_layers["SimpleBake"].active=True
		bpy.ops.object.mode_set(mode="EDIT",toggle=False)
		bpy.ops.mesh.reveal()
		bpy.ops.mesh.select_all(action="SELECT")
		bpy.ops.uv.smart_project(island_margin=self.island_margin,correct_aspect=self.uvcorrectaspect)
		bpy.ops.object.mode_set(mode="OBJECT",toggle=False)
		return
	def combine_existing_to_atlas(self,context):
		sbp=context.scene.SimpleBake_Props
		print_message(context,"Combining existing UVs into atlas map")
		bpy.ops.object.select_all(action="DESELECT")
		for obj in self.bake_objects:
			obj.select_set(state=True)
		if context.active_object==None:
			context.view_layer.objects.active=self.bake_objects[0]
		for obj in self.bake_objects:
			if("SimpleBake" in obj.data.uv_layers):
				obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake"])
			obj.data.uv_layers.new(name="SimpleBake")
			obj.data.uv_layers["SimpleBake"].active=True
		bpy.ops.object.mode_set(mode="EDIT",toggle=False)
		bpy.ops.mesh.reveal()
		bpy.ops.mesh.select_all(action="SELECT")
		pack_uvs(self,context)
		bpy.ops.object.mode_set(mode="OBJECT",toggle=False)
		return
	def smart_project_individual_objects(self,context):
		print_message(context,"Smart projecting each object individually")
		for obj in self.bake_objects:
			select_only_this(context,obj)
			if("SimpleBake" in obj.data.uv_layers):
				obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake"])
			obj.data.uv_layers.new(name="SimpleBake")
			obj.data.uv_layers["SimpleBake"].active=True
			bpy.ops.object.mode_set(mode="EDIT",toggle=False)
			bpy.ops.mesh.reveal()
			bpy.ops.mesh.select_all(action="SELECT")
			bpy.ops.uv.smart_project(island_margin=self.island_margin,correct_aspect=self.uvcorrectaspect)
			bpy.ops.object.mode_set(mode="OBJECT",toggle=False)
		return
	def per_mat_smart_project_to_bounds(self,context):
		print_message(context,"Smart projecting the UVs for each material into new UV map")
		bpy.ops.object.select_all(action="DESELECT")
		for obj in self.bake_objects:
			if("SimpleBake" in obj.data.uv_layers):
				obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake"])
			obj.data.uv_layers.new(name="SimpleBake")
			obj.data.uv_layers["SimpleBake"].active=True
			obj.select_set(state=True)
			select_only_this(context,obj)
			bpy.ops.object.mode_set(mode='EDIT',toggle=False)
			bpy.ops.mesh.reveal()
			i=0
			for slot in obj.material_slots:
				obj.active_material_index=i
				bpy.ops.mesh.select_all(action="DESELECT")
				bpy.ops.object.material_slot_select()
				bpy.ops.uv.smart_project(island_margin=self.island_margin,correct_aspect=self.uvcorrectaspect)
				i +=1
			bpy.ops.object.mode_set(mode='OBJECT',toggle=False)
		return
	def check_prefer_sb_maps(self,context):
		if self.prefer_sb_uv_maps:
			print_message(context,"Preferring existing UV maps called SimpleBake. Setting them to active")
			for obj in self.bake_objects:
				if("SimpleBake" in obj.data.uv_layers):
					obj.data.uv_layers["SimpleBake"].active=True
		return
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		self.island_margin=sbp.unwrapmargin
		self.uvcorrectaspect=sbp.uvcorrectaspect
		self.average_islands=sbp.average_uv_size
		self.prefer_sb_uv_maps=sbp.prefer_existing_sbmap
		self.new_uv_option=sbp.new_uv_option
		self.new_uv_method=sbp.new_uv_method
		self.expand_mat_uvs=sbp.expand_mat_uvs
		self.uvpackmargin=sbp.uvpackmargin
		if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
			from .bake_operators.auto_match_operators import SimpleBake_OT_AutoMatch_Operation as bo
			hl_matches=bo.hl_matches
			self.bake_objects=[context.scene.objects[name] for name in hl_matches.keys()]
		elif self.pbrtarget_only:
			self.bake_objects=[sbp.targetobj]
		elif self.cyclesbake_target_only:
			self.bake_objects=[sbp.targetobj_cycles]
		else:
			self.bake_objects=[i.obj_point for i in sbp.objects_list]
		if self.new_uv_option and len(self.bake_objects)==1:
			self.smart_project_individual_objects(context)
		elif self.new_uv_option and self.new_uv_method==SBConstants.NEWUV_SMART_INDIVIDUAL:
			self.smart_project_individual_objects(context)
		elif self.new_uv_option and self.new_uv_method==SBConstants.NEWUV_SMART_ATLAS:
			self.smart_project_to_atlas(context)
		elif self.new_uv_option and self.new_uv_method==SBConstants.NEWUV_COMBINE_EXISTING:
			self.combine_existing_to_atlas(context)
		elif not self.new_uv_option:
			print_message(context,"We are working with existing UV maps")
			self.check_prefer_sb_maps(context)
		else:
			print_message(context,"Something went wrong processing UVs")
		for obj in self.bake_objects:
			obj["SB_uv_used_for_bake"]=obj.data.uv_layers.active.name
			if self.new_uv_option and sbp.move_new_uvs_to_top:
				rearrange_uvs(obj)
		return {'FINISHED'}
classes=([SimpleBake_OT_Process_UVs])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
