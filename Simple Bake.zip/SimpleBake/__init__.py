bl_info={"name":"🧇 简单烘焙 (Simple Bake)","author":"Lewis 汉化：GJJ <www.toohey.co.uk/SimpleBake/support/> 汉化：GJJ","version":(1,7,7),"blender":(3,0,0),"location":"【3D视图】>【N面板】>【🧇】","description":"PBR和其他纹理的简单烘焙","warning":"","wiki_url":"","tracker_url":"","category":"Bake",}
import bpy
from .G import *
from bpy.utils import register_class,unregister_class
from . import object_preperation,image_management,material_management,external_save,property_group,uv_management,copy_and_apply,starting_checks,utils,background_and_progress,channel_packing,channel_packing_old,cleanup
try:
	from . import auto_update
except:
	auto_update=None
from . import presets,presets_local,sketchfab_upload,messages,auto_cage,ui,bake_operators
import platform,sys
from pathlib import Path
if auto_update !=None:
	from .auto_update import VersionControl
else:
	VersionControl=None
classes=([])
def register():
	RGI()
	global classes
	for cls in classes:
		register_class(cls)
	object_preperation.register()
	image_management.register()
	material_management.register()
	external_save.register()
	property_group.register()
	ui.register()
	uv_management.register()
	copy_and_apply.register()
	bake_operators.register()
	starting_checks.register()
	utils.register()
	background_and_progress.register()
	channel_packing.register()
	channel_packing_old.register()
	if auto_update!=None:
		auto_update.register()
	presets.register()
	presets_local.register()
	sketchfab_upload.register()
	messages.register()
	auto_cage.register()
	cleanup.register()
	prefs=bpy.context.preferences.addons[__package__].preferences
	version=bl_info["version"]
	if VersionControl !=None:
		VersionControl.installed_version=version
		no_online_check=False
		if prefs.no_update_check:
			no_online_check=True
		VersionControl.check_at_current_version(no_online_check)
	from .ui.panel import UPG;UPG(None,bpy.context)
def unregister():
	UGI()
	global classes
	for cls in classes:
		unregister_class(cls)
	object_preperation.unregister()
	image_management.unregister()
	material_management.unregister()
	external_save.unregister()
	property_group.unregister()
	ui.unregister()
	uv_management.unregister()
	copy_and_apply.unregister()
	bake_operators.unregister()
	starting_checks.unregister()
	utils.unregister()
	background_and_progress.unregister()
	channel_packing.unregister()
	channel_packing_old.unregister()
	if auto_update !=None:
		auto_update.unregister()
	presets.unregister()
	presets_local.unregister()
	sketchfab_upload.unregister()
	messages.unregister()
	auto_cage.unregister()
	cleanup.unregister()
