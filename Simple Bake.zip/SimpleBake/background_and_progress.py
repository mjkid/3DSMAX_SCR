from .G import *
import bpy
from bpy.props import StringProperty,BoolProperty,IntProperty
from bpy.utils import register_class,unregister_class
from bpy.types import Operator
import os,signal,uuid,tempfile,subprocess,sys
from pathlib import Path
from .utils import show_message_box,force_to_object_mode,SBConstants,pbr_selections_to_list,specials_selection_to_list
class BakeInProgress:
	is_baking=False
	was_error=False
	running_sequence=False
	running_sequence_last=False
	running_sequence_first=False
	sequence_frames=0
class BackgroundBakeTasks:
	active_tasks=[]
	completed_tasks=[]
	queued_tasks=[]
	@classmethod
	def get_completed_or_active_bgt_by_pid(cls,pid):
		pid=int(pid)
		match=[t for t in cls.completed_tasks if t.pid==pid]
		if len(match)==0:
			match=[t for t in cls.active_tasks if t.pid==pid]
		assert(len(match)>0)
		match=match[0]
		return match
	@classmethod
	def get_queued_bgt_by_id(cls,id):
		match=[t for t in cls.queued_tasks if t.id==id]
		assert(len(match)==1)
		match=match[0]
		return match
	@classmethod
	def get_bgbake_status(cls,active_bgbake):
		sbp=bpy.context.scene.SimpleBake_Props
		pid=active_bgbake.pid
		path=Path(sbp.bgbake_temp_dir) / "progress" / str(pid)
		try:
			with open(str(path),"r") as progfile:
				progress=int(progfile.readline())
		except:
			progress=0
		active_bgbake.progress=progress
		if progress==100:
			cls.completed_tasks.append(active_bgbake)
			cls.active_tasks.remove(active_bgbake)
			cls.next_please()
		return progress
	@classmethod
	def next_please(cls):
		if len(cls.active_tasks)==0 and len(cls.queued_tasks) > 0:
			t=cls.queued_tasks[0]
			cls.active_tasks.append(t)
			cls.queued_tasks.remove(t)
			t.spawn_bg_process()
			return 2
		elif len(cls.active_tasks)==0 and len(cls.queued_tasks)==0:
			return None
		else:
			if len(cls.active_tasks)>0:
				active_bgt=cls.active_tasks[0]
				cls.get_bgbake_status(active_bgt)
			return 2
	def save_file_copy(self):
		sbp=bpy.context.scene.SimpleBake_Props
		unique_id=str(uuid.uuid4())[0:7]
		tmp_dir_path=Path(sbp.bgbake_temp_dir)
		if not os.path.exists(str(tmp_dir_path)):
				os.makedirs(str(tmp_dir_path))
		save_path=tmp_dir_path / (unique_id + ".blend")
		[i.pack() for i in bpy.data.images if i.is_dirty]
		bpy.ops.wm.save_as_mainfile(filepath=str(save_path),check_existing=False,copy=True)
		self.initial_save_path=save_path
		return True
	def spawn_bg_process(self):
		sbp=bpy.context.scene.SimpleBake_Props
		tmp_dir_path=sbp.bgbake_temp_dir
		base_folder_override=Path(bpy.data.filepath).parent.as_posix()
		args=[bpy.app.binary_path]
		if not sbp.fake_background:
			args.append("--background")
		args.append(str(self.initial_save_path))
		args.append("--python-expr")
		args.append(f"""
import bpy;
import os;
from pathlib import Path;
prefs=bpy.context.preferences;
bpy.ops.preferences.addon_enable(module='SimpleBake');
allowed_addons=['io_anim_bvh','io_curve_svg','io_mesh_uv_layout','io_scene_fbx','io_scene_gltf2','cycles','pose_library','bl_pkg','SimpleBake'];
for addon in prefs.addons.keys():
	if addon not in allowed_addons:
		try:
			bpy.ops.preferences.addon_disable(module=addon)
			print(f"Disabled " + addon)
		except:
			print(f"Error when disabling addon " + addon)
orig_file_path=bpy.data.filepath;
savepath=str(Path('{tmp_dir_path}') / (str(os.getpid()) + '.blend'));
bpy.ops.wm.save_as_mainfile(filepath=str(savepath),check_existing=False);
os.remove(orig_file_path);
bpy.context.scene.SimpleBake_Props.bgbake_temp_dir='{tmp_dir_path}';
bpy.context.scene.SimpleBake_Props.base_folder_override='{base_folder_override}';
{self.start_command};
""")
		process=subprocess.Popen(args,shell=False)
		self.pid=process.pid
		self.file_path_po=Path(tmp_dir_path) / (str(process.pid) + ".blend")
		return True
	def __init__(self,name,copy_and_apply,start_command,bg_bake_id):
		sbp=bpy.context.scene.SimpleBake_Props
		bpy.app.timers.register(BackgroundBakeTasks.next_please,first_interval=2)
		self.start_command=start_command
		self.save_file_copy()
		self.progress=0
		if name=="": name="Untitled"
		self.name=name
		self.copy_and_apply=copy_and_apply
		self.bg_bake_id=bg_bake_id
		self.pid=0
		self.id=str(uuid.uuid4())
		self.__class__.queued_tasks.append(self)
class SimpleBake_OT_Import_BGBake(Operator):
	"""从背景导入烘焙纹理和物体"""
	bl_idname="simplebake.import_bgbake";bl_label=g("Import")
	pid: StringProperty()
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		bgt=BackgroundBakeTasks.get_completed_or_active_bgt_by_pid(self.pid)
		force_to_object_mode(context)
		b_img_names=[i.name for i in bpy.data.images]
		b_obj_names=[o.name for o in context.scene.objects]
		savepath=Path(sbp.bgbake_temp_dir) / (self.pid + ".blend")
		savepath=str(savepath) + "/Collection/"
		bpy.ops.wm.append(filename="SimpleBake_Bakes_Background",directory=savepath,use_recursive=False,active_collection=False)
		sbc=bpy.data.collections["SimpleBake_Bakes_Background"]
		sbc.name="SimpleBake_Bakes"
		context.scene.collection.children.link(sbc)
		del_list=[]
		for c in bpy.data.collections:
			if sbc.name in c.children:
				c.children.unlink(sbc)
				if len(c.children)==0:
					del_list.append(c.name)
		for name in del_list:
			c=bpy.data.collections.get(name)
			if c!=None:
				bpy.data.collections.remove(c)
		if not bgt.copy_and_apply:
			for obj in sbc.objects:
				bpy.data.objects.remove(obj)
			bpy.data.collections.remove(sbc)
		a_img_names=[i.name for i in bpy.data.images]
		a_obj_names=[o.name for o in context.scene.objects]
		message=[]
		message.append(f"Imported - {len(a_img_names) - len(b_img_names)} images")
		message.append(f"Imported - {len(a_obj_names) - len(b_obj_names)} objects")
		for name in b_img_names:
			if name + ".002" in a_img_names:
				bpy.data.images.remove(bpy.data.images[name])
				bpy.data.images[name + ".002"].name=name
			elif name + ".001" in a_img_names:
				bpy.data.images.remove(bpy.data.images[name])
				bpy.data.images[name + ".001"].name=name
		BackgroundBakeTasks.completed_tasks.remove(bgt)
		for obj in context.scene.objects:
			if "SB_BG_HIDE" in obj:
				l=obj["SB_BG_HIDE"]
				if bgt.bg_bake_id in l:
					obj.hide_set(True)
		show_message_box(context,message,"Import complete",icon='INFO')
		return{'FINISHED'}
class SimpleBake_OT_Delete_Queued_BGBake(Operator):
	"""删除排队的背景烘焙"""
	bl_idname="simplebake.delete_queued_bgbake";bl_label=g("Delete")
	id: StringProperty()
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		bgt=BackgroundBakeTasks.get_queued_bgt_by_id(self.id)
		BackgroundBakeTasks.queued_tasks.remove(bgt)
		return{'FINISHED'}
class SimpleBake_OT_Discard_BGBake(Operator):
	"""丢弃已完成的背景烘焙"""
	bl_idname="simplebake.discard_bgbake";bl_label=g("Discard")
	pid: StringProperty()
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		bgt=BackgroundBakeTasks.get_completed_or_active_bgt_by_pid(self.pid)
		pid=bgt.pid
		BackgroundBakeTasks.completed_tasks.remove(bgt)
		path=str(bgt.file_path_po)
		try:
			os.remove(path)
			os.remove(path.replace(".blend",".blend1"))
		except:
			pass
		return{'FINISHED'}
class SimpleBake_OT_Kill_Active_BGBake(Operator):
	"""消灭活动背景烘焙"""
	bl_idname="simplebake.kill_active_bgbake";bl_label=g("Kill")
	pid: StringProperty()
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		bgt=BackgroundBakeTasks.get_completed_or_active_bgt_by_pid(self.pid)
		pid=bgt.pid
		BackgroundBakeTasks.active_tasks.remove(bgt)
		try:
			os.kill(pid,signal.SIGTERM)
		except OSError:
			print(f"无法终点进程 {pid}")
		return{'FINISHED'}
class SimpleBake_OT_Update_Progress(Operator):
	bl_idname="simplebake.update_progress";bl_label=g("Update")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		print(f"进度更新 - {sbp.current_bake_image_number}")
		self.background=True if "--background" in sys.argv or sbp.fake_background else False
		sbp.current_bake_image_number+=1
		percent_complete=(sbp.current_bake_image_number/sbp.total_bake_images_number) *100
		percent_complete=round(percent_complete)
		sbp.percent_complete=percent_complete
		if self.background:
			path=Path(sbp.bgbake_temp_dir) / "progress"
			if not os.path.exists(str(path)):
				os.makedirs(str(path))
			pid=os.getpid()
			path=path / str(pid)
			with open(str(path),"w") as progfile:
				progfile.write(str(percent_complete))
		return{'FINISHED'}
class BakeProgress:
	def __init__(self,mode,objnum,hl_matches=None):
		sbp=bpy.context.scene.SimpleBake_Props
		t=0
		if mode==SBConstants.PBRS2A_DECALS:
			ps=len(pbr_selections_to_list(bpy.context))
			ss=len(specials_selection_to_list(bpy.context))
			t=(ps+ss) * 1
			t+=ps * 1
			sbp.total_bake_images_number=t
		if mode==SBConstants.PBR:
			ps=len(pbr_selections_to_list(bpy.context))
			print(f"得到 {ps} pbr烘焙")
			ss=len(specials_selection_to_list(bpy.context))
			print(f"得到 {ss} pbr烘焙")
			t=(ps + ss) * objnum
			print(f"Total of {t} based on {ps+ss} x {objnum}")
			sbp.total_bake_images_number=t
		if mode==SBConstants.PBRS2A:
			ps=len(pbr_selections_to_list(bpy.context))
			ss=len(specials_selection_to_list(bpy.context))
			o=1
			t=(ps + ss) * o
			sbp.total_bake_images_number=t
		if mode==SBConstants.CYCLESBAKE:
			cb=1
			ss=len(specials_selection_to_list(bpy.context))
			t=(cb + ss) * objnum
			sbp.total_bake_images_number=t
		if mode==SBConstants.CYCLESBAKE_S2A:
			cb=1
			ss=len(specials_selection_to_list(bpy.context))
			objnum=1
			t=(cb + ss) * objnum
			sbp.total_bake_images_number=t
		if mode in [SBConstants.PBRS2A_AUTOMATCH,SBConstants.CYCLESBAKES2A_AUTOMATCH]:
			ps=len(pbr_selections_to_list(bpy.context)) if mode==SBConstants.PBRS2A_AUTOMATCH else 1
			ss=len(specials_selection_to_list(bpy.context))
			t=len(hl_matches) * (ps + ss)
			sbp.total_bake_images_number=t
classes=([SimpleBake_OT_Update_Progress,SimpleBake_OT_Import_BGBake,SimpleBake_OT_Delete_Queued_BGBake,SimpleBake_OT_Kill_Active_BGBake,SimpleBake_OT_Discard_BGBake])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
