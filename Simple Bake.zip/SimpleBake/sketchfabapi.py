import json,os,bpy
from time import sleep
import requests
from .messages import print_message
SKETCHFAB_DOMAIN='sketchfab.com'
SKETCHFAB_API_URL='https://api.{}/v3'.format(SKETCHFAB_DOMAIN)
def _get_request_payload(apikey,data={},files={},json_payload=False):
	"""Helper method that returns the authentication token and proper content
	type depending on whether or not we use JSON payload."""
	headers={'Authorization': 'Token {}'.format(apikey)}
	if json_payload:
		headers.update({'Content-Type': 'application/json'})
		data=json.dumps(data)
	return {'data': data,'files': files,'headers': headers}
def upload(model_file,uploadname,apikey):
	"""POST a model to sketchfab.
	This endpoint only accepts formData as we upload a file.
	"""
	model_endpoint=SKETCHFAB_API_URL + '/models'
	print_message(bpy.context,f"Sketchfab URL is going to be: {model_endpoint}")
	name=uploadname
	description='上传至简单烘焙 for Blender'
	isPublished = False,
	data = {
		'name': name,
		'description': description,
		'isPublished': isPublished,
		'source': "simplebake-for-blender"
	}
	f=open(model_file,'rb')
	files={'modelFile': f}
	try:
		r=requests.post(model_endpoint,**_get_request_payload(apikey,data,files=files))
	except requests.exceptions.RequestException as e:
		print_message(bpy.context,'An error occured: {}'.format(e))
		return False
	finally:
		f.close()
	print_message(bpy.context,f"Status code from Sketchfab was {r.status_code}");
	if r.status_code !=requests.codes.created:
		print_message(bpy.context,'Upload failed with error: {}'.format(r.json()))
		return False
	model_url=r.headers['Location']
	return model_url.replace("https://api.sketchfab.com/v3/models/","https://sketchfab.com/3d-models/")
