from .G import *
import bpy
from bpy.props import (FloatProperty,StringProperty,BoolProperty,EnumProperty,PointerProperty,IntProperty,CollectionProperty,FloatVectorProperty)
from bpy.types import PropertyGroup
from bpy.utils import register_class,unregister_class
import os,getpass,tempfile
from pathlib import Path
from .utils import SBConstants,show_message_box,get_cs_list,select_only_this,disable_impossible
from . import __package__ as base_package
suppress_for_preset_load=False
class ObjectListItem(PropertyGroup):
	"""代表列表中某个项目的属性组"""
	obj_point:   PointerProperty(name="Bake Object",description="场景中要烘焙的物体",type=bpy.types.Object)
	name: StringProperty(name="Name",description="此项目的名称",default="Untitled")
class PresetItem(PropertyGroup):
	"""表示简单烘焙预设的属性组"""
	name: bpy.props.StringProperty(name="Name",description="此项目的名称",default="Untitled")
class CPTexItem(PropertyGroup):
	"""表示简单烘焙 CP纹理的属性组"""
	name: StringProperty(name="Name",description="此项目的名称",default="Untitled")
	R: StringProperty(name="R",description="R通道的烘焙类型")
	G: StringProperty(name="G",description="G通道烘焙类型")
	B: StringProperty(name="B",description="B通道烘焙类型")
	A: StringProperty(name="A",description="A通道的烘焙类型")
	file_format: StringProperty(name="File Format",description="CP纹理的文件格式")
	exr_codec: StringProperty()
	png_compression: IntProperty()
def auto_set_bake_margin(context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	multiplier=4
	current_width=sbp.imgwidth
	margin=(current_width / 1024) * multiplier
	margin=round(margin,0)
	context.scene.render.bake.margin=int(margin)
	return True
def selected_col_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.selected_col:
		sbp.apply_col_man_to_col=False
		sbp.multiply_diffuse_ao="purediffuse"
	disable_impossible(context)
def tex_per_mat_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.tex_per_mat==True:
		sbp.copy_and_apply=False
		sbp.hide_source_objects=False
		sbp.hide_cage_object=False
		sbp.expand_mat_uvs=False
	disable_impossible(context)
def expand_mat_uvs_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.expand_mat_uvs:
		sbp.new_uv_option=False
		sbp.prefer_existing_sbmap=False
	disable_impossible(context)
def copy_and_apply_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.copy_and_apply==False:
		sbp.hide_source_objects=False
		sbp.hide_cage_object=False
		sbp.create_glTF_node=False
	else:
		sbp.hide_source_objects=True
		sbp.hide_cage_object=True
		sbp.apply_bakes_to_original=False
		sbp.del_cptex_components=False
def apply_bakes_to_original_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.apply_bakes_to_original:
		sbp.copy_and_apply=False
		sbp.del_cptex_components=False
	disable_impossible(context)
def export_file_format_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.export_file_format=="JPEG" or sbp.export_file_format=="TARGA":
		sbp.everything_16bit=False
		sbp.use_alpha=False
	disable_impossible(context)
def save_bakes_external_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.save_bakes_external==False:
		sbp.everything_16bit=False
		sbp.export_folder_per_object=False
		sbp.cp_list.clear()
		sbp.rough_glossy_switch=SBConstants.PBR_ROUGHNESS
		sbp.normal_format_switch=SBConstants.NORMAL_OPENGL
	disable_impossible(context)
def new_uv_option_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.new_uv_option==True:
		sbp.prefer_existing_sbmap=False
		sbp.auto_detect_udims=False
	else:
		sbp.auto_detect_udims=True
	disable_impossible(context)
def global_mode_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.global_mode==SBConstants.CYCLESBAKE:
		sbp.tex_per_mat=False
		sbp.expand_mat_uvs=False
		sbp.cycles_s2a=False
		sbp.targetobj_cycles=None
	if not sbp.global_mode==SBConstants.PBR:
		sbp.selected_s2a=False
		sbp.targetobj=None
		sbp.s2a_opmode="single"
	disable_impossible(context)
def selected_rough_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.selected_rough:
		sbp.rough_glossy_switch=SBConstants.PBR_ROUGHNESS
	disable_impossible(context)
def selected_normal_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.selected_normal:
		sbp.normal_format_switch=SBConstants.NORMAL_OPENGL
	disable_impossible(context)
def presets_list_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	index=sbp.presets_list_index
	item=sbp.presets_list[index]
	sbp.preset_name=item.name
	disable_impossible(context)
def local_presets_list_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	index=sbp.local_presets_list_index
	item=sbp.local_presets_list[index]
	sbp.local_preset_name=item.name
	disable_impossible(context)
def presets_show_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	bpy.ops.simplebake.preset_refresh()
	disable_impossible(context)
def imgheight_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	sbp.outputheight=sbp.imgheight
	disable_impossible(context)
def imgwidth_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	sbp.outputwidth=sbp.imgwidth
	disable_impossible(context)
def textures_show_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.first_texture_show:
		auto_set_bake_margin(context)
		sbp.first_texture_show=False
	disable_impossible(context)
def bake_objects_show_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.first_texture_show:
		auto_set_bake_margin(context)
		sbp.first_texture_show=False
	disable_impossible(context)
def selected_s2a_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.selected_s2a:
		sbp.targetobj=None
		sbp.s2a_opmode='single'
	if sbp.selected_s2a:
		sbp.selected_col_mats=False
		sbp.selected_lightmap=False
	disable_impossible(context)
def cycles_s2a_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.cycles_s2a:
		sbp.targetobj_cycles=None
	if sbp.cycles_s2a:
		sbp.selected_col_mats=False
		sbp.selected_lightmap=False
	disable_impossible(context)
def cp_list_index_update(self,context):
	if suppress_for_preset_load:
		return True
	sbp=context.scene.SimpleBake_Props
	index=sbp.cp_list_index
	cpt=sbp.cp_list[index]
	messages=[]
	try:
		sbp.channelpackfileformat=cpt.file_format
		sbp.exr_codec_cpts=cpt.exr_codec
	except:
		pass
	if "png_compression" in cpt:
		sbp.png_compression=cpt.png_compression
	try:
		sbp.cptex_R=cpt.R
	except:
		messages.append(f"WARNING: {cpt.name} depends on {cpt.R} for the Red channel,but you are not baking it")
		messages.append("You can enable the required bake,or change the bake for that channel")
	try:
		sbp.cptex_G=cpt.G
	except:
		messages.append(f"WARNING: {cpt.name} depends on {cpt.G} for the Green channel,but you are not baking it")
		messages.append("You can enable the required bake,or change the bake for that channel")
	try:
		sbp.cptex_B=cpt.B
	except:
		messages.append(f"WARNING: {cpt.name} depends on {cpt.B} for the Blue channel,but you are not baking it")
		messages.append("You can enable the required bake,or change the bake for that channel")
	try:
		sbp.cptex_A=cpt.A
	except:
		messages.append(f"WARNING: {cpt.name} depends on {cpt.A} for the Alpha channel,but you are not baking it")
		messages.append("You can enable the required bake,or change the bake for that channel")
	sbp.cp_name=cpt.name
	try:
		context.scene.render.image_settings.exr_codec=cpt.exr_codec
	except:
		pass
	if len(messages)>0:
		show_message_box(context,messages,title="Warning",icon="ERROR")
	disable_impossible(context)
def clear_image_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.clear_image:
		sbp.use_alpha=False
	disable_impossible(context)
def bgbake_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.bgbake=="bg":
		sbp.apply_bakes_to_original=False
	disable_impossible(context)
def s2a_opmode_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.s2a_opmode=="decals":
		sbp.selected_alpha=True
	disable_impossible(context)
def auto_match_mode_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	disable_impossible(context)
def objects_list_index_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	i=sbp.objects_list_index
	if i !=-1:
		if len(sbp.objects_list)>0:
			o=sbp.objects_list[i]
			if o.obj_point !=None:
				select_only_this(context,o.obj_point)
	disable_impossible(context)
def keep_internal_after_export_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if not sbp.keep_internal_after_export:
		sbp.copy_and_apply=False
def multiply_diffuse_ao_update(self,context):
	if suppress_for_preset_load: return True
	sbp=context.scene.SimpleBake_Props
	if sbp.multiply_diffuse_ao=="diffusexao":
		sbp.selected_ao=True
def auto_cage_extrusion_update(self,context):
	sbp=context.scene.SimpleBake_Props
	to=None
	if sbp.global_mode=="PBR":
		to=sbp.targetobj
	else:
		to=sbp.targetobj_cycles
	if to==None:
		return False
	co=[o for o in context.scene.objects if "SB_auto_cage" in o and o["SB_auto_cage"]==to.name]
	if len(co) !=1:
		return False
	else:
		co=co[0]
	if 'SB_AUTO_CAGE' in co.modifiers:
		co.modifiers['SB_AUTO_CAGE'].mid_level=1-sbp.auto_cage_extrusion
def get_selected_bakes_dropdown(self,context):
	sbp=context.scene.SimpleBake_Props
	items=[]
	items.append(("none",g("None"),""))
	if sbp.selected_col:
		items.append((SBConstants.PBR_DIFFUSE,SBConstants.PBR_DIFFUSE,""))
	if sbp.selected_metal:
		items.append((SBConstants.PBR_METAL,SBConstants.PBR_METAL,""))
	if sbp.selected_sss:
		items.append((SBConstants.PBR_SSS,SBConstants.PBR_SSS,""))
	if sbp.selected_ssscol:
		items.append((SBConstants.PBR_SSSCOL,SBConstants.PBR_SSSCOL,""))
	if sbp.selected_rough:
		if sbp.rough_glossy_switch==SBConstants.PBR_GLOSSY:
			items.append((SBConstants.PBR_GLOSSY,SBConstants.PBR_GLOSSY,""))
		else:
			items.append((SBConstants.PBR_ROUGHNESS,SBConstants.PBR_ROUGHNESS,""))
	if sbp.selected_normal:
		items.append((SBConstants.PBR_NORMAL,SBConstants.PBR_NORMAL,""))
	if sbp.selected_trans:
		items.append((SBConstants.PBR_TRANSMISSION,SBConstants.PBR_TRANSMISSION,""))
	if sbp.selected_transrough:
		items.append((SBConstants.PBR_TRANSMISSION_ROUGH,SBConstants.PBR_TRANSMISSION_ROUGH,""))
	if sbp.selected_clearcoat:
		items.append((SBConstants.PBR_CLEARCOAT,SBConstants.PBR_CLEARCOAT,""))
	if sbp.selected_clearcoat_rough:
		items.append((SBConstants.PBR_CLEARCOAT_ROUGH,SBConstants.PBR_CLEARCOAT_ROUGH,""))
	if sbp.selected_emission:
		items.append((SBConstants.PBR_EMISSION,SBConstants.PBR_EMISSION,""))
	if sbp.selected_emission_strength:
		items.append((SBConstants.PBR_EMISSION_STRENGTH,SBConstants.PBR_EMISSION_STRENGTH,""))
	if sbp.selected_specular:
		items.append((SBConstants.PBR_SPECULAR,SBConstants.PBR_SPECULAR,""))
	if sbp.selected_alpha:
		items.append((SBConstants.PBR_ALPHA,SBConstants.PBR_ALPHA,""))
	if sbp.selected_bump:
		items.append((SBConstants.PBR_BUMP,SBConstants.PBR_BUMP,""))
	if sbp.selected_displacement:
		items.append((SBConstants.PBR_DISPLACEMENT,SBConstants.PBR_DISPLACEMENT,""))
	if sbp.selected_col_mats:
		items.append((SBConstants.COLOURID,SBConstants.COLOURID,""))
	if sbp.selected_col_vertex:
		items.append((SBConstants.VERTEXCOL,SBConstants.VERTEXCOL,""))
	if sbp.selected_ao:
		items.append((SBConstants.AO,SBConstants.AO,""))
	if sbp.selected_thickness:
		items.append((SBConstants.THICKNESS,SBConstants.THICKNESS,""))
	if sbp.selected_curvature:
		items.append((SBConstants.CURVATURE,SBConstants.CURVATURE,""))
	if sbp.selected_lightmap:
		items.append((SBConstants.LIGHTMAP,SBConstants.LIGHTMAP,""))
	return items
def get_fbx_presets_dropdown(self,context):
	preset_path=bpy.utils.preset_paths('operator/export_scene.fbx/')
	if preset_path:
		items=os.listdir(preset_path[0])
		items=[ (i,i.replace(".py",""),"") for i in items if not os.path.isdir(preset_path[0] + i)]
		items.insert(0,("None",g("None"),""))
		return items
	else:
		return [("None",g("None"),"")]
def get_gltf_presets_dropdown(self,context):
	preset_path=bpy.utils.preset_paths('operator/export_scene.gltf/')
	if preset_path:
		items=os.listdir(preset_path[0])
		items=[ (i,i.replace(".py",""),"") for i in items if not os.path.isdir(preset_path[0] + i)]
		items.insert(0,("None",g("None"),""))
		return items
	else:
		return [("None",g("None"),"")]
def get_cpt_format_dropdown(self,context):
	items=[("PNG",g("PNG"),""),("TARGA",g("TGA"),"")]
	prefs=context.preferences.addons[base_package].preferences
	if prefs.use_old_channel_packing:
		items.append(("OPEN_EXR",g("Open EXR"),""))
	return items
def get_s2aopmode_options(self,context):
	sbp=context.scene.SimpleBake_Props
	items=[("single",g("Standard (bake list to target)"),""),("automatch",g("Auto-match high to low"),"")]
	if sbp.global_mode==SBConstants.PBR:
		items.append(("decals",g("Decals to target"),""))
	return items
class SimpleBakePropGroup(bpy.types.PropertyGroup):
	des="全局烘焙模式"
	global_mode: EnumProperty(name="Bake Mode",default=SBConstants.PBR,description="",items=[ (SBConstants.PBR,"PBR Bake","从围原理化 BSDF和自发光着色器创建的材质中烘焙PBR贴图" ),(SBConstants.CYCLESBAKE,"Cycles Bake","烘焙“传统”循环烘焙模式" ) ],update=global_mode_update)
	des="从目标物体到选定物体投射光线的距离)"
	ray_distance: FloatProperty(name="Ray Distance",default=0.0,min=0,description=des)
	des="外壳挤出和射线距离的倍数。这可以帮助您更轻松地拨入右侧的值"
	cage_and_ray_multiplier: FloatProperty(name="Multiplier",default=1,min=0,description=des)
	des="调整此值以使自动固定帧物体膨胀或收缩"
	auto_cage_extrusion: FloatProperty(name="Extrusion",default=0,min=0,max=1,description=des,update=auto_cage_extrusion_update)
	des="Blender挤出自动生成的笼子以烘焙到目标的距离。有关更多信息，请参阅“自动拉伸笼型”选项的工具提示。注意：如果在名称模式下自动匹配高多边形和低多边形对象，则此设置仅在未检测到该低对象的笼子对象时才相关。只要有笼子，它就会被忽略。请参阅猴子提示。"
	cage_extrusion: FloatProperty(name="Cage Extrusion",default=0.1,min=0,description=des)
	des="为烘焙纹理选择颜色空间"
	cyclesbake_cs: EnumProperty(name="Colour Space",description=des,items=get_cs_list,default=19)
	des="单独烘焙每个物体,隐藏其他物体,这样它们就不会效果烘焙。当烘焙到目标时,这会隐藏所有物体*的效果,但烘焙列表*中的物体除外,因此它们不再效果列表中的物体。灯光不受效果"
	isolate_objects: BoolProperty(name="Isolate objects from each other during baking",description=des)
	des="烘焙从一个或多个源物体(通常为高多边形)到单个目标物体(通常是低多边形)的映射。源物体和目标物体必须位于同一位置(重叠)。有关更多细节信息,请参阅Blender文档中关于选定到活动烘焙的部件"
	selected_s2a: BoolProperty(name="Bake selected objects to target object",description=des,update=selected_s2a_update)
	des="指定烘焙的目标物体。注意,这不一定是视口中选择的一部件(尽管它可以是)"
	targetobj: PointerProperty(name="Target Object",description=des,type=bpy.types.Object)
	des=("选择检测低多边形对象的模式。这可以是按名称（“obj_low”和“obj_high”）或按位置（与烘焙列表中的对象最接近的对象）")
	auto_match_mode: EnumProperty(name="Auto match mode",default="position",update=auto_match_mode_update,description=des,items=[("name",g("By name"),""),("position",g("By position"),"")])
	des="如果您没有使用自定义外壳物体,Blender将在烘焙到目标时自动从目标物体中挤出外壳。自动挤压的外壳可以是平滑的,也可以是坚硬的。注意：如果在名称下自动匹配高多边形和低多边形物体模式,则此设置仅在未检测到该低物体的外壳物体时才相关。只要有外壳,它就会被忽略。查看猴子提示."
	cage_smooth_hard: EnumProperty(name="Auto extruded cage type",default="smooth",description=des,items=[("smooth",g("Smooth"),""),("hard",g("Hard"),"")])
	des="将多个对象烘焙为一组纹理。不适用于“将贴图烘焙到目标对象”（没有意义），除非您使用“自动匹配高多边形和低多边形”选项。您必须烘焙多个对象。"
	merged_bake: BoolProperty(name="Multiple objects to one texture set",default=False,description=des)
	des="每次烘焙一个物体时,物体的名称将用于纹理名称中。将多个物体烘焙到一个纹理集,但需要为纹理渲染名称"
	merged_bake_name: StringProperty(name="Texture name for multiple bake",default="MergedBake",description=des)
	des="使用选定的“循环”激活选项进行烘焙"
	cycles_s2a: BoolProperty(name="Selected to Active",description=des,update=cycles_s2a_update)
	des="指定要烘焙的目标物体(这将是香草blender烘焙的活动物体)"
	targetobj_cycles: PointerProperty(name="Target Object",description=des,type=bpy.types.Object)
	des="简单烘焙为目标物体渲染了不同的烘焙方式"
	s2a_opmode: EnumProperty(name="Bake to target mode",default=0,description=des,items=get_s2aopmode_options,update=s2a_opmode_update)
	des="烘焙到现有图像,覆盖所有其他与纹理相关的设置"
	tex_override: BoolProperty(name="Override and bake to existing image",default=False,description=des)
	des="要烘焙的现有图像"
	tex_override_tex: PointerProperty(name="Existing Image:",description=des,type=bpy.types.Image)
	des="设置将生成的烘焙图像的高度"
	imgheight: IntProperty(name="Bake height",default=1024,description=des,update=imgheight_update)
	des="设置将生成的烘焙图像的宽度"
	imgwidth: IntProperty(name="Bake width",default=1024,description=des,update=imgwidth_update)
	des="设置要输出的烘焙图像的高度"
	outputheight: IntProperty(name="Output Height",default=1024,description=des)
	des="设置要输出的烘焙图像的宽度"
	outputwidth: IntProperty(name="Output Width",default=1024,description=des)
	des="法向映射始终创建为32位浮点图像,但此选项会导致所有图像都创建为32位数浮点图像。理论上图像质量会提高,但通常不会引起注意."
	everything32bitfloat: BoolProperty(name="All internal 32bit float",default=False,description=des)
	des="烘焙图像具有透明背景(否则为黑色)"
	use_alpha: BoolProperty(name="Transparent background",default=False,description=des)
	des="在烘焙之前清除现有的烘焙图像(如果有的话)。保持启用此选项将确保简单烘焙每次烘焙都以空白图像开始。关闭此选项以允许迭代烘焙,每次烘焙都会添加到现有图像中."
	clear_image: BoolProperty(name="Clear existing bake image before bake",default=True,description=des,update=clear_image_update)
	des="在粗糙度和光泽度之间切换（彼此反转）。注意：粗糙度是Blender的默认设置，因此，如果更改此设置，纹理在Blender中使用时可能看起来不太合适。仅在导出烘焙时可用（请参阅“导出设置”部分。）"
	rough_glossy_switch: EnumProperty(name="",default=SBConstants.PBR_ROUGHNESS,description=des,items=[(SBConstants.PBR_ROUGHNESS,"Rough",""),(SBConstants.PBR_GLOSSY,"Glossy","")])
	des="在OpenGL和DirectX格式之间切换法线贴图。注意：Opengl是Blender的默认设置，因此，如果更改此设置，纹理在Blender中使用时可能看起来不太合适。仅在导出烘焙时可用（请参阅“导出设置”部分。）"
	normal_format_switch: EnumProperty(name="",default=SBConstants.NORMAL_OPENGL,description=des,items=[(SBConstants.NORMAL_OPENGL,"OpenGL",""),(SBConstants.NORMAL_DIRECTX,"DirectX","")])
	des="将每种材质烘焙成单独的的纹理(用于导出到像《第二人生》这样的虚拟世界"
	tex_per_mat: BoolProperty(name="Texture per material",description=des)
	des="烘焙PBR颜色图"
	selected_col: BoolProperty(name=SBConstants.PBR_DIFFUSE,default=True,description=des,update=selected_col_update)
	des="在纯色/漫反射或带环境遮蔽的多色/漫反射之间进行选择。还必须烘焙环境遮蔽(如果选择倍增选项,将自动启用)。必须导出您的烘焙,否则会变灰"
	multiply_diffuse_ao: EnumProperty(name="",default="purediffuse",update=multiply_diffuse_ao_update,description=des,items=[("purediffuse",g("Diffuse only"),""),("diffusexao",g("Diffuse with AO"),"")])
	des="将环境遮蔽与颜色/漫反射相乘的百分比"
	multiply_diffuse_ao_percent: IntProperty(name="%",default=50,min=0,max=100)
	des="烘焙PBR金属度图"
	selected_metal: BoolProperty(name=SBConstants.PBR_METAL,description=des)
	des="烘焙PBR粗糙度或光泽度映射"
	selected_rough: BoolProperty(name="Roughness/Glossy",description=des,update=selected_rough_update)
	des="烘焙法向映射"
	selected_normal: BoolProperty(name=SBConstants.PBR_NORMAL,description=des,update=selected_normal_update)
	des="烘焙PBR透光度图"
	selected_trans: BoolProperty(name=SBConstants.PBR_TRANSMISSION,description=des)
	des="烘焙PBR透光度粗糙度图 (仅限Blender3.6 及之前版本)"
	selected_transrough: BoolProperty(name=SBConstants.PBR_TRANSMISSION_ROUGH,description=des)
	des="烘焙自发光映射"
	selected_emission: BoolProperty(name=SBConstants.PBR_EMISSION,description=des)
	des="烘焙“自发光强度”映射"
	selected_emission_strength: BoolProperty(name=SBConstants.PBR_EMISSION_STRENGTH,description=des)
	des="烘焙次表面映射"
	selected_sss: BoolProperty(name=SBConstants.PBR_SSS,description=des)
	des="烘焙次表面颜色映射"
	selected_ssscol: BoolProperty(name=SBConstants.PBR_SSSCOL,description=des)
	des="烘焙PBR清漆映射"
	selected_clearcoat: BoolProperty(name=SBConstants.PBR_CLEARCOAT,description=des)
	des="烘焙PBR清漆粗糙度映射"
	selected_clearcoat_rough: BoolProperty(name=SBConstants.PBR_CLEARCOAT_ROUGH,description=des)
	des="烘焙镜面反射映射"
	selected_specular: BoolProperty(name=SBConstants.PBR_SPECULAR,description=des)
	des="烘焙PBR Alpha映射"
	selected_alpha: BoolProperty(name=SBConstants.PBR_ALPHA,description=des)
	des="烘焙材质中使用的碰撞节点的高度输入。Bump节点必须插入原理化 BSDF的法线输入端)"
	selected_bump: BoolProperty(name=SBConstants.PBR_BUMP,description=des)
	des="烘焙“位移”节点的“高度”输入，或“矢量位移”节点中的“矢量”输入，在任何一种情况下，都要插入“材质输出”节点的\“位移”插座。仅适用于插入的单个置换或矢量置换节点（不支持矢量数学节点）"
	selected_displacement: BoolProperty(name=SBConstants.PBR_DISPLACEMENT,description=des)
	des="基于每种材质随机颜色的ColourID图"
	selected_col_mats: BoolProperty(name=SBConstants.COLOURID,description=des)
	des="将活动顶点颜色烘焙为纹理"
	selected_col_vertex: BoolProperty(name=SBConstants.VERTEXCOL,description=des)
	des="环境光遮蔽"
	selected_ao: BoolProperty(name=SBConstants.AO,description=des)
	des="厚度图"
	selected_thickness: BoolProperty(name=SBConstants.THICKNESS,description=des)
	des="曲率图"
	selected_curvature: BoolProperty(name=SBConstants.CURVATURE,description=des)
	des="光照贴图"
	selected_lightmap: BoolProperty(name=SBConstants.LIGHTMAP,description=des)
	des="将您在渲染属性面板中设置的颜色管理设置应用于光照映射。仅在导出烘焙时可用。如果导出到EXR文件,将被忽略,因为这些文件不支持颜色管理"
	lightmap_apply_colman: BoolProperty(name="Export with colour management settings",default=False,description=des)
	des="所有具有环境遮蔽成分的特殊材质(厚度和环境遮蔽本身)的采样数量"
	ao_sample_count: IntProperty(name="AO Sample Count",description=des,default=16)
	des="使用智能UV项目为物体(或目标物体,如果烘焙到目标)创建新的UV映射。有关更多细节信息,请参阅Blender市场常见问题解答"
	new_uv_option: BoolProperty(name="New UV Map(s)",description=des,update=new_uv_option_update)
	des="如果正在烘焙的物体存在一个UV映射,请使用任何名为“简单烘焙”的现有UV映射进行烘焙(而不是活动UV映射)"
	prefer_existing_sbmap: BoolProperty(name="Prefer existing UV maps called SimpleBake",description=des)
	des="新UV法"
	new_uv_method: EnumProperty(name="New UV Method",default="SmartUVProject_Atlas",description=des,items=[("SmartUVProject_Individual",g("Smart UV Project (Individual)"),"使用智能 UV 投射,每个物体都会获得一个新的UV映射"),("SmartUVProject_Atlas",g("Smart UV Project (Atlas)"),"使用智能 UV 投射创建合成UV映射(图集映射)"),("CombineExisting",g("Combine Active UVs (Atlas)"),"通道合成每个物体上现有的活动UV映射来创建合成UV映射(图集映射)")])
	des="如果要创建新的UV,或更喜欢名为简单烘焙的现有UV映射,则用于烘焙的UV映射可能不是烘焙前在视口中显示的UV映射。此选项恢复烘焙前的活动状态"
	restore_orig_uv_map: BoolProperty(name="Restore originally active UV map at end",description=des,default=True)
	des="将合成UV打包到图集贴图时使用的边距"
	uvpackmargin: FloatProperty(name="Pack Margin",default=0.03,description=des)
	des="将UV岛合成到图集贴图中时,求其平均大小"
	average_uv_size: BoolProperty(name="Average UV Island Size",default=True,description=des)
	des="使用“每种材质的纹理”时,创建新的UV映射,并使用智能UV项目从每种材质展开UV以填充该映射"
	expand_mat_uvs: BoolProperty(name="New UVs per material,expanded to bounds",description=des,update=expand_mat_uvs_update)
	des="使用UDIM图块自动检测每个烘焙物体的UV映射的位置,并烘焙到这些图块。禁用仅烘焙常规UV空间(即首先图块)"
	auto_detect_udims: BoolProperty(name="Auto detect UDIMs",default=True,description=des)
	des="用于智能 UV项目的孤岛之间的边距"
	unwrapmargin: FloatProperty(name="UV Unwrap Margin",default=0.03,description=des)
	des="为智能UV投射使用正确的朝向选项"
	uvcorrectaspect: BoolProperty(name="Correct aspect",default=True,description=des)
	des="将新生成的UV映射移动到UV映射列表中的首先项目"
	move_new_uvs_to_top: BoolProperty(name="Move new UVs to top",description=des)
	des=""
	uvp_shape_method: EnumProperty(name="Shape method",default="CONCAVE",description=des,items=[("CONCAVE",g("Concave"),""),("CONVEX",g("Convex"),"")])
	des=""
	uvp_scale: BoolProperty(name="Scale",default=True,description=des)
	des=""
	uvp_rotate: BoolProperty(name="Rotate",default=True,description=des)
	des=""
	uvp_rotation_method: EnumProperty(name="Rotation method",default="ANY",description=des,items=[("AXIS_ALIGNED",g("Axis Aligned"),""),("CARDINAL",g("Cardinal"),""),("ANY",g("Any"),"")])
	des=""
	uvp_margin_method: EnumProperty(name="Margin method",default="SCALED",description=des,items=[("SCALED",g("Scaled"),""),("ADD",g("Add"),""),("FRACTION",g("Fraction"),"")])
	des=""
	uvp_lock_pinned: BoolProperty(name="Lock pinned",default=False,description=des)
	des=""
	uvp_lock_method: EnumProperty(name="Lock method",default="LOCKED",description=des,items=[("SCALE",g("Scale"),""),("ROTATION",g("Rotation"),""),("ROTATION_SCALE",g("Rotation Scale"),""),("LOCKED",g("All"),"")])
	des=""
	uvp_merge_overlapping: BoolProperty(name="Merge overlapping",default=False,description=des)
	des=""
	uvp_pack_to: EnumProperty(name="Pack to",default="CLOSEST_UDIM",description=des,items=[("CLOSEST_UDIM",g("Closest UDIM"),""),("ACTIVE_UDIM",g("Active UDIM"),""),("ORIGINAL_AABB",g("Original"),"")])
	des="将烘焙文件导出到下面指定的文件夹,位于保存.blend文件的同一文件夹下。如果未保存.blend文件,则不可用"
	save_bakes_external: BoolProperty(name="Export bakes",default=False,description=des,update=save_bakes_external_update)
	des="为每个烘焙物体的纹理和fbx创建一个子文件夹。仅在导出烘焙和/或网格时可用."
	export_folder_per_object: BoolProperty(name="Sub-folder per object",default=False,description=des)
	des="导出到单个FBX/GLTF文件,或将每个物体导出到其单独的的FBX/GLTF-文件"
	export_mesh_individual_or_combined: EnumProperty(name="Export mesh single or combined",default="individual",description=des,items=[("individual",g("Individual mesh files"),""),("combined",g("Combined mesh file"),"")])
	des="将网格导出为具有单个纹理和用于烘焙的UV映射的.fbx文件(即准备导入到其他局部)。文件保存在下面指定的文件夹中,在保存Blend文件的文件夹下。如果未保存.blend文件,则不可用"
	save_obj_external: BoolProperty(name="Export mesh",default=False,description=des)
	des="fbx的文件名。注意：为了保持兼容性,将只使用MS Windows可接受的字符"
	fbx_name: StringProperty(name="FBX name",description=des,default="Export",maxlen=20)
	des="gltf的文件名。注意：为了保持兼容性,将只使用MS Windows可接受的字符"
	gltf_name: StringProperty(name="GLTF name",description=des,default="Export",maxlen=20)
	des="在Blender中创建所选物体的副本(如果烘焙到目标,则创建目标物体),并将烘焙的纹理应用于它。如果您在后台烘焙,则会在导入后生成/不能与“将烘焙应用于原始物体”同时使用。如果您已取消选择“导出后保留内部图像”,因为新材质需要这些图像,则无法使用此选项"
	copy_and_apply: BoolProperty(name="Copy objects and apply bakes",default=False,description=des,update=copy_and_apply_update)
	des="将烘焙纹理应用于原始物体。不能与“复制物体并应用烘焙”同时使用。在后台烘焙时不能使用"
	apply_bakes_to_original: BoolProperty(name="Apply bakes to original object",default=False,description=des,update=apply_bakes_to_original_update)
	des="基于原理化 BSDF、Emission BSDF或Background节点的复制和应用物体上的材质"
	cyclesbake_copy_and_apply_mat_format: EnumProperty(name="Material format",default="emission",description=des,items=[("principled",g("Principled BSDF"),""),("emission",g("Emission"),""),("background",g("Background"),"")])
	des="烘焙后,在视口中隐藏从中烘焙的源物体。如果在后台烘焙,则会在导入后生成这种情况"
	hide_source_objects: BoolProperty(name="Hide source objects after bake",default=False,description=des)
	des="烘焙后,在视口中隐藏从中烘焙的外壳物体。如果在后台烘焙,则会在导入后生成这种情况"
	hide_cage_object: BoolProperty(name="Hide cage object after bake",default=False,description=des)
	des="保留烘焙物体的原始材质指定(注意：所有材质都将相同,并指向烘焙纹理集,但每种材质的面指定都将保留)"
	preserve_materials: BoolProperty(name="Preserve object original materials (BETA)",description=des)
	des="法向映射始终以16位导出,但此选项会导致所有图像以16位格式导出。除非文件大小有问题,否则这可能应该保持启用状态"
	everything_16bit: BoolProperty(name="All exports 16bit",default=True,description=des)
	des="选择导出烘焙的文件格式。也适用于Sketchfab上传图像"
	export_file_format: EnumProperty(name="Export File Format",update=export_file_format_update,default="PNG",description=des,items=[("PNG",g("PNG"),""),("JPEG",g("JPG"),""),("TIFF",g("TIFF"),""),("TARGA",g("TGA"),""),("TARGA_RAW",g("TGA RAW"),""),("OPEN_EXR",g("Open EXR"),"")])
	des="EXR文件的编解码器"
	exr_codec_export: EnumProperty(name="Codec",default="ZIP",description=des,items=[("NONE",g("NONE"),""),("PXR24",g("PXR24"),""),("ZIP",g("ZIP"),""),("PIZ",g("PIZ"),""),("RLE",g("RLE"),""),("ZIPS",g("ZIPS"),""),("DWAA",g("DWAA"),"")])
	des="JPEG的质量,因为它使用有损压缩。与原生Blender设置相同"
	jpeg_quality: IntProperty(name="JPEG quality",default=90,description=des,min=0,max=100)
	des="在外部保存漫反射图像时,应用当前场景中的颜色空间设置(曝光、伽玛等)。仅在导出烘焙图像时可用。如果导出到EXR文件,将被忽略,因为这些文件不支持颜色管理"
	apply_col_man_to_col: BoolProperty(name="Export diffuse with col management settings",default=False,description=des)
	des="在外部保存图像时,应用当前场景中的颜色空间设置(曝光、伽玛等)。仅在导出烘焙图像时可用。如果将“循环烘焙模式”设置为“法线”,则不可用。如果导出到EXR文件,将被忽略,因为这些文件不支持颜色管理"
	export_cycles_col_space: BoolProperty(name="Export with col management settings",default=True,description=des)
	des="通道合成器运行烘焙图像。必须保存Blend文件,并且必须导出烘焙"
	rundenoise: BoolProperty(name="Denoise",description=des,default=False)
	des="将网格导出到FBX时,将修改器应用于物体"
	apply_mods_on_mesh_export: BoolProperty(name="Apply object modifiers",description=des,default=True)
	des="导出到FBX时使用“应用转换”选项"
	apply_transformation: BoolProperty(name="Apply transformation",description=des,default=False)
	des=("要导出到的文件路径。注意：Blender使用“//”表示保存Blend文件的文件夹(例如“//SimpleBake_Box/”)。但是,如果您愿意,也可以键入完整路径。两者都会奏效.")
	export_path: StringProperty(subtype="DIR_PATH",description=des,default="//SimpleBake_Bakes")
	des="导出后,将烘焙图像保存在Blender内部"
	keep_internal_after_export: BoolProperty(name="Keep internal images after export",description=des,default=True,update=keep_internal_after_export_update)
	des="输入现有FBX导出预设的名称,以将其用于网格导出"
	fbx_preset_name: EnumProperty(name="FBX Export Preset",items=get_fbx_presets_dropdown,description=des,default=0)
	des="输入现有GLTF导出预设的名称,以将其用于网格导出"
	gltf_preset_name: EnumProperty(name="GLTF Export Preset",items=get_gltf_presets_dropdown,description=des,default=0)
	des="导出网格的格式(FBX或GLTF)"
	export_format: EnumProperty(name="Export format",default="fbx",description=des,items=[("fbx",g("FBX"),""),("gltf",g("GLTF"),""),])
	des="启用后,您将烘焙添加到烘焙列表中的物体。关闭后,您将烘焙视口中选定的物体"
	objects_list: CollectionProperty(type=ObjectListItem)
	objects_list_index: IntProperty(name="Index for bake objects list",default=0,update=objects_list_index_update)
	bgbake: EnumProperty(name="Background Bake",default="fg",items=[("fg",g("Foreground"),"在前台进行烘焙。blender将锁定,直到烘焙完成"),("bg",g("Background"),"在后台进行烘焙,让您在烘焙过程中可以继续在Blender中工作")],update=bgbake_update)
	des="名称可帮助您识别背景烘焙任务。这可以是任何东西,只是为了帮助跟踪多个背景烘焙任务。该名称将显示在下面的列表中."
	bgbake_name: StringProperty(name="Background bake task name",description=des) 
	memLimit: EnumProperty(name="GPU Memory Limit",default="4096",description="通道约束渲染图块大小来约束内存使用。更多的内存意味着更快的烘焙时间,但可能会超过计算机的能力,从而导致崩溃或烘焙时间变慢",items=[("512",g("Ultra Low"),"超低内存使用率(最大512个平铺大小"),("1024",g("Low"),"内存使用率低(最大1024个平铺大小"),("2048",g("Medium"),"中内存使用率(最大2048个平铺大小"),("4096",g("Normal"),"法向内存使用情况,适用于相当现代的计算机(最大4096个平铺大小"),("Off",g("No Limit"),"不约束内存使用(图块大小与渲染图像大小匹配")])
	des="应用于这些烘焙的名称(包含在烘焙文件名中,前提是您已将其包含在图像格式字符串中请参阅插件首选项)。注意：为了保持兼容性,将只使用MS Windows可接受的字符"
	batch_name: StringProperty(name="Batch name",description=des,default="Bake1",maxlen=20)
	des="创建glTF设置节点组"
	create_glTF_node: BoolProperty(name="Create glTF settings",description=des,default=False)
	glTF_selection: EnumProperty(name="glTF selection",default=SBConstants.AO,description="应将哪个映射插入glTF设置节点",items=[(SBConstants.AO,SBConstants.AO,"Use ambient occlusion"),(SBConstants.LIGHTMAP,SBConstants.LIGHTMAP,"Use lightmap")])
	des="默认情况下,PBR烘焙在2个采样上完成(因为它们被烘焙为不可能生成自发光和噪点)。但是,对于包含倒角或环境遮蔽节点的材质,需要增加采样数。如果在材质中检测到这些节点,则使用此数量"
	boosted_sample_count: IntProperty(name="Boosted sample count (AO and Bevel)",description=des,default=50)
	des="通常，法线贴图被视为一种特殊情况。无论您的其他设置如何，它们始终是内部32位浮点数和16/32位外部导出（所选文件类型的最大值）。启用此选项会关闭特殊处理。法线贴图将遵循与其他纹理相同的规则，并受“所有内部32位浮点”和“所有导出16位”选项的影响"
	no_force_32bit_normals: BoolProperty(name="Don't force high bit-depth normal maps",default=False,description=des)
	des="要搜索的文本"
	findreplace_find: StringProperty(name="Find",default="",description=des)
	des="要查找的文本"
	findreplace_replace: StringProperty(name="Replace",default="",description=des)
	des="查找和替换的数据类型"
	findreplace_type: EnumProperty(name="Data type",default="image",description=des,items=[("image",g("Images"),""),("object",g("Objects"),""),("material",g("Materials"),"")])
	des="将查找和替换操作约束为简单烘焙创建的物体/材质/图像"
	limit_findandreplace_to_sb: BoolProperty("Limit",default=False,description=des)
	des="全局预设列表"
	presets_list: CollectionProperty(type=PresetItem,name="Presets",description="预设")
	presets_list_index: IntProperty(name="Index for bake presets list",default=0,update=presets_list_update)
	des="保存此预设的名称"
	preset_name: StringProperty(name="Name: ",description=des,default="Preset Name",maxlen=64)
	des="加载预设时清除烘焙物体列表。将应用预设中存储的任何烘焙物体列表"
	preset_load_clear_obj: BoolProperty(name="Replace bake objects list with preset",description=des,default=True)
	des="局部预设列表"
	local_presets_list: CollectionProperty(type=PresetItem,name="Local Presets",description="局部预设")
	local_presets_list_index: IntProperty(name="Index for local bake presets list",default=0,update=local_presets_list_update)
	des="保存此预设的名称"
	local_preset_name: StringProperty(name="Name: ",description=des,default="Preset Name",maxlen=64)
	showtips: BoolProperty(name="",default=False)
	des="显示简单烘焙预设"
	presets_show: BoolProperty(name="",description=des,default=False,update=presets_show_update)
	des="显示烘焙物体"
	bake_objects_show: BoolProperty(name="",description=des,default=False,update=bake_objects_show_update)
	des="显示PBR设置"
	pbr_settings_show: BoolProperty(name="",description=des,default=False)
	des="显示循环设置"
	cyclesbake_settings_show: BoolProperty(name="",description=des,default=False)
	des="显示特别设置"
	specials_show: BoolProperty(name="",description=des,default=False)
	des="显示纹理设置"
	textures_show: BoolProperty(name="",description=des,default=False,update=textures_show_update)
	des="显示导出设置"
	export_show: BoolProperty(name="",description=des,default=False)
	des="显示UV设置"
	uv_show: BoolProperty(name="",description=des,default=False)
	des="显示其他设置"
	other_show: BoolProperty(name="",description=des,default=False)
	des="显示通道打包设置"
	channelpacking_show: BoolProperty(name="",description=des,default=False)
	des="显示管理员设置"
	admin_settings_show: BoolProperty(name="",description=des,default=False)
	des="显示当前运行的后台烘焙的状态"
	bg_status_show: BoolProperty(name="BG Bakes Status",description=des,default=True)
	des="显示高级UV打包选项"
	uv_advanced_packing_show: BoolProperty(name="Advanced UV packing options",description=des,default=False)
	first_texture_show: BoolProperty(name="",description=des,default=True)
	des="用于通道打包图像的红色通道的烘焙类型"
	cptex_R: EnumProperty(items=get_selected_bakes_dropdown,description=des)
	des="用于通道打包图像的绿色通道的烘焙类型"
	cptex_G: EnumProperty(items=get_selected_bakes_dropdown,description=des)
	des="用于通道打包图像的蓝色通道的烘焙类型"
	cptex_B: EnumProperty(items=get_selected_bakes_dropdown,description=des)
	des="用于通道打包图像的Alpha通道的烘焙类型"
	cptex_A: EnumProperty(items=get_selected_bakes_dropdown,description=des)
	cp_name: StringProperty(name="Name: ",default="PackedTex",maxlen=30,description=des)
	des="通道打包纹理列表"
	cp_list: CollectionProperty(type=CPTexItem,name="CP Textures",description="CP纹理")
	cp_list_index: IntProperty(name="Index for CP Textures list",default=0,update=cp_list_index_update)
	des="EXR文件的编解码器"
	exr_codec_cpts: EnumProperty(name="Codec",default="ZIP",description=des,items=[("NONE",g("NONE"),""),("PXR24",g("PXR24"),""),("ZIP",g("ZIP"),""),("PIZ",g("PIZ"),""),("RLE",g("RLE"),""),("ZIPS",g("ZIPS"),""),("DWAA",g("DWAA"),"")])
	des="保存通道打包图像时使用的PNG压缩"
	png_compression: IntProperty(default=15,description=des,min=0,max=100)
	des="通道包图像的文件格式"
	channelpackfileformat: EnumProperty(name="Export File Format for Channel Packing",description=des,items=get_cpt_format_dropdown)
	des=("在外部文件系统中创建打包纹理后,删除烘焙(内部和外部)。如果您也在使用副本,则不可用 "
	"对象和“应用烘焙”选项或“将烘焙应用于原始对象”选项，因为在这两种情况下，您都需要新材质的单独纹理")
	del_cptex_components: BoolProperty(name="Delete bakes after channel pack",description=des,default=False)
	des="在场景的指定帧之间重复烘焙过程,创建图像序列。确保在简单烘焙插件首选项中将帧号作为图像格式字符串的一部件"
	bake_sequence: BoolProperty(name="Image sequence",default=False,description=des)
	des="图像序列的起始帧"
	bake_sequence_start_frame: IntProperty(name="Start",default=1,description=des,min=0)
	des="图像序列的起始帧"
	bake_sequence_end_frame: IntProperty(name="End",description=des)
	highlight_col: FloatVectorProperty(name="Col",subtype='COLOR',min=0.0,max=1.0,default=(1.0,0.0,0.0),description="选择RGB颜色",size=3)
	t=Path(tempfile.TemporaryDirectory().name).as_posix()
	bgbake_temp_dir: StringProperty(default=t)
	total_bake_images_number: IntProperty()
	current_bake_image_number: IntProperty(default=0)
	base_folder_override: StringProperty(default="")
	fg_status_message: StringProperty()
	percent_complete: IntProperty()
	testing: StringProperty(maxlen=0)
	highlight_on: BoolProperty(default=False)
	suppress_report: BoolProperty(default=False)
	fake_background: BoolProperty(default=False)
	try:
		l=getpass.getuser()
		safe_context_check: StringProperty(default=l)
	except:
		safe_context_check: StringProperty(default="")
classes=([ObjectListItem,PresetItem,CPTexItem,SimpleBakePropGroup])
def register():
	global classes
	for cls in classes:
		register_class(cls)
	bpy.types.Scene.SimpleBake_Props=bpy.props.PointerProperty(type=SimpleBakePropGroup)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
