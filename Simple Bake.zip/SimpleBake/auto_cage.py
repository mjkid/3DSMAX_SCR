from .G import *
import bpy
from bpy.types import Operator
from bpy.utils import register_class,unregister_class
from bpy.props import StringProperty
from .utils import select_only_this
def set_parent(context,child_name,parent_name):
	"""
	Sets the parent of the specified child object to the specified parent object.:param child_name: The name of the child object.:param parent_name: The name of the parent object.
	"""
	child=context.scene.objects.get(child_name)
	parent=context.scene.objects.get(parent_name)
	if child is None:
		print(f"子物体 '{child_name}' 未找到.")
		return
	if parent is None:
		print(f"父物体 '{parent_name}' 未找到.")
		return
	original_matrix=child.matrix_world.copy()
	child.parent=parent
	child.matrix_parent_inverse=parent.matrix_world.inverted()
	child.matrix_world=original_matrix
def duplicate_and_apply_modifiers(context,obj_name):
	obj=context.scene.objects.get(obj_name)
	if obj is None:
		print(f"物体 '{obj_name}' 未找到")
		return None
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(True)
	context.view_layer.objects.active=obj
	bpy.ops.object.duplicate()
	new_obj=context.view_layer.objects.active
	new_obj.name=f"{obj_name}_cage"
	new_obj["SB_bake_operation_id"]="Blah"
	for modifier in new_obj.modifiers:
		try:
			bpy.ops.object.modifier_apply(modifier=modifier.name)
		except:
			new_obj.modifiers.remove(modifier)
	new_obj.hide_select=True
	return new_obj.name
def remove_all_materials(obj):
	obj.data.materials.clear()
def add_new_material(obj,mat_name,color,alpha):
	mat=bpy.data.materials.new(name=mat_name)
	mat.diffuse_color=(color[0],color[1],color[2],alpha)
	mat.use_nodes=True
	if (pnode:=mat.node_tree.nodes.get("Principled BSDF")):
		pnode.inputs["Base Color"].default_value=(color[0],color[1],color[2],alpha)
		pnode.inputs["Alpha"].default_value=0.5
	obj.data.materials.append(mat)
	obj.color=(color[0],color[1],color[2],alpha)
	obj.show_transparent=True
def add_displacement_modifier(obj):
	displace=obj.modifiers.new(name='Displace',type='DISPLACE')
	displace.texture=None
	displace.mid_level=1
	displace.name="SB_AUTO_CAGE"
class SimpleBake_OT_Auto_Cage(Operator):
	bl_idname="simplebake.auto_cage";bl_label=g("Auto-Cage");bl_description="为选定的目标物体*自动创建一个外壳物体*。必须处于物体才能运行模式"
	target_name: StringProperty()
	@classmethod
	def poll(cls,context):
		if context.mode !="OBJECT":
			return False
		sbp=context.scene.SimpleBake_Props
		if sbp.global_mode=="PBR":
			if sbp.targetobj==None: return False
			if sbp.targetobj.type !="MESH": return False
			if sbp.targetobj.name not in context.view_layer.objects: return False
			t=[o.name for o in context.scene.objects if "SB_auto_cage" in o and o["SB_auto_cage"]==sbp.targetobj.name]
			if len(t) > 0:
				return False
		elif sbp.global_mode=="CyclesBake":
			if sbp.targetobj_cycles==None: return False
			if sbp.targetobj_cycles.type !="MESH": return False
			if sbp.targetobj_cycles.name not in context.view_layer.objects: return False
			t=[o.name for o in context.scene.objects if "SB_auto_cage" in o and o["SB_auto_cage"]==sbp.targetobj_cycles.name]
			if len(t) > 0:
				return False
		return True
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		if self.target_name !="":
			obj_name=self.target_name
		elif sbp.global_mode=="PBR" and sbp.targetobj !=None:
			obj_name=sbp.targetobj.name
		elif sbp.global_mode=="CyclesBake" and sbp.targetobj_cycles !=None:
			obj_name=sbp.targetobj_cycles.name
		else:
			return {'CANCELLED'}
		new_obj_name=duplicate_and_apply_modifiers(context,obj_name)
		if new_obj_name:
			new_obj=context.scene.objects.get(new_obj_name)
			remove_all_materials(new_obj)
			add_new_material(new_obj,'SB_Cage_Mat',(1.0,0.0,0.0),0.5)
			add_displacement_modifier(new_obj)
			set_parent(context,new_obj_name,obj_name)
			new_obj["SB_auto_cage"]=obj_name
			context.scene.render.bake.cage_object=new_obj
		select_only_this(context,context.scene.objects.get(obj_name))
		return {'FINISHED'}
class SimpleBake_OT_Remove_Auto_Cage(Operator):
	bl_idname="simplebake.remove_auto_cage";bl_label=g("Remove Auto-Cage Object *for selected Target Object*");bl_description="删除为选定目标物体*自动创建的帧物体*。必须处于物体才能运行模式"
	target_name: StringProperty()
	@classmethod
	def poll(cls,context):
		if context.mode !="OBJECT":
			return False
		sbp=context.scene.SimpleBake_Props
		to_name=""
		if sbp.global_mode=="PBR":
			if sbp.targetobj==None: return False
			if sbp.targetobj.type !="MESH": return False
			if sbp.targetobj.name not in context.view_layer.objects: return False
			to_name=sbp.targetobj.name
		elif sbp.global_mode=="CyclesBake":
			if sbp.targetobj_cycles==None: return False
			if sbp.targetobj_cycles.type !="MESH": return False
			if sbp.targetobj_cycles.name not in context.view_layer.objects: return False
			to_name=sbp.targetobj_cycles.name
		t=[o.name for o in context.scene.objects if "SB_auto_cage" in o and o["SB_auto_cage"]==to_name]
		if len(t)==0:
			return False
		return True
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		if self.target_name !="":
			obj_name=self.target_name
		elif sbp.global_mode=="PBR" and sbp.targetobj !=None:
			obj_name=sbp.targetobj.name
		elif sbp.global_mode=="CyclesBake" and sbp.targetobj_cycles !=None:
			obj_name=sbp.targetobj_cycles.name
		else:
			return {'CANCELLED'}
		to_remove=[o.name for o in context.scene.objects if "SB_auto_cage" in o and o["SB_auto_cage"]==obj_name]
		for o_name in to_remove:
			o=context.scene.objects.get(o_name)
			if o !=None:
				bpy.data.objects.remove(o)
		return {'FINISHED'}
classes=([SimpleBake_OT_Auto_Cage,SimpleBake_OT_Remove_Auto_Cage])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
