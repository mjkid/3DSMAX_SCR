from .G import *
import bpy
from urllib.request import urlopen
from bpy.utils import register_class,unregister_class
from bpy.types import Operator
import base64
from pathlib import Path
import os,urllib.request,shutil
from .utils import show_message_box
from .messages import print_message
class VersionControl:
	was_error=False
	at_current=True
	installed_version=False
	installed_version_str=""
	current_version_str=""
	just_updated=False
	@classmethod
	def check_at_current_version(cls,no_online_check):
		iv=cls.installed_version
		iv=str(iv[0]) + str(iv[1]) + str(iv[2])
		iv=int(iv)
		cls.installed_version_str=str(cls.installed_version).replace(",",".").replace(")","").replace("(","")
		if no_online_check:
			return True
		link="http://www.toohey.co.uk/SimpleBake/currentversion4"
		cver=0
		try:
			f=urlopen(link,timeout=5)
			cver=f.read()
			cver=cver.decode("utf-8")
			cls.current_version_str=cver
			cver=cver.replace(".","")
			cver=int(cver)
		except Exception as e:
			cls.was_error=True
			print_message(bpy.context,"Unable to check for latest version of SimpleBake - are you online?",screen=False)
			cver=iv
			print_message(bpy.context,str(e),screen=False)
		if cver > iv:
			cls.at_current=False
			print_message(bpy.context,"There is a newer version of SimpleBake available",screen=False)
		else:
			cls.at_current=True
			print_message(bpy.context,"Your copy of SimpleBake is up to date",screen=False)
class SimpleBake_OT_Auto_Update(Operator):
	"""下载并安装简单烘焙的更新版本"""
	bl_idname="simplebake.auto_update";bl_label=g("Update")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		try:
			current_ver_url=base64.b64decode("aHR0cDovL3d3dy50b29oZXkuY28udWsvU2ltcGxlQmFrZS9TaW1wbGVCYWtlX0N1cnJlbnQ0LnppcA==").decode("utf-8")
			current_ver_zip_name="SimpleBake_Curent4.zip"
			addon_dir_name="SimpleBake"
			import zipfile
			addons_path=Path(os.path.dirname(__file__)).parents[0]
			print_message(context,f"Addons folder: {addons_path}")
			os.chdir(str(addons_path))
			print_message(context,"Starting download")
			urllib.request.urlretrieve(current_ver_url,current_ver_zip_name)
			current_ver_zip_name="SimpleBake_Curent4.zip"
			print_message(context,"Download complete")
			addon_dir=addons_path / addon_dir_name
			shutil.rmtree(str(addon_dir)) 
			current_ver_zip=zipfile.ZipFile(current_ver_zip_name,"r")
			current_ver_zip.extractall()
			current_ver_zip.close()
			downloaded_zip=addons_path / current_ver_zip_name
			downloaded_zip.unlink()
			message_lines=["SimpleBake update complete","Please restart Blender"]
			show_message_box(context,message_lines,"Update complete",icon='INFO')
			print_message(context,"Update complete. Please restart Blender")
			VersionControl.just_updated=True
			return {'FINISHED'}
		except Exception as e:
			print_message(context,str(e))
			return {'CANCELLED'}
class SimpleBake_OT_Rollback_Update(Operator):
	"""下载并安装简单烘焙的早期版本"""
	bl_idname="simplebake.rollback_update";bl_label=g("Rollback")
	def execute(self,context):
		sbp=context.scene.SimpleBake_Props
		try:
			current_ver_url=base64.b64decode("aHR0cDovL3d3dy50b29oZXkuY28udWsvU2ltcGxlQmFrZS9TaW1wbGVCYWtlX1ByZXZpb3VzNC56aXA=").decode("utf-8")
			current_ver_zip_name="SimpleBake_Previous4.zip"
			addon_dir_name="SimpleBake"
			import zipfile
			addons_path=Path(os.path.dirname(__file__)).parents[0]
			print_message(context,f"Addons folder: {addons_path}")
			os.chdir(str(addons_path))
			print_message(context,"Starting download")
			urllib.request.urlretrieve(current_ver_url,current_ver_zip_name)
			print_message(context,"Download complete")
			addon_dir=addons_path / addon_dir_name
			shutil.rmtree(str(addon_dir))
			current_ver_zip=zipfile.ZipFile(current_ver_zip_name,"r")
			current_ver_zip.extractall()
			current_ver_zip.close()
			downloaded_zip=addons_path / current_ver_zip_name
			downloaded_zip.unlink()
			message_lines=["SimpleBake rollback complete","Please restart Blender"]
			show_message_box(context,message_lines,"Rollback complete",icon='INFO')
			print_message(context,"Rollback complete. Please restart Blender")
			VersionControl.just_updated=True
			return {'FINISHED'}
		except Exception as e:
			print_message(context,str(e))
			return {'CANCELLED'}
classes=([SimpleBake_OT_Auto_Update,SimpleBake_OT_Rollback_Update])
def register():
	global classes
	for cls in classes:
		register_class(cls)
def unregister():
	global classes
	for cls in classes:
		unregister_class(cls)
