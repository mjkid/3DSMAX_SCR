import bpy;from .G import *
bl_info={"name": "🦴 快速绑骨 (Quick Rig for ARP)","author":"Artell 汉化：GJJ","version": (1,27,21),"blender": (2,80,0),"location": "【3D视图】>【N面板】>【🦴】","description": "从现有骨架快速生成ARP骨架(必须安装ARP)","category": "Animation","wiki_url": "http://lucky3d.fr/auto-rig-pro/doc/quick_rig_doc.html","tracker_url": "https://blendermarket.com/products/auto-rig-pro-quick-rig",}
from . import auto_rig_quick_prefs,auto_rig_quick
def cleanse_modules():
	import sys
	all_modules=sys.modules
	all_modules=dict(sorted(all_modules.items(),key=lambda x:x[0]))
	for k in all_modules:
		if k.startswith(__name__):
			del sys.modules[k]
def register():
	auto_rig_quick_prefs.register()
	auto_rig_quick.register()
	UPG(None,bpy.context)
def unregister():
	auto_rig_quick_prefs.unregister()
	auto_rig_quick.unregister()
	cleanse_modules()
if __name__== "__main__":
	register()