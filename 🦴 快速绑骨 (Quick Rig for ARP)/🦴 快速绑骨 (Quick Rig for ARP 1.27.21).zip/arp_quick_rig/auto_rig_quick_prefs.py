from .G import *
import bpy,os,platform
def get_documents_path(other_folder):
	home=os.path.expanduser("~")
	documents= ""
	if platform.system()== "Windows":
		documents=os.path.join(home, "Documents")
	else:
		documents=os.path.join(home, "Documents")
	p=os.path.join(documents, 'AutoRigPro')
	p=os.path.join(p,other_folder)
	return p
class ARP_MT_arp_quick_addon_preferences(bpy.types.AddonPreferences):
	bl_idname=AD
	custom_presets_path: bpy.props.StringProperty(name="Custom Presets Path",subtype='FILE_PATH',default=get_documents_path('Quick Rig Presets'))
	V:bpy.props.BoolProperty(default=1,name='Confirm version compatibility',description="不再显示版本提示")
	C:bpy.props.StringProperty(name="Category",description="N面板类别的名称",default=TB,update=UPG)
	def draw(S,_):
		L=S.layout.column_flow(columns=2,align=1);DH(S,_,L);L.template_icon(icon_value=I("1"),scale=12)
		GP(L,S, "C",text="Interface Tab")
		GP(L,S, "custom_presets_path",text="Custom Presets Path")
		X(S,_,L)
def register():RCL(ARP_MT_arp_quick_addon_preferences)
def unregister():UCL(ARP_MT_arp_quick_addon_preferences)
