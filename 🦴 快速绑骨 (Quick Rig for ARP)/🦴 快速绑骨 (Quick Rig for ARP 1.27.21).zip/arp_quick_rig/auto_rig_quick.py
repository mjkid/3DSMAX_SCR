from .G import *
import bpy,sys,linecache,ast,os,time,math,difflib
from mathutils import Vector,Euler,Matrix
from bpy.types import Panel,UIList,Operator,Menu
from bpy.props import BoolProperty,FloatProperty,StringProperty,IntProperty,EnumProperty,FloatVectorProperty
from .utils import *
import addon_utils,requests,webbrowser
class ARP_OT_quick_eval_axis(Operator):
	"""评估骨骼轴。\n仅适用于A或T形"""
	bl_idname= "arp.quick_eval_axis";bl_label=g("Quick Eval Axis");bl_options={'UNDO'}
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	type: StringProperty(default="")
	hand_bone_name: StringProperty(default="")
	arm_bone_name: StringProperty(default="")
	foot_bone_name: StringProperty(default="")
	def execute(self,context):
		current_mode=get_current_mode()
		try:
			scn=bpy.context.scene
			bpy.ops.object.mode_set(mode='EDIT')
			hand_bone=get_edit_bone(self.hand_bone_name)
			arm_bone=get_edit_bone(self.arm_bone_name)
			foot_bone=get_edit_bone(self.foot_bone_name)
			limb=scn.limb_map[scn.limb_map_index]
			if self.type== "up_axis_arm":
				evaluate_arm_up_axis(limb,hand_bone,arm_bone)
			elif self.type== "up_axis":
				evaluate_hand_up_axis(limb,hand_bone,arm_bone)
			elif self.type== "foot_up_axis":
				evaluate_foot_up_axis(limb,foot_bone)
		finally:
			restore_current_mode(current_mode)
		return {'FINISHED'}
class ARP_OT_quick_limbs_move(Operator):
	"""移动条目"""
	bl_idname= "arp.quick_limbs_move";bl_label=g("Quick Limbs Move");bl_options={'UNDO'}
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	direction: StringProperty(default=g("UP"))
	def execute(self,context):
		try:
			scn=bpy.context.scene
			fac=-1
			if self.direction== 'DOWN':
				fac=1
			target_idx=scn.limb_map_index + fac
			if target_idx < 0:
				target_idx=len(scn.limb_map)-1
			if target_idx > len(scn.limb_map)-1:
				target_idx=0
			scn.limb_map.move(scn.limb_map_index,target_idx)
			scn.limb_map_index=target_idx
		except:
			pass
		return {'FINISHED'}
class ARP_OT_quick_check_for_update(Operator):
	"""检查是否发布了新建Quick Rig版本"""
	bl_idname= "arp.quick_check_for_update";bl_label=g("Check for Update")
	current_version=0
	latest_version=0
	current_version_digits= ''
	message= ''
	same_major_version=False
	new_log_diff=[]
	fixed_log_diff=[]
	new_log_diff_brk={}
	fixed_log_diff_brk={}
	def invoke(self,context,event):
		self.same_major_version=False
		self.new_log_diff=[]
		self.fixed_log_diff=[]
		new_log_diff_brk={}
		fixed_log_diff_brk={}
		link= "https://www.lucky3d.fr/quick-rig/00_LOG.txt"
		req=requests.get(link,timeout=5)
		f=req.text
		remote_lines=f.splitlines()
		ver_string=remote_lines[0].replace('[','').replace(']','')
		if ver_string== '':
			self.message= 'Failed to check,is there an internet connection?'
		else:
			print("ver_string",ver_string)
			ver_list=ver_string.split('.')
			ver_int=int(ver_list[0] + ver_list[1] + ver_list[2])
			self.latest_version=ver_int
			self.current_version=get_quickrig_version()
			str_current=str(self.current_version)
			self.current_version_digits=str_current[0]+'.'+str_current[1]+str_current[2]+'.'+str_current[3]+str_current[4]
			if self.current_version < self.latest_version:
				latest_ver_string=ver_int_to_str(self.latest_version)
				self.message= '* New version available! * ' + latest_ver_string
			else:
				self.message= 'Already up to date! ['+self.current_version_digits+'] Keep on riggin\''
			if str(self.latest_version)[:3]==str(self.current_version)[:3]:
				self.same_major_version=True
			version_seq= '['+ver_string+']'
			new_log=[]
			fixed_log=[]
			state= 'PARSE_NEW'
			for i,line in enumerate(remote_lines):
				if i==0:
					continue
				logline=line.strip()
				if logline== '':
					continue
				if logline== 'New/improved:':
					continue
				if logline== 'Fixed:':
					state= 'PARSE_FIXED'
					continue
				if logline.startswith('-'):
					logline=logline[1:]
				if logline.startswith(' '):
					logline=logline[1:]
				if state== 'PARSE_NEW':
					new_log.append(logline)
				elif state== 'PARSE_FIXED':
					fixed_log.append(logline)
			current_new_log=[]
			current_fixed_log=[]
			addon_directory=os.path.dirname(os.path.abspath(__file__))
			log_path=os.path.join(addon_directory, '00_LOG.txt')
			print('log_path',log_path)
			if os.path.exists(log_path) and self.same_major_version:
				log_file=open(log_path, 'r') if sys.version_info >=(3,11) else open(log_path, 'rU').readlines()
				register_new_log=False
				register_fixed_log=False
				for line in log_file:
					if line.startswith('New/improved:'):
						register_new_log=True
						continue
					if line.startswith('Fixed:'):
						register_fixed_log=True
						continue
					if register_new_log:
						valid_line=False
						if len(line) and not line.startswith(' '):
							line=line.strip()
							if line.startswith('-'):
								line=line[1:]
							if line.startswith(' '):
								line=line[1:]
							if len(line):
								current_new_log.append(line)
								valid_line=True
						if valid_line:
							continue
						else:
							register_new_log=False
							continue
					if register_fixed_log:
						valid_line=False
						if len(line) and not line.startswith(' '):
							line=line.strip()
							if line.startswith('-'):
								line=line[1:]
							if line.startswith(' '):
								line=line[1:]
							if len(line):
								current_fixed_log.append(line)
								valid_line=True
						if valid_line:
							continue
						else:
							register_fixed_log=False
							continue
			else:
				print('丢失日志文件，或专业新建版本可用')
			'''
			print('当前_新_日志')
			for i in current_new_log:
				print('start',i)
			print('')
			print('新建日志(_L)')
			for i in new_log:
				print('start',i)
			'''
			for i in new_log:
				if not i in current_new_log:
					self.new_log_diff.append('- '+i)
			for i in fixed_log:
				if not i in current_fixed_log:
					self.fixed_log_diff.append('- '+i)
			for idx,i in enumerate(self.new_log_diff):
				indexes=[100,200,300]
				substring_list=[]
				start_index=0
				for index in indexes:
					while index < len(i) and i[index] != ' ':
						index +=1
					substring=i[start_index:index]
					substring_list.append(substring)
					start_index=index + 1
				substring_list.append(i[start_index:])
				for j in reversed(substring_list):
					if j== '':
						substring_list.pop(substring_list.index(j))
				self.new_log_diff_brk[idx]=substring_list
			for idx,i in enumerate(self.fixed_log_diff):
				indexes=[100,200,300]
				substring_list=[]
				start_index=0
				for index in indexes:
					while index < len(i) and i[index] != ' ':
						index +=1
					substring=i[start_index:index]
					substring_list.append(substring)
					start_index=index + 1
				substring_list.append(i[start_index:])
				for j in reversed(substring_list):
					if j== '':
						substring_list.pop(substring_list.index(j))
				self.fixed_log_diff_brk[idx]=substring_list
		wm=context.window_manager
		return wm.invoke_props_dialog(self,width=600)
	def draw(self,context):
		layout=self.layout
		GL(layout,self.message)
		layout.separator()
		if len(self.new_log_diff) or len(self.fixed_log_diff):
			add_text= '' if self.same_major_version else ' (include '+str(self.latest_version)[0]+'.'+str(self.latest_version)[:3][-2:] +' log only)'
			GL(layout,'Changes since current version '+self.current_version_digits+add_text)
			layout.separator()
			if len(self.new_log_diff):
				GL(layout,'[New/Improved]:',icon='KEYTYPE_JITTER_VEC')
				for i in self.new_log_diff_brk:
					for line in self.new_log_diff_brk[i]:
						GL(layout,line)
			if len(self.fixed_log_diff):
				layout.separator()
				GL(layout,'[Fixed]:',icon='KEYTYPE_JITTER_VEC')
				for i in self.fixed_log_diff_brk:
					for line in self.fixed_log_diff_brk[i]:
						GL(layout,line)
			layout.separator()
		layout.separator()
	def execute(self,context):
		return {'FINISHED'}
class ARP_MT_quick_export(Menu):
	bl_label= "Export as custom preset"
	def draw(self,_context):
		layout=self.layout
		GO(layout,"arp.quick_export_preset",text="Save as New Preset")
class ARP_OT_quick_export_preset(Operator):
	"""导出为自定义预设"""
	bl_idname= "arp.quick_export_preset";bl_label=g("Export Preset")
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	preset_name: StringProperty(default=g('CoolPreset'))
	def invoke(self,context,event):
		wm=context.window_manager
		return wm.invoke_props_dialog(self,width=400)
	def draw(self,context):
		layout=self.layout
		GP(layout,self, "preset_name",text="Preset Name")
	def execute(self,context):
		custom_dir=get_prefs().custom_presets_path
		if not (custom_dir.endswith("\\") or custom_dir.endswith('/')):
			custom_dir += '/'
		filepath=custom_dir+self.preset_name+'.py'
		if not os.path.exists(os.path.dirname(filepath)):
			try:
				os.makedirs(os.path.dirname(filepath))
			except:
				pass
		_export_mapping(filepath)
		update_quick_presets()
		return {'FINISHED'}
class ARP_MT_quick_import(Menu):
	bl_label= "Import built-in presets list"
	custom_presets=[]
	def draw(self,_context):
		layout=self.layout
		presets_dict = {"Advanced Skeleton":"advanced_skeleton",
						"Biped":"biped",
						"Character Creator":"CC",
						"Character Creator +":"CC+",
						"Character Creator Accurig":"CC_Accurig",
						"DAZ (Genesis 3, 8, 8.1)": "DAZ",
						"DAZ (Genesis 9)": "DAZ_genesis_9",
						"DAZ (Genesis 9 v2)": "DAZ_genesis_9_v2",
						"DAZ (Other #1)": "DAZ_genesis_01",
						"DAZ (Other #2)": "DAZ_genesis_02",
						"Human Generator": "human_generator",
						"Human Generator V2": "human_generator_v2",
						"Human Generator V2 (Facial)": "human_generator_v2_facial",
						"MB Lab":"MB_LAB",
						"Mixamo":"mixamo",
						"Mixamo (Old)": "mixamo_old",
						"UE4 Mannequin": "UE_mannequin",
						"UE4 Mannequin (Automatic Orientations)": "UE_mannequin_automatic",
						"UE5 Manny": "UE5_manny",
						"UE5 Manny (2 Twists, for UE export)":"UE5_manny_2_twists",
						"UE MetaHuman":"UE_MetaHuman",
						"VRoid":"VRoid",
						"VRoid (CATS fixed)":"VRoid_cats"}
		for j in presets_dict:
			icon="MB" if "MB" in j else "MAX" if "Biped"==j else"CC" if "Character Creator" in j else "DAZ" if "DAZ" in j else "MAYA" if "Skeleton" in j else "HG" if "Human Generator" in j else "UE" if "UE" in j else "MIX" if "Mixamo" in j else "VO" if "VRoid" in j else ""
			layout.operator("arp.quick_import_preset",text=j,icon_value=I(icon)).preset_name=presets_dict[j]
		if len(self.custom_presets):
			layout.label(text='__________')
		for cp in self.custom_presets:layout.operator("arp.quick_import_preset",text=cp.title()).preset_name='CUSTOM_'+cp
class ARP_OT_quick_import_preset(Operator):
	""" 导入选定的预设 """
	bl_idname= "arp.quick_import_preset";bl_label=g("Import Preset")
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	preset_name: StringProperty(default="")
	clear: BoolProperty(default=True,description="导入预设之前，清理现有肢体映射")
	filepath: StringProperty(subtype="FILE_PATH",default=g('py'))
	fuzzy_match: BoolProperty(default=False,description="Approximate names match,if the preset does not match the exact names of the bones\nWarning,can be wrong!")
	@classmethod
	def poll(cls,context):
		obj=context.active_object
		if obj:
			return obj.type== "ARMATURE"
		return False
	def invoke(self,context,event):
		wm=context.window_manager
		return wm.invoke_props_dialog(self,width=400)
	def draw(self,context):
		layout=self.layout
		GP(layout,self, "clear",text="Clear Current Limbs")
		GP(layout,self, "fuzzy_match",text="Fuzzy Match")
	def execute(self,context):
		print("IMPORT PRESET")
		scn=bpy.context.scene
		try:
			scn.arp_quick_hold_update=True
			if self.clear:
				for i in range(0,len(scn.limb_map)):
					_remove_limb()
			if self.preset_name.startswith('CUSTOM_'):
				custom_dir=P().custom_presets_path
				if not (custom_dir.endswith("\\") or custom_dir.endswith('/')):
					custom_dir += '/'
				try:
					os.listdir(custom_dir)
				except:
					GR(self,'ERROR', 'The custom presets directory seems invalid: '+custom_dir+'\nCheck the path in the addon preferences')
					return
				self.filepath=custom_dir + self.preset_name[7:]+'.py'
			else:
				addon_directory=os.path.dirname(os.path.abspath(__file__))
				self.filepath=addon_directory + '/presets/'+self.preset_name+'.py'
			import_success=_import_mapping(self)
			print("import_success",import_success)
			if import_success==False and self.fuzzy_match==False:
				bpy.ops.arp.reimport_fuzzy('INVOKE_DEFAULT',preset_name=self.preset_name,clear=self.clear,filepath=self.filepath)
		finally:
			scn.arp_quick_hold_update=False
		return {'FINISHED'}
class ARP_OT_reimport_preset_fuzzy(Operator):
	"""导入与模糊名称匹配"""
	bl_idname= 'arp.reimport_fuzzy';bl_label= ''
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	preset_name: StringProperty(default="")
	clear: BoolProperty(default=True,description="导入预设之前，清理现有肢体映射")
	filepath: StringProperty(subtype="FILE_PATH",default=g('py'))
	def draw(self,context):
		layout=self.layout
		layout.label(text="",icon='ERROR')
		GL(layout,"Bone names stored in this preset don't match the bones of this skeleton!")
		GL(layout,'Try to import again with approximate names matching (fuzzy match)?')
		GL(layout,'Warning,prone to error.')
	def invoke(self,context,event):
		wm=context.window_manager
		return wm.invoke_props_dialog(self,width=400)
	def execute(self,context):
		print("REIMPORT",self.preset_name,self.filepath)
		bpy.ops.arp.quick_import_preset('EXEC_DEFAULT',preset_name=self.preset_name,clear=self.clear,filepath=self.filepath,fuzzy_match=True)
		return {"FINISHED"}
class ARP_OT_quick_report_message(Operator):
	""" 在弹窗窗口中报告消息"""
	bl_idname= "arp.quick_report_message";bl_label=g('Report Message')
	message= ""
	icon_type= 'INFO'
	def draw(self,context):
		layout=self.layout
		split_message=self.message.split('\n')
		for i,line in enumerate(split_message):
			if i==0:
				GL(layout,line,icon=self.icon_type)
			else:
				GL(layout,line)
	def execute(self,context):
		return {"FINISHED"}
	def invoke(self,context,event):
		wm=context.window_manager
		return wm.invoke_props_dialog(self,width=400)
def update_3_bones_leg(self,context):
	scn=context.scene
	if scn.arp_quick_hold_update:
		return
	slimb=scn.limb_map[scn.limb_map_index]
	limb_type=scn.limb_map[scn.limb_map_index].type
	if limb_type != 'LEG':
		return
	if slimb.leg_type.startswith('3'):
		slimb.auto_knee=False
		slimb.auto_ik_roll=True
	else:
		slimb.auto_knee=True
		slimb.auto_ik_roll=False
def update_limb_name(self,context):
	scn=context.scene
	if scn.arp_quick_hold_update:
		return
	slimb=scn.limb_map[scn.limb_map_index]
	limb_type=scn.limb_map[scn.limb_map_index].type
	dupli_count=0
	limb_map_len=None
	try:
		limb_map_len=len(scn.limb_map)
		for i in range(0,limb_map_len):
			foo=1
	except:
		return
	for i in range(0,limb_map_len):
		if i==scn.limb_map_index:
			break
		limb=scn.limb_map[i]
		if limb.type==limb_type and slimb.side==limb.side:
			dupli_count +=1
	try:
		if limb_type== "HEAD" or limb_type== "SPINE":
			if slimb.side != "CENTER":
				slimb.side= "CENTER"
	except:
		pass
	try:
		if limb_type== "LEG" or limb_type== "ARM":
			if slimb.side== "CENTER":
				slimb.side= "LEFT"
	except:
		pass
	_side= ".l"
	if slimb.side== "RIGHT":
		_side= ".r"
	elif slimb.side== "CENTER":
		_side= ".x"
	dupli_idx= ""
	if dupli_count > 0:
		dupli_idx= '{:03d}'.format(dupli_count)
		dupli_idx= "_dupli_"+str(dupli_idx)
	if slimb.name !=limb_type.title() + dupli_idx + _side:
		slimb.name=limb_type.title() + dupli_idx + _side
class LimbProp(bpy.types.PropertyGroup):
	sk_descript= 'Shape key name that must be connected to this controller.\nLeave blank if none'
	sk_default_value= ''
	sk_toggle_descript= 'Connect shape keys to this controller'
	name: StringProperty(default="",description="肢体名称")
	type: bpy.props.EnumProperty(name="Limb Type",items=(('LEG', 'Leg', '支腿类型'),('ARM', 'Arm', '臂类型'),('SPINE', 'Spine', '脊椎类型'),('HEAD', 'Head', '头部类型'),('TAIL', 'Tail', '尾部类型')),description="肢体的类型",update=update_limb_name)
	side: bpy.props.EnumProperty(name="Limb Side",items=(('LEFT', 'Left', '左侧侧'),('RIGHT', 'Right', '右侧'),('CENTER', 'Center', '中心侧')),description="肢体的侧",update=update_limb_name)
	bone_01: StringProperty(name="Bone1",default="",description="")
	bone_02: StringProperty(name="Bone2",default="",description="")
	bone_03: StringProperty(name="Bone3",default="",description="")
	bone_04: StringProperty(name="Bone4",default="",description="")
	bone_05: StringProperty(name="Bone5",default="",description="")
	bone_06: StringProperty(name="Bone6",default="",description="")
	bone_07: StringProperty(name="Bone7",default="",description="")
	bone_twist_02_01: StringProperty(name="Bone Twist 02 01",default="",description="")
	bone_twist_02_02: StringProperty(name="Bone Twist 02 02",default="",description="")
	bone_twist_03_01: StringProperty(name="Bone Twist 03 01",default="",description="")
	bone_twist_03_02: StringProperty(name="Bone Twist 03 02",default="",description="")
	bone_twist_04_01: StringProperty(name="Bone Twist 04 01",default="",description="")
	bone_twist_04_02: StringProperty(name="Bone Twist 04 02",default="",description="")
	bone_twist_05_01: StringProperty(name="Bone Twist 05 01",default="",description="")
	bone_twist_05_02: StringProperty(name="Bone Twist 05 02",default="",description="")
	bone_twist_06_01: StringProperty(name="Bone Twist 06 01",default="",description="")
	bone_twist_06_02: StringProperty(name="Bone Twist 06 02",default="",description="")
	bone_twist_07_01: StringProperty(name="Bone Twist 07 01",default="",description="")
	bone_twist_07_02: StringProperty(name="Bone Twist 07 02",default="",description="")
	twist_bones_amount: IntProperty(default=1,min=0,max=7,description="每个子肢体的扭曲骨骼数")
	spine_amount: IntProperty(default=4,min=1,max=7,description='脊椎骨骼的数量')
	neck_bones_amount: IntProperty(default=2,min=1,max=10,description="颈部骨骼的数量")
	neck3: StringProperty(name="Neck3",default="",description="")
	neck4: StringProperty(name="Neck4",default="",description="")
	neck5: StringProperty(name="Neck5",default="",description="")
	neck6: StringProperty(name="Neck6",default="",description="")
	neck7: StringProperty(name="Neck7",default="",description="")
	neck8: StringProperty(name="Neck8",default="",description="")
	neck9: StringProperty(name="Neck9",default="",description="")
	neck10: StringProperty(name="Neck10",default="",description="")
	fingers: bpy.props.EnumProperty(name="Fingers",items=(('NONE', 'None', '无'),('3', '3 Bones (No Metacarps)', '3 每个手指的骨骼，无掌骨'),('4', '4 Bones (With Metacarps)', '4 每个手指的骨骼，包括掌骨')),description="手指设置")
	up_axis: bpy.props.EnumProperty(name="Up Axis",items=(('X', 'X', 'X指向上'),('-X', '-X', '-X指向上'),('Y', 'Y', 'Y指向上'),('-Y', '-Y', '-Y指向上'),('Z', 'Z', 'Z指向上'),('-Z', '-Z', '-Z指向上')),description="骨骼轴上")
	up_axis_arm: bpy.props.EnumProperty(name="Up Axis",items=(('DEFAULT', 'Do not Align', '无对齐，保留默认定位'),('X', 'X', 'X指向上'),('-X', '-X', '-X指向上'),('Y', 'Y', 'Y指向上'),('-Y', '-Y', '-Y指向上'),('Z', 'Z', 'Z指向上'),('-Z', '-Z', '-Z指向上')),description="骨骼轴上")
	force_up_axis: BoolProperty(name="Force Up Axis",default=True,description="力度自动装配Pro脚部Z轴向上(建议用于面向Y轴的典型人形角色")
	foot_dir_axis: EnumProperty(items=(('X','X','X'),('Y','Y','Y'),('Z','Z','Z'),('-X','-X','-X'),('-Y','-Y','-Y'),('-Z','-Z','-Z')),default='Y',description='在未设置脚趾骨骼的情况下，脚骨骼轴确定脚方向')
	force_z_axis: BoolProperty(name="Force Z Axis",default=True,description="力度自动装配Pro Z轴和世界向量(建议用于面向Y轴的典型人形角色")
	primary_axis_auto: BoolProperty(default=True,description="使用自动主要")
	primary_axis: bpy.props.EnumProperty(name="Primary Axis",items=(("X", "X", "X"),("Y", "Y", "Y"),("Z", "Z", "Z"),("-X", "-X", "-X"),("-Y", "-Y", "-Y"),("-Z", "-Z", "-Z")),default='Y',description="指向子骨骼的骨骼轴")
	primary_axis_auto_multi: StringProperty(default='')
	primary_axis_fingers: StringProperty(default='')
	connect: BoolProperty(name="Connect",description="将骨骼的头部与其父级尾部连接",default=True)
	connect_foot_to_calf: BoolProperty(name="Connect Foot to Calf",description="Force the foot bone's head position to match the calf bone's tail position.\nIf disabled,the calf bone's tail is connected to the foot bone's head (default)",default=False)
	IK_axis_correc: bpy.props.EnumProperty(name='IK_axis_correc',items=(('X', 'X', 'X'),('Y', 'Y', 'Y'),('Z', 'Z', 'Z'),('-X', '-X', '-X'),('-Y', '-Y', '-Y'),('-Z', '-Z', '-Z')),default='Y',description='用于校正IK骨骼的轴(如有必要)直线对齐')
	pelvis_up: bpy.props.BoolProperty(default=False,description="确保骨盆骨骼朝上，通常应为人形生物启用")
	auto_ik_roll: BoolProperty(name='Auto IK Roll',default=False,description='自动对齐IK骨骼轴以获得连贯的旋转轴和完美对齐的上IK极')
	auto_knee: BoolProperty(name="Auto-Knee",description="在线IK杆的自动膝部方向基本脚方向",default=True)
	auto_elbow: BoolProperty(name="Auto-Elbow",description="人形机器人的自动肘方向，确保它指向+Y",default=False)
	leg_type: bpy.props.EnumProperty(name="Leg Type",description="腿的类型，使用2或3个骨骼",items=(('2', 'Default', '2 骨骼腿(人形))'),('3_1', '3 Bones Leg (Type 1)', '3 骨骼腿，典型的四足动物。大腿上部骨骼具有旋转控制'),('3_2', '3 Bones Leg (Type 2)', '3 骨骼腿，典型的四足动物。小腿骨骼具有旋转控制')),update=update_3_bones_leg)
	upper_thigh: StringProperty(name="Upper Thigh",default="",description="3块骨骼腿的额外大腿骨骼")
	thumb: StringProperty(name="Thumb",default="",description="")
	index: StringProperty(name="Index",default="",description="")
	middle: StringProperty(name="Middle",default="",description="")
	ring: StringProperty(name="Ring",default="",description="")
	pinky: StringProperty(name="Pinky",default="",description="")
	manual_phalanges: BoolProperty(name="All Fingers",default=False,description="Set all finger bones manually. \nIf disabled,only set the first phalange of each finger,the other phalanges will be found automatically if they are children bones")
	thumb1: StringProperty(name="Thumb1",default="",description="")
	index1: StringProperty(name="Index1",default="",description="")
	middle1: StringProperty(name="Middle1",default="",description="")
	ring1: StringProperty(name="Ring1",default="",description="")
	pinky1: StringProperty(name="Pinky1",default="",description="")
	thumb2: StringProperty(name="Thumb2",default="",description="")
	index2: StringProperty(name="Index2",default="",description="")
	middle2: StringProperty(name="Middle2",default="",description="")
	ring2: StringProperty(name="Ring2",default="",description="")
	pinky2: StringProperty(name="Pinky2",default="",description="")
	thumb3: StringProperty(name="Thumb3",default="",description="")
	index3: StringProperty(name="Index3",default="",description="")
	middle3: StringProperty(name="Middle3",default="",description="")
	ring3: StringProperty(name="Ring3",default="",description="")
	pinky3: StringProperty(name="Pinky3",default="",description="")
	toes_parent_foot: BoolProperty(default=False)
	weights_override: BoolProperty(name="Weights Override",default=False,description="Use another bone weight instead of the selected one\nUseful for skeleton with complex bones hierarchy")
	override_bone_01: StringProperty(name="Bone",default="",description="骨骼")
	override_bone_02: StringProperty(name="Bone",default="",description="骨骼")
	override_bone_03: StringProperty(name="Bone",default="",description="骨骼")
	override_bone_04: StringProperty(name="Bone",default="",description="骨骼")
	override_bone_05: StringProperty(name="Bone",default="",description="骨骼")
	override_bone_06: StringProperty(name="Bone",default="",description="骨骼")
	override_bone_07: StringProperty(name="Bone",default="",description="骨骼")
	override_upper_thigh: StringProperty(name="Bone",default="",description="骨骼")
	straight_head: BoolProperty(default=True,description='对齐头部主要(Z上')
	facial: BoolProperty(default=False,description='启用面部绑定')
	facial_left: BoolProperty(default=True,description='启用面部左骨骼')
	facial_right: BoolProperty(default=True,description='启用面部右骨骼')
	facial_eyes: BoolProperty(default=True,description='启用眼睛骨骼')
	eye_left: StringProperty(name='Left Eye',default='',description='左眼球骨骼')
	eye_cor_sk_left: BoolProperty(default=False,description='当时启用矫正形状')
	eye_cor_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eye_cor_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eye_cor_sk_in_left: StringProperty(default=sk_default_value,description=sk_descript)
	eye_cor_sk_out_left: StringProperty(default=sk_default_value,description=sk_descript)
	eye_right: StringProperty(name='Right Eye',default='',description='右眼球骨骼')
	eye_cor_sk_right: BoolProperty(default=False,description='当时启用矫正形状')
	eye_cor_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eye_cor_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eye_cor_sk_in_right: StringProperty(default=sk_default_value,description=sk_descript)
	eye_cor_sk_out_right: StringProperty(default=sk_default_value,description=sk_descript)
	facial_eyelids: IntProperty(default=0,min=0,max=13)
	eyelid_top_01_left: StringProperty(name='Eyelid 01',default='',description='')
	eyelid_top_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyelid_top_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_top_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_top_02_left: StringProperty(name='Eyelid 02',default='',description='')
	eyelid_top_03_left: StringProperty(name='Eyelid 03',default='',description='')
	eyelid_top_04_left: StringProperty(name='Eyelid 04',default='',description='')
	eyelid_top_05_left: StringProperty(name='Eyelid 05',default='',description='')
	eyelid_top_06_left: StringProperty(name='Eyelid 06',default='',description='')
	eyelid_top_07_left: StringProperty(name='Eyelid 07',default='',description='')
	eyelid_top_08_left: StringProperty(name='Eyelid 08',default='',description='')
	eyelid_top_09_left: StringProperty(name='Eyelid 09',default='',description='')
	eyelid_top_10_left: StringProperty(name='Eyelid 10',default='',description='')
	eyelid_top_11_left: StringProperty(name='Eyelid 11',default='',description='')
	eyelid_top_12_left: StringProperty(name='Eyelid 12',default='',description='')
	eyelid_top_13_left: StringProperty(name='Eyelid 13',default='',description='')
	eyelid_bot_01_left: StringProperty(name='Eyelid 01',default='',description='')
	eyelid_bot_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyelid_bot_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_bot_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_bot_02_left: StringProperty(name='Eyelid 02',default='',description='')
	eyelid_bot_03_left: StringProperty(name='Eyelid 03',default='',description='')
	eyelid_bot_04_left: StringProperty(name='Eyelid 04',default='',description='')
	eyelid_bot_05_left: StringProperty(name='Eyelid 05',default='',description='')
	eyelid_bot_06_left: StringProperty(name='Eyelid 06',default='',description='')
	eyelid_bot_07_left: StringProperty(name='Eyelid 07',default='',description='')
	eyelid_bot_08_left: StringProperty(name='Eyelid 08',default='',description='')
	eyelid_bot_09_left: StringProperty(name='Eyelid 09',default='',description='')
	eyelid_bot_10_left: StringProperty(name='Eyelid 10',default='',description='')
	eyelid_bot_11_left: StringProperty(name='Eyelid 11',default='',description='')
	eyelid_bot_12_left: StringProperty(name='Eyelid 12',default='',description='')
	eyelid_bot_13_left: StringProperty(name='Eyelid 13',default='',description='')
	eyelid_corner_out_left: StringProperty(name='Eyelid Corner Out',default='',description='')
	eyelid_corner_in_left: StringProperty(name='Eyelid Corner In',default='',description='')
	eyelid_top_01_right: StringProperty(name='Eyelid 01',default='',description='')
	eyelid_top_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyelid_top_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_top_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_top_02_right: StringProperty(name='Eyelid 02',default='',description='')
	eyelid_top_03_right: StringProperty(name='Eyelid 03',default='',description='')
	eyelid_top_04_right: StringProperty(name='Eyelid 04',default='',description='')
	eyelid_top_05_right: StringProperty(name='Eyelid 05',default='',description='')
	eyelid_top_06_right: StringProperty(name='Eyelid 06',default='',description='')
	eyelid_top_07_right: StringProperty(name='Eyelid 07',default='',description='')
	eyelid_top_08_right: StringProperty(name='Eyelid 08',default='',description='')
	eyelid_top_09_right: StringProperty(name='Eyelid 09',default='',description='')
	eyelid_top_10_right: StringProperty(name='Eyelid 10',default='',description='')
	eyelid_top_11_right: StringProperty(name='Eyelid 11',default='',description='')
	eyelid_top_12_right: StringProperty(name='Eyelid 12',default='',description='')
	eyelid_top_13_right: StringProperty(name='Eyelid 13',default='',description='')
	eyelid_bot_01_right: StringProperty(name='Eyelid 01',default='',description='')
	eyelid_bot_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyelid_bot_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_bot_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyelid_bot_02_right: StringProperty(name='Eyelid 02',default='',description='')
	eyelid_bot_03_right: StringProperty(name='Eyelid 03',default='',description='')
	eyelid_bot_04_right: StringProperty(name='Eyelid 04',default='',description='')
	eyelid_bot_05_right: StringProperty(name='Eyelid 05',default='',description='')
	eyelid_bot_06_right: StringProperty(name='Eyelid 06',default='',description='')
	eyelid_bot_07_right: StringProperty(name='Eyelid 07',default='',description='')
	eyelid_bot_08_right: StringProperty(name='Eyelid 08',default='',description='')
	eyelid_bot_09_right: StringProperty(name='Eyelid 09',default='',description='')
	eyelid_bot_10_right: StringProperty(name='Eyelid 10',default='',description='')
	eyelid_bot_11_right: StringProperty(name='Eyelid 11',default='',description='')
	eyelid_bot_12_right: StringProperty(name='Eyelid 12',default='',description='')
	eyelid_bot_13_right: StringProperty(name='Eyelid 13',default='',description='')
	eyelid_corner_out_right: StringProperty(name='Eyelid Corner Out',default='',description='')
	eyelid_corner_in_right: StringProperty(name='Eyelid Corner In',default='',description='')
	eyelids_align_engine: EnumProperty(items=(('BONES', 'Bones Coords', '保持当前眼睑骨骼变换'),('WEIGHTS', 'Weights Centroids', '基于顶点权重质心重新计算眼睑骨骼变换')),default='WEIGHTS',description='应如何对齐眼睑骨骼：使用当前骨骼变换，或重新计算外面顶点权重质心的变换')
	facial_eyebrows: BoolProperty(default=True)
	facial_eyebrows_amount: IntProperty(min=1,max=8,default=4)
	eyebrow_01_left: StringProperty(name='Eyebrow 01 Left',default='',description='')
	eyebrow_01_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_01_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_01_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_02_left: StringProperty(name='Eyebrow 02 Left',default='',description='')
	eyebrow_02_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_02_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_02_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_03_left: StringProperty(name='Eyebrow 03 Left',default='',description='')
	eyebrow_03_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_03_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_03_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_04_left: StringProperty(name='Eyebrow 04 Left',default='',description='')
	eyebrow_04_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_04_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_04_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_05_left: StringProperty(name='Eyebrow 05 Left',default='',description='')
	eyebrow_05_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_05_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_05_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_06_left: StringProperty(name='Eyebrow 06_Left',default='',description='')
	eyebrow_06_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_06_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_06_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_07_left: StringProperty(name='Eyebrow 07 Left',default='',description='')
	eyebrow_07_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_07_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_07_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_08_left: StringProperty(name='Eyebrow 08 Left',default='',description='')
	eyebrow_08_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_08_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_08_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_01_right: StringProperty(name='Eyebrow 01 Right',default='',description='')
	eyebrow_01_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_01_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_01_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_02_right: StringProperty(name='Eyebrow 02 Right',default='',description='')
	eyebrow_02_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_02_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_02_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_03_right: StringProperty(name='Eyebrow 03 Right',default='',description='')
	eyebrow_03_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_03_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_03_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_04_right: StringProperty(name='Eyebrow 04 Right',default='',description='')
	eyebrow_04_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_04_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_04_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_05_right: StringProperty(name='Eyebrow 05 Right',default='',description='')
	eyebrow_05_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_05_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_05_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_06_right: StringProperty(name='Eyebrow 06 Right',default='',description='')
	eyebrow_06_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_06_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_06_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_07_right: StringProperty(name='Eyebrow 07 Right',default='',description='')
	eyebrow_07_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_07_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_07_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_08_right: StringProperty(name='Eyebrow 08 Right',default='',description='')
	eyebrow_08_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	eyebrow_08_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	eyebrow_08_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	facial_cheeks: BoolProperty(default=False)
	cheek_smile_left: StringProperty(default='')
	cheek_smile_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	cheek_smile_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	cheek_smile_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	cheek_left: StringProperty(default='')
	cheek_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	cheek_sk_inflate_left: StringProperty(default=sk_default_value,description=sk_descript)
	cheek_smile_right: StringProperty(default='')
	cheek_smile_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	cheek_smile_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	cheek_smile_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	cheek_right: StringProperty(default='')
	cheek_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	cheek_sk_inflate_right: StringProperty(default=sk_default_value,description=sk_descript)
	facial_nose: BoolProperty(default=False)
	nose_root: StringProperty(name='Nose Root',default='',description='')
	nose_tip1: StringProperty(name='Nose Tip 1',default='',description='')
	nose_tip2: StringProperty(name='Nose Tip 2',default='',description='')
	facial_mouth: BoolProperty(default=True)
	jaw: StringProperty(name='Jaw',default='',description='颌骨骨骼')
	jaw_sk: BoolProperty(default=False,description=sk_toggle_descript)
	jaw_sk_open: StringProperty(default=sk_default_value,description=sk_descript)
	jaw_sk_left: StringProperty(default=sk_default_value,description=sk_descript)
	jaw_sk_right: StringProperty(default=sk_default_value,description=sk_descript)
	jaw_sk_forward: StringProperty(default=sk_default_value,description=sk_descript)
	lips_offset: BoolProperty(default=False,description='添加嘴唇偏移控制器')
	lips_offset_sk: BoolProperty(default=False,description=sk_toggle_descript)
	lips_offset_sk_up: StringProperty(default=sk_default_value,description=sk_descript)
	lips_offset_sk_down: StringProperty(default=sk_default_value,description=sk_descript)
	lips_offset_sk_left: StringProperty(default=sk_default_value,description=sk_descript)
	lips_offset_sk_right: StringProperty(default=sk_default_value,description=sk_descript)
	lips_offset_sk_forward: StringProperty(default=sk_default_value,description=sk_descript)
	lips_roll_sk: BoolProperty(default=False,description=sk_toggle_descript)
	lips_roll_sk_up_out: StringProperty(default=sk_default_value,description=sk_descript)
	lips_roll_sk_up_in: StringProperty(default=sk_default_value,description=sk_descript)
	lips_roll_sk_low_out: StringProperty(default=sk_default_value,description=sk_descript)
	lips_roll_sk_low_in: StringProperty(default=sk_default_value,description=sk_descript)
	lips_amount: IntProperty(default=2,min=0,max=8)
	lip_top_mid: StringProperty(name='Lip Top Mid',default='',description='')
	lip_top_mid_sk: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_mid_sk_up: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_mid_sk_down: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_01_left: StringProperty(name='Lip Top 01 Left',default='',description='')
	lip_top_01_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_01_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_01_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_02_left: StringProperty(name='Lip Top 02 Left',default='',description='')
	lip_top_02_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_02_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_02_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_03_left: StringProperty(name='Lip Top 03 Left',default='',description='')
	lip_top_03_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_03_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_03_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_04_left: StringProperty(name='Lip Top 04 Left',default='',description='')
	lip_top_04_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_04_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_04_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_05_left: StringProperty(name='Lip Top 05 Left',default='',description='')
	lip_top_05_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_05_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_05_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_06_left: StringProperty(name='Lip Top 06 Left',default='',description='')
	lip_top_06_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_06_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_06_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_07_left: StringProperty(name='Lip Top 07 Left',default='',description='')
	lip_top_07_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_07_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_07_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_08_left: StringProperty(name='Lip Top 08 Left',default='',description='')
	lip_top_08_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_08_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_08_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_01_right: StringProperty(name='Lip Top 01 Right',default='',description='')
	lip_top_01_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_01_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_01_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_02_right: StringProperty(name='Lip Top 02 Right',default='',description='')
	lip_top_02_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_02_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_02_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_03_right: StringProperty(name='Lip Top 03 Right',default='',description='')
	lip_top_03_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_03_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_03_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_04_right: StringProperty(name='Lip Top 04 Right',default='',description='')
	lip_top_04_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_04_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_04_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_05_right: StringProperty(name='Lip Top 05 Right',default='',description='')
	lip_top_05_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_05_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_05_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_06_right: StringProperty(name='Lip Top 06 Right',default='',description='')
	lip_top_06_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_06_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_06_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_07_right: StringProperty(name='Lip Top 07 Right',default='',description='')
	lip_top_07_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_07_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_07_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_08_right: StringProperty(name='Lip Top 08 Right',default='',description='')
	lip_top_08_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_top_08_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_top_08_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_corner_left: StringProperty(name='Lip Corner Left',default='',description='')
	lip_corner_left_sk: BoolProperty(default=False,description=sk_toggle_descript)
	lip_corner_left_sk_up: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_corner_left_sk_down: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_corner_left_sk_out: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_corner_left_sk_in: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_corner_right: StringProperty(name='Lip Corner Right',default='',description='')
	lip_corner_right_sk: BoolProperty(default=False,description=sk_toggle_descript)
	lip_corner_right_sk_up: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_corner_right_sk_down: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_corner_right_sk_out: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_corner_right_sk_in: StringProperty(name='',default=sk_default_value,description=sk_descript)
	lip_bot_mid: StringProperty(name='Lip Bot Mid',default='',description='')
	lip_bot_mid_sk: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_mid_sk_up: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_mid_sk_down: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_01_left: StringProperty(name='Lip Bot 01 Left',default='',description='')
	lip_bot_01_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_01_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_01_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_02_left: StringProperty(name='Lip Bot 02 Left',default='',description='')
	lip_bot_02_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_02_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_02_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_03_left: StringProperty(name='Lip Bot 03 Left',default='',description='')
	lip_bot_03_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_03_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_03_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_04_left: StringProperty(name='Lip Bot 04 Left',default='',description='')
	lip_bot_04_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_04_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_04_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_05_left: StringProperty(name='Lip Bot 05 Left',default='',description='')
	lip_bot_05_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_05_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_05_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_06_left: StringProperty(name='Lip Bot 06 Left',default='',description='')
	lip_bot_06_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_06_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_06_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_07_left: StringProperty(name='Lip Bot 07 Left',default='',description='')
	lip_bot_07_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_07_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_07_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_08_left: StringProperty(name='Lip Bot 08 Left',default='',description='')
	lip_bot_08_sk_left: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_08_sk_up_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_08_sk_down_left: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_01_right: StringProperty(name='Lip Bot 01 Right',default='',description='')
	lip_bot_01_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_01_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_01_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_02_right: StringProperty(name='Lip Bot 02 Right',default='',description='')
	lip_bot_02_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_02_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_02_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_03_right: StringProperty(name='Lip Bot 03 Right',default='',description='')
	lip_bot_03_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_03_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_03_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_04_right: StringProperty(name='Lip Bot 04 Right',default='',description='')
	lip_bot_04_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_04_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_04_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_05_right: StringProperty(name='Lip Bot 05 Right',default='',description='')
	lip_bot_05_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_05_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_05_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_06_right: StringProperty(name='Lip Bot 06 Right',default='',description='')
	lip_bot_06_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_06_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_06_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_07_right: StringProperty(name='Lip Bot 07 Right',default='',description='')
	lip_bot_07_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_07_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_07_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_08_right: StringProperty(name='Lip Bot 08 Right',default='',description='')
	lip_bot_08_sk_right: BoolProperty(default=False,description=sk_toggle_descript)
	lip_bot_08_sk_up_right: StringProperty(default=sk_default_value,description=sk_descript)
	lip_bot_08_sk_down_right: StringProperty(default=sk_default_value,description=sk_descript)
	tongues_amount: IntProperty(default=0,min=0,max=8)
	tongue_01: StringProperty(name='Tongue 01',default='')
	tongue_02: StringProperty(name='Tongue 02',default='')
	tongue_03: StringProperty(name='Tongue 03',default='')
	tongue_04: StringProperty(name='Tongue 04',default='')
	tongue_05: StringProperty(name='Tongue 05',default='')
	tongue_06: StringProperty(name='Tongue 06',default='')
	tongue_07: StringProperty(name='Tongue 07',default='')
	tongue_08: StringProperty(name='Tongue 08',default='')
	facial_teeth: BoolProperty(default=False,description='启用牙齿骨骼')
	teeth_top_mid: StringProperty(name='Teeth top mid',default='',description='')
	teeth_top_left: StringProperty(name='Teeth top left',default='',description='')
	teeth_top_right: StringProperty(name='Teeth top right',default='',description='')
	teeth_bot_mid: StringProperty(name='Teeth bot mid',default='',description='')
	teeth_bot_left: StringProperty(name='Teeth bot left',default='',description='')
	teeth_bot_right: StringProperty(name='Teeth bot right',default='',description='')
	facial_chin: BoolProperty(default=False,description='启用下巴骨骼')
	chin_01: StringProperty(name='Chin 01',default='',description='')
	chin_02: StringProperty(name='Chin 02',default='',description='')
	dupli_idx: StringProperty(default='')
class ARP_UL_quick_limbs_list(UIList):
	"""
	@classmethod
	def poll(cls,context):
		return
	"""
	def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
		layout.prop(item, "name",text="",emboss=False,translate=False)
	def invoke(self,context,event):
		pass
class ARP_OT_quick_export_mapping(Operator):
	"""导出骨骼映射到文件"""
	bl_idname= "arp.quick_export_mapping";bl_label=g("Export bones mapping")
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	filter_glob: StringProperty(default=g("*.py"),options={'HIDDEN'})
	filepath: StringProperty(subtype="FILE_PATH",default=g('py'))
	def execute(self,context):
		_export_mapping(self.filepath)
		return {'FINISHED'}
	def invoke(self,context,event):
		self.filepath= 'quick_rig_mapping.py'
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}
class ARP_OT_quick_import_mapping(Operator):
	"""导入骨骼映射"""
	bl_idname= "arp.quick_import_mapping";bl_label=g("Import bones mapping")
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	filter_glob: StringProperty(default=g("*.py"),options={'HIDDEN'})
	filepath: StringProperty(subtype="FILE_PATH",default=g('py'))
	@classmethod
	def poll(cls,context):
		if context.active_object:
			if context.active_object.type== "ARMATURE":
				return True
	def execute(self,context):
		scn=bpy.context.scene
		try:
			scn.arp_quick_hold_update=True
			for i in range(0,len(scn.limb_map)):
				_remove_limb()
			_import_mapping(self)
		finally:
			scn.arp_quick_hold_update=False
		return {'FINISHED'}
	def invoke(self,context,event):
		self.filepath= 'quick_rig_mapping.py'
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}
class ARP_OT_quick_freeze_armature(Operator):
	"""清理来自骨架对象的动画数据，并初始化其变换。保留骨骼动画"""
	bl_idname= "arp.quick_freeze_armature";bl_label=g("quick_freeze_armature");bl_options={'UNDO'}
	@classmethod
	def poll(cls,context):
		if context.active_object.type== "ARMATURE":
			return True
	def execute(self,context):
		use_global_undo=context.preferences.edit.use_global_undo
		context.preferences.edit.use_global_undo=False
		try:
			_freeze_armature()
		finally:
			context.preferences.edit.use_global_undo=use_global_undo
		return {'FINISHED'}
class ARP_OT_quick_set_weight_override(Operator):
	"""为选定的骨骼设置权重覆盖"""
	bl_idname= "arp.quick_set_weight_override";bl_label=g("Override weight with this bone:");bl_options={'UNDO'}
	"""
	@classmethod
	def poll(cls,context):
		if context.active_object:
			return context.active_object.type== "ARMATURE"
		return False
	"""
	value: StringProperty(default="")
	def invoke(self,context,event):
		wm=context.window_manager
		return wm.invoke_props_dialog(self)
	def draw(self,context):
		layout=self.layout
		scn=context.scene
		limb=scn.limb_map[scn.limb_map_index]
		row=layout.column().row(align=True)
		row.prop(limb, "override_"+self.value,text="")
		row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "override_"+self.value
	def execute(self,context):
		print("")
		return {'FINISHED'}
class ARP_OT_quick_revert(Operator):
	"""恢复为原点骨架和权重"""
	bl_idname= "arp.quick_revert";bl_label=g("Revert");bl_options={'UNDO'}
	meshes_parented_to_bones={}
	skin_dict={}
	error_mess= ''
	def execute(self,context):
		self.error_mess= ''
		def show_error(_error_message):
			ARP_OT_quick_report_message.message=_error_message
			ARP_OT_quick_report_message.icon_type= 'ERROR'
			bpy.ops.arp.quick_report_message('INVOKE_DEFAULT')
		try:
			_revert(self)
		finally:
			if self.error_mess != '':
				show_error(self.error_mess)
		return {'FINISHED'}
class ARP_OT_quick_make_rig(Operator):
	"""从所选骨架生成Auto Rig Pro骨架"""
	bl_idname= "arp.quick_make_rig";bl_label=g("Make Rig!");bl_options={'UNDO'}
	mode: EnumProperty(items=(('CONVERT', 'Convert', '将当前骨架转换为自动装配Pro骨架，更改骨骼名称和轴。\n符合Auto Rig Pro版本和导出工具'),('PRESERVE', 'Preserve', '保留当前骨架的原样，仅将Auto Rig Pro控制器附加到它。\n不符合Auto Rig Pro版本和导出工具')))
	match_to_rig: BoolProperty(name="Match to Rig",default=True,description="使用“匹配到绑定”(Match to rig)完成绑定生成，否则显示参考骨骼")
	animation: EnumProperty(name='Animation',items=(('ANIM_BAKE', 'Bake Animation', '烘焙动画(重映射重定目标)'),('ANIM_BIND', 'Bind Only (Remap)', '绑定动画(重映射仅绑定仅)'),('NO_ANIM', 'No Animation', '不烘焙动画')),default='NO_ANIM')
	show_in_front: BoolProperty(name="Show In Front",default=True,description="在其它对象之前显示绑定控制器(类似X射线)，以便内部网格的控制器可视")
	remove_root: BoolProperty(name="Remove Root",default=True,description='移除任何命名的骨骼"Root" (不区分大小写)在骨架的根处')
	neck_auto_twist: BoolProperty(default=False,description="颈部使用自动扭曲骨骼")
	hide_base_armature: BoolProperty(name="Hide Base Armature",default=True,description="隐藏现有骨架")
	match_origin: BoolProperty(name="Same Origin",default=True,description="匹配控制绑定原点点与骨架原点，否则将其保留在世界中心(0,0,0")
	orphan_bones_shape: EnumProperty(name="Orphan Bones Shape",items=(('NONE', 'None', '无'),('cs_sphere', 'cs_sphere', 'cs_sphere'),('cs_box', 'cs_box', 'cs_box')),description="肢体定义中未使用的孤立骨骼的自定义骨骼形状",default="cs_sphere")
	orphan_bones_scale: FloatProperty(name="Orphan Bones Scale",default=0.5,description="孤儿骨骼的自定义形状缩放")
	orphan_bones_layer: IntProperty(name="Orphan Bones Layer",default=0,description="在此层索引中设置孤立骨骼",min=0,max=31)
	orphan_bones_collection: EnumProperty(items=(('Main','Main',"主集合"),('Secondary', 'Secondary', '第二集合'),('Orphan Bones', 'Orphan Bones', '孤儿骨骼集合')),default='Main',description='将孤儿骨骼添加到的集合')
	orphan_copy_cns: BoolProperty(name="Copy Constraints",default=False,description='复制孤立骨骼约束')
	retarget_sk_drivers: BoolProperty(name="Retarget Shape Keys Drivers",default=False,description='将驱动程序从源骨骼重定目标到控制器')
	preserve_volume: BoolProperty(name="Preserve Volume",default=False,description="使用对偶四元数蒙皮(保留体积)或线性蒙皮")
	color_orphan_group: FloatVectorProperty(name="Color Orphan Bones",subtype="COLOR_GAMMA",default=(1.0,1.0,0.0),min=0.0,max=1.0,description="孤立控制器颜色")
	arm_ik_fk: EnumProperty(items=(('IK', 'IK', 'IK'),('FK', 'FK', 'FK')),default='FK',description='臂运动学模式')
	leg_ik_fk: EnumProperty(items=(('IK', 'IK', 'IK'),('FK', 'FK', 'FK')),default='IK',description='腿运动学模式')
	orphan_bones_loc_retarget: EnumProperty(items=(('IK', 'Global', 'IK'),('LOCAL', 'Local', '局部')),default='IK',description='将孤立骨骼重新定位到位置的空间系统')
	orphan_bones_parent_to_def: BoolProperty(default=False,description='如果可能，父级将骨骼孤立为在肢体列表中设置的主骨骼，而不是另一个孤立骨骼作为父级')
	base_armature_name= ''
	base_armature_pos=None
	arp_armature_name= ''
	orphan_bones_dict={}
	source_anim_rig_name= ''
	fingers_ctrl={}
	toes_ctrl={}
	tail_ctrl={}
	meshes_parented_to_bones={}
	skin_dict={}
	arp_ver_int=37710
	arp_light=False
	error_mess= ''
	@classmethod
	def poll(cls,context):
		if context.active_object:
			return context.active_object.type== "ARMATURE"
		return False
	def restore_base_arm_loc(self):
		base_armature=get_object(self.base_armature_name)
		print("restore base armature loc:",self.base_armature_name)
		base_armature.location=self.base_armature_pos
		bpy.context.evaluated_depsgraph_get().update()
	def invoke(self,context,event):
		def show_error(_error_message):
			ARP_OT_quick_report_message.message=_error_message
			ARP_OT_quick_report_message.icon_type= 'ERROR'
			bpy.ops.arp.quick_report_message('INVOKE_DEFAULT')
		self.error_mess= ''
		self.arp_light=False
		self.fingers_ctrl={}
		self.toes_ctrl={}
		self.tail_ctrl={}
		self.meshes_parented_to_bones={}
		self.skin_dict={}
		self.base_armature_name=bpy.context.active_object.name
		base_armature=get_object(self.base_armature_name)
		self.base_armature_pos=base_armature.location.copy()
		scn=context.scene
		if CKD('auto_rig_pro_master')==False:
			show_error('Auto-Rig Pro is not installed.\nInstall it first,it is required to use Quick Rig')
			return {"FINISHED"}
		if len(scn.limb_map)==0:
			show_error('No limbs found,cannot generate rig. Add limbs first.')
			return {"FINISHED"}
		limbs_count_dict={"heads.x":0, "spines.x":0}
		for limb_item in scn.limb_map:
			if limb_item.type== "HEAD":
				limbs_count_dict["heads.x"]=limbs_count_dict["heads.x"]+1
			elif limb_item.type== "SPINE":
				limbs_count_dict["spines.x"]=limbs_count_dict["spines.x"]+1
		for limb in limbs_count_dict:
			if limbs_count_dict[limb] > 1:
				show_error('Multiple limbs of the same type and same side found,not supported yet.\nRemove duplicates (Head,Spine)')
				return {"FINISHED"}
		for limb in scn.limb_map:
			if limb.type== "LEG":
				bone_names=[]
				if limb.leg_type== "2":
					bone_names=["thigh", "calf", "foot"]
					req_bones=[limb.bone_01,limb.bone_03,limb.bone_05]
				elif limb.leg_type.startswith('3'):
					bone_names=["upper_thigh", "thigh", "calf", "foot"]
					req_bones=[limb.upper_thigh,limb.bone_01,limb.bone_03,limb.bone_05]
				'''# disable twist check for now... some skeletons have twist bones for thigh but not calf
				if limb.twist_bones_amount > 1:
					req_bones.append(limb.bone_02)
					bone_names.append('Thigh Twist 01')
					req_bones.append(limb.bone_04)
					bone_names.append('Calf Twist 01')
					for i in range(2,limb.twist_bones_amount+1):
						id= '%02d' % (i)
						req_bones.append(get_limb_prop(limb, 'bone_twist_'+id+'_01'))
						bone_names.append('Thigh Twist '+id)
						req_bones.append(get_limb_prop(limb, 'bone_twist_'+id+'_02'))
						bone_names.append('Calf Twist '+id)
				'''
				for i,n in enumerate(req_bones):
					if n== '' or n==None or base_armature.data.bones.get(n)==None:
						show_error('Error: Leg '+limb.side.lower()+' is missing required input bones: '+str(bone_names[i]).upper())
						return {"FINISHED"}
			elif limb.type== "ARM":
				bone_names=["arm", "forearm", "hand"]
				req_bones=[limb.bone_02,limb.bone_04,limb.bone_06]
				'''# disable twist check for now... some skeletons have twist bones for upperarm but not foerarm
				if limb.twist_bones_amount > 1:
					req_bones.append(limb.bone_03)
					bone_names.append('Arm Twist 01')
					req_bones.append(limb.bone_05)
					bone_names.append('Forearm Twist 01')
					for i in range(2,limb.twist_bones_amount+1):
						id= '%02d' % (i)
						req_bones.append(get_limb_prop(limb, 'bone_twist_'+id+'_01'))
						bone_names.append('Arm Twist '+id)
						req_bones.append(get_limb_prop(limb, 'bone_twist_'+id+'_02'))
						bone_names.append('Forearm Twist '+id)
				'''
				for i,n in enumerate(req_bones):
					if n== "" or n==None or base_armature.data.bones.get(n)==None:
						show_error('Error: Arm '+limb.side.lower()+' is missing required input bones: '+str(bone_names[i]).upper())
						return {"FINISHED"}
			elif limb.type== "SPINE":
				for n in [limb.bone_01]:
					if n== '' or base_armature.data.bones.get(n)==None:
						show_error("Error: Spine is missing required input bones")
						return {"FINISHED"}
			elif limb.type== "HEAD":
				if limb.bone_02== "" or base_armature.data.bones.get(limb.bone_02)==None:
					show_error("Error: Head is missing required input bones")
					return {"FINISHED"}
				if limb.bone_04 != "":
					if limb.bone_01== "" or base_armature.data.bones.get(limb.bone_04)==None or base_armature.data.bones.get(limb.bone_01)==None:
						show_error("Error: Head is missing required input bones")
						return {"FINISHED"}
				if limb.neck_bones_amount > 1:
					necks_list=[limb.bone_04,limb.neck3,limb.neck4,limb.neck5,limb.neck6,limb.neck7,limb.neck8,limb.neck9,limb.neck10]
					for i in range(2,limb.neck_bones_amount+1):
						cur_neck=necks_list[i-2]
						if cur_neck== "" or base_armature.data.bones.get(cur_neck)==None:
							limb.neck_bones_amount=i-1
			elif limb.type== 'TAIL':
				if limb.bone_01== '' or base_armature.data.bones.get(limb.bone_01)==None:
					show_error("Error: Tail is missing required input bones")
					return {"FINISHED"}
		wm=context.window_manager
		return wm.invoke_props_dialog(self)
	def draw(self,context):
		scn=context.scene
		layout=GG(self.layout)
		GE(layout,self,"mode",text="Mode")
		GE(layout,self, "animation",text="Animation")
		if self.arp_light:
			if self.animation != 'NO_ANIM':
				GL(layout,"Auto-Rig Pro Full version is required for animation",icon='ERROR')
		else:
			if self.animation== 'ANIM_BAKE':
				GO(layout,'arp.batch_retarget',text='Multiple Anims...')
				col=layout.column()
				GE(layout,self, 'orphan_bones_loc_retarget',text='Orphan Bones Locations')
				layout.separator()
		GE(layout,self, "arm_ik_fk",text="Arms")
		GE(layout,self, "leg_ik_fk",text="Legs")
		R=layout.row()
		GP(R,self, "neck_auto_twist",text="Neck Twist")
		GP(R,self, "remove_root",text='Ignore "Root" Bone')
		R=layout.row()
		GP(R,self, "match_to_rig",text="Match to Rig")
		R.enabled=True if self.animation== 'NO_ANIM' else False
		GP(R,self, "show_in_front",text="X-Ray Display")
		R=layout.row()
		GP(R,self, "preserve_volume",text="Preserve Volume")
		GP(R,self, "match_origin",text="Same Origin")
		if self.mode== 'CONVERT':
			GP(layout,self, "hide_base_armature",text="Hide Base Armature")
		layout.separator()
		GL(layout,"Orphan Bones:")
		GP(layout,self, 'orphan_bones_parent_to_def',text='Parent to Main Bones (when possible)')
		GP(layout,self, 'orphan_copy_cns',text='Copy Constraints')
		GP(layout,self, 'retarget_sk_drivers',text='Retarget Shape Keys Drivers')
		GE(layout,self, "orphan_bones_shape",text="Shape")
		GP(layout,self, "orphan_bones_scale",text="Scale")
		GP(layout,self, "color_orphan_group",text="Color")
		GE(layout,self, 'orphan_bones_layer' if bpy.app.version < (4,0,0) else 'orphan_bones_collection',text='Layer' if bpy.app.version < (4,0,0) else 'Collection')
		layout.separator()
	def execute(self,context):
		def show_error(_error_message):
			ARP_OT_quick_report_message.message=_error_message
			ARP_OT_quick_report_message.icon_type= 'ERROR'
			bpy.ops.arp.quick_report_message('INVOKE_DEFAULT')
		use_global_undo=context.preferences.edit.use_global_undo
		context.preferences.edit.use_global_undo=False
		scn=bpy.context.scene
		debug=True
		time_start=time.time()
		self.orphan_bones_dict={}# clear previous sessions data if any
		if self.arp_light:
			self.animation= "NO_ANIM"
		def execute_make_rig():
			if self.animation != 'NO_ANIM':
				print("-------------------------------------- ANIM--------------------------------------------------")
				rig=get_object(bpy.context.active_object.name)
				if rig.animation_data:
					if rig.animation_data.action:
						if len(bpy.context.selected_objects) > 1:
							for o in bpy.context.selected_objects:
								if o !=rig:
									o.select_set(state=False)
						bpy.ops.object.mode_set(mode='OBJECT')
						current_act_name=rig.animation_data.action.name
						act_list=[act.name for act in bpy.data.actions]
						duplicate_object()
						print('set self.source_anim_rig_name',rig.name+'_anim_TEMP')
						self.source_anim_rig_name=rig.name+'_ANIM_TEMP'
						bpy.context.active_object.name=self.source_anim_rig_name
						for act in bpy.data.actions:
							if not act.name in act_list:
								bpy.data.actions.remove(act)
						bpy.context.active_object.animation_data.action=bpy.data.actions.get(current_act_name)
						bpy.ops.object.mode_set(mode='OBJECT')
						bpy.ops.object.select_all(action='DESELECT')
						set_active_object(rig.name)
			_make_rig(self)
			if self.match_to_rig or self.animation != 'NO_ANIM':
				bpy.ops.arp.match_to_rig()
				bpy.ops.arp.reset_pose()
				if len(self.orphan_bones_dict):
					arp_armature=bpy.context.active_object
					enable_layer(self.orphan_bones_collection,idx=self.orphan_bones_layer)
					if bpy.app.version >=(4,0,0):
						sort_armature_collections(arp_armature,only_collection=self.orphan_bones_collection)
			base_arm=get_object(self.base_armature_name)
			if self.mode== 'CONVERT' and self.hide_base_armature:
				if base_arm:
					base_arm.hide_set(True)
			screen=bpy.context.screen
			for area in screen.areas:
				if area.type== "VIEW_3D":
					for space in area.spaces:
						try:
							space.overlay.show_xray_bone=self.show_in_front
						except:
							pass
			base_arm=get_object(self.base_armature_name)
			arp_arm=get_object(self.arp_armature_name)
			if self.match_origin:
				self.restore_base_arm_loc()
				rot_save,scale_save=arp_arm.rotation_euler.copy(),arp_arm.scale.copy()
				arp_arm.matrix_world=base_arm.matrix_world.copy()
				arp_arm.rotation_euler,arp_arm.scale=rot_save,scale_save
			if self.mode== 'CONVERT':
				_parent_meshes(self,base_arm,arp_arm)
			if self.animation != 'NO_ANIM':
				_remap_animation(self)
			elapsed_time=round((time.time() - time_start),1)
			GR(self,"INFO", "Rig done in "+str(elapsed_time)+' seconds')
		if debug:
			try:
				execute_make_rig()
			finally:
				context.preferences.edit.use_global_undo=use_global_undo
		else:
			try:
				execute_make_rig()
			except Exception as ex:
				error_message=get_error_message()
				GR(self,'ERROR',error_message)
				try:
					bpy.ops.object.mode_set(mode='OBJECT')
					set_active_object(self.arp_armature_name)
					bpy.ops.arp.delete_arp()
				except:
					pass
			finally:
				if self.match_origin:
					self.restore_base_arm_loc()
				if self.mode== 'PRESERVE':
					hide_layer('qr_helpers',idx=15)
				context.preferences.edit.use_global_undo=use_global_undo
		if self.error_mess != '':
			show_error(self.error_mess)
		return {'FINISHED'}
class ARP_OT_quick_mirror_facial(Operator):
	"""镜像全部面部骨骼，如果对面已定义，则自动填充空白输入"""
	bl_idname= "arp.quick_mirror_facial";bl_label=g("Mirror Facial");bl_options={"UNDO"}
	@classmethod
	def poll(cls,context):
		if context.active_object:
			if context.active_object:
				if context.active_object.type== 'ARMATURE':
					return True
		return False
	def execute(self,context):
		use_global_undo=context.preferences.edit.use_global_undo
		context.preferences.edit.use_global_undo=False
		try:
			_mirror_facial(self)
		finally:
			context.preferences.edit.use_global_undo=use_global_undo
		return {'FINISHED'}
class ARP_OT_quick_mirror_limb(Operator):
	"""镜像选定肢体\n轴设置可能无法正确镜像。\n骨骼名称必须包含左侧或右标识符，如_left或.l"""
	bl_idname= "arp.quick_mirror_limb";bl_label=g("Mirror Limb");bl_options={'UNDO'}
	mirrors_not_found=[]
	@classmethod
	def poll(cls,context):
		if context.active_object:
			if context.mode== "POSE" or context.mode== "EDIT_ARMATURE":
				return True
		return False
	def execute(self,context):
		use_global_undo=context.preferences.edit.use_global_undo
		context.preferences.edit.use_global_undo=False
		if len(bpy.context.scene.limb_map)==0:
			GR(self,'ERROR', 'No limbs to mirror. Add limbs first.')
			return {'FINISHED'}
		try:
			self.mirrors_not_found=[]
			_mirror_limb(self)
		finally:
			if len(self.mirrors_not_found):
				mess= 'Mirror bones not found:'
				for i in self.mirrors_not_found:
					mess += '\n'+i
				GR(self,'ERROR',mess)
			context.preferences.edit.use_global_undo=use_global_undo
		return {'FINISHED'}
class ARP_OT_quick_add_limb(Operator):
	"""添加肢体"""
	bl_idname= "arp.quick_add_limb";bl_label=g("Add Limb");bl_options={'UNDO'}
	@classmethod
	def poll(cls,context):
		if context.active_object:
			if context.mode== "POSE" or context.mode== "EDIT_ARMATURE":
				return True
		return False
	type: bpy.props.EnumProperty(name='Limb Type',items=(('LEG', 'Leg', '腿部'),('ARM', 'Arm', '手臂'),('SPINE', 'Spine', '脊椎'),('HEAD', 'Head', '头部'),('TAIL', 'Tail', '尾部')),description='肢体类型')
	def draw(self,context):
		layout=self.layout
		col=layout.column(align=True)
		first_bone_name= ''
		if self.type== 'LEG':
			first_bone_name= 'Thigh'
		elif self.type== 'ARM':
			first_bone_name= 'Shoulder'
		elif self.type== 'SPINE':
			first_bone_name= 'Pelvis'
		elif self.type== 'HEAD':
			first_bone_name= 'Neck'
		elif self.type== 'TAIL':
			first_bone_name= 'Tail root'
		GL(col,"Make sure the following first bone of the limb is selected")
		GL(col,"before clicking OK:")
		GL(col,first_bone_name)
		GE(layout,self,"type")
	def execute(self,context):
		use_global_undo=context.preferences.edit.use_global_undo
		context.preferences.edit.use_global_undo=False
		try:
			check_freeze_armature()
			_add_limb(self)
		finally:
			context.preferences.edit.use_global_undo=use_global_undo
		return {'FINISHED'}
	def invoke(self,context,event):
		sel_bone=context.active_bone
		if sel_bone:
			sel_bone_name=sel_bone.name.lower()
			if "shoulder" in sel_bone_name or "clavicle" in sel_bone_name:
				self.type= "ARM"
			elif "thigh" in sel_bone_name or "leg" in sel_bone_name:
				self.type= "LEG"
			elif "pelvis" in sel_bone_name or "root" in sel_bone_name or "hips" in sel_bone_name or "spine" in sel_bone_name:
				self.type= "SPINE"
			elif "neck" in sel_bone_name or "head" in sel_bone_name:
				self.type= "HEAD"
			else:
				self.type= 'TAIL'
		wm=context.window_manager
		return wm.invoke_props_dialog(self,width=400)
class ARP_OT_quick_remove_limb(Operator):
	"""移除选定肢体"""
	bl_idname= "arp.quick_remove_limb";bl_label=g("quick_remove_limb");bl_options={'UNDO'}
	"""
	@classmethod
	def poll(cls,context):
		if context.active_object:
			return context.active_object.type== "EMPTY"
	"""
	def execute(self,context):
		use_global_undo=context.preferences.edit.use_global_undo
		context.preferences.edit.use_global_undo=False
		try:
			_remove_limb()
		finally:
			context.preferences.edit.use_global_undo=use_global_undo
		return {'FINISHED'}
class ARP_OT_quick_pick_bone(Operator):
	"""拾取选定的骨骼"""
	bl_idname= "arp.quick_pick_bone";bl_label= "";bl_options={'UNDO'}
	def draw(S,_):L=S.layout;[GP(L,S,n) for n in S.__annotations__]
	value: StringProperty(default="")
	"""
	@classmethod
	def poll(cls,context):
		if context.active_object:
			return context.active_object.type== "EMPTY"
	"""
	def execute(self,context):
		use_global_undo=context.preferences.edit.use_global_undo
		context.preferences.edit.use_global_undo=False
		try:
			_pick_bone(self)
		finally:
			context.preferences.edit.use_global_undo=use_global_undo
		return {'FINISHED'}
def get_error_message():
	exc_type,exc_obj,tb=sys.exc_info()
	f=tb.tb_frame
	lineno=tb.tb_lineno
	filename=f.f_code.co_filename
	linecache.checkcache(filename)
	line=linecache.getline(filename,lineno,f.f_globals)
	error_message= 'Error in ({}\nLine {} "{}"): {}'.format(filename,lineno,line.strip(),exc_obj)
	return error_message
def pose_bone_constraints_from_dict(armature,pbone,cns_multi_dict):
	def get_constraint_target(target_name):
		if target_name==None:
			return None
		if target_name== "rig__self":
			return armature
		else:
			return get_object(target_name)
	for cns_dict in cns_multi_dict:
		new_cns=pbone.constraints.new(cns_dict["type"])
		for cns_prop in cns_dict:
			if cns_prop== "action":
				action_name=cns_dict[cns_prop]
				setattr(new_cns,cns_prop,bpy.data.actions.get(action_name))
			elif cns_prop== "type":
				continue
			elif cns_prop== "target" or cns_prop== "pole_target":
				target_name=cns_dict[cns_prop]
				setattr(new_cns,cns_prop,get_constraint_target(target_name))
				continue
			elif cns_prop== "targets":
				for tar in cns_dict[cns_prop]:
					tar_obj_name,tar_bone_name,tar_weight=tar[0],tar[1],tar[2]
					t=new_cns.targets.new()
					t.target=get_constraint_target(tar_obj_name)
					t.subtarget=tar_bone_name
					t.weight=tar_weight
				continue
			elif "subtarget" in cns_prop:
				setattr(new_cns,cns_prop,cns_dict[cns_prop])
				continue
			try:
				setattr(new_cns,cns_prop,cns_dict[cns_prop])
			except:
				pass
		'''
		if new_cns.type== "CHILD_OF":
			print("为的ChildOf约束设置反转矩阵:",pbone.name, "...")
			set_constraint_inverse_matrix(new_cns,pbone)
		'''
def pose_bones_constraints_to_dict(armature_object,pose_bones_list):
	bones_data={}
	exclude_cns_props=['__doc__', '__module__', '__slots__', 'active', 'bl_rna', 'error_location', 'error_rotation','is_proxy_local', 'is_valid', 'rna_type', 'joint_bindings']
	def get_constraint_relative_target(target):
		if target==armature_object:
			return "rig__self"
		else:
			return cns.target.name
	for pbone in pose_bones_list:
		if len(pbone.constraints)==0:
			continue
		cns_dict_list=[]
		for cns in pbone.constraints:
			cns_data={}
			for prop in dir(cns):
				if prop in exclude_cns_props or "matrix" in prop:
					continue
				if prop== "action":
					if cns.action:
						cns_data["action"]=cns.action.name
						continue
				if prop== "target":
					if cns.target:
						cns_data["target"]=get_constraint_relative_target(cns.target)
						continue
				if prop== "targets":
					targets_list=[]
					for tar in cns.targets:
						if tar==None:
							targets_list.append(["", "",tar.weight])
							continue
						tar_name=get_constraint_relative_target(tar.target)
						targets_list.append([tar_name,tar.subtarget,tar.weight])
					cns_data["targets"]=targets_list
					continue
				if prop== "pole_target":
					if cns.pole_target:
						cns_data["pole_target"]=get_constraint_relative_target(cns.pole_target)
					continue
				try:
					getattr(cns,prop)
				except:
					continue
				prop_val=getattr(cns,prop)
				if type(prop_val)==Vector:
					prop_val=[prop_val[0],prop_val[1],prop_val[2]]
				cns_data[prop]=prop_val
			cns_dict_list.append(cns_data)
		bones_data[pbone.name]=cns_dict_list
	return bones_data
def find_closest_match(word,word_list,threshold=0.6):
	closest_match=None
	closest_match_ratio=0
	valid_match=None
	while valid_match==None and threshold > 0.3:
		for candidate in word_list:
			ratio=difflib.SequenceMatcher(None,word,candidate).ratio()
			if ratio > closest_match_ratio:
				closest_match_ratio=ratio
				closest_match=candidate
		if closest_match_ratio >=threshold:
			valid_match=closest_match
		else:
			threshold -=0.1
	return valid_match
def set_mapping_from_dict(dict,armature,self):
	print("从从集合映射")
	scn=bpy.context.scene
	for limb_name in dict:
		item=None
		if limb_name in scn.limb_map:
			item=scn.limb_map[limb_name]
		else:
			item=scn.limb_map.add()
		prop_dict=dict[limb_name]
		for prop in prop_dict:
			prop_value=prop_dict[prop]
			def_bone_name=prop_value
			valid=True
			if prop.startswith("bone_") or prop.startswith("override_bone_") or prop in ["thumb", "index", "middle", "pinky", "ring"]:
				valid=False
				for b in armature.data.bones:
					if b.name==prop_value:
						valid=True
						break
				if not valid:
					preset_name= ""
					try:
						preset_name=self.preset_name
					except:
						pass
					if preset_name== "mixamo" or preset_name== "mixamo_old":
						for b in armature.data.bones:
							if ':' in b.name:
								prefix=b.name.split(':')[0]
								if b.name.replace(prefix+':', '')==prop_value.replace('mixamorig:', ''):
									def_bone_name=def_bone_name=b.name#'mixamorig:'+prop_value
									valid=True
									break
							else:
								if b.name==prop_value.replace('mixamorig:', ''):
									def_bone_name=b.name
									valid=True
									break
					if not valid:
						if hasattr(self, 'fuzzy_match') and self.fuzzy_match:
							closest_match=find_closest_match(prop_value,[b.name for b in armature.data.bones])
							if closest_match:
								def_bone_name=closest_match
								valid=True
			if valid:
				setattr(item,prop,def_bone_name)
	scn.limb_map_index=0
	valid=False
	for limb in scn.limb_map:
		for prop in dir(limb):
			if prop.startswith("bone_"):
				attr=getattr(limb,prop)
				if attr != "":
					valid=True
	return valid
def _import_mapping(self):
	print("import preset:",self.filepath)
	filepath=self.filepath
	scn=bpy.context.scene
	armature=bpy.context.active_object
	file=open(filepath, 'r') if sys.version_info >=(3,11) else open(filepath, 'rU')
	file_lines=file.readlines()
	mapping_dict_str=str(file_lines[0])
	file.close()
	mapping_dict=ast.literal_eval(mapping_dict_str)
	import_success=set_mapping_from_dict(mapping_dict,armature,self)
	return import_success
def _export_mapping(filepath):
	scn=bpy.context.scene
	if not filepath.endswith(".py"):
		filepath += ".py"
	file=open(filepath, "w",encoding="utf8",newline="\n")
	mapping_dict={}
	for limb_item in scn.limb_map:
		prop_list=[]
		for item_prop in dir(limb_item):
			if not item_prop.startswith("__") and item_prop != "bl_rna" and item_prop != "rna_type" and not item_prop.startswith('bl_system'):
				prop_list.append(item_prop)
		prop_dict={}
		for prop in prop_list:
			prop_dict[prop]=getattr(limb_item,prop)
		mapping_dict[limb_item.name]=prop_dict
	file.write(str(mapping_dict))
	file.close()
def _freeze_armature():
	context=bpy.context
	saved_frame=context.scene.frame_current
	context.scene.frame_set(bpy.context.scene.frame_current)
	bpy.context.scene.tool_settings.use_keyframe_insert_auto=False
	arm_name=context.active_object.name
	bpy.ops.object.mode_set(mode='OBJECT')
	bpy.ops.object.select_all(action='DESELECT')
	set_active_object(arm_name)
	base_arm_name=arm_name
	base_action_name= ""
	if context.active_object.animation_data:
		if context.active_object.animation_data.action:
			base_action_name=context.active_object.animation_data.action.name
	is_animated=False
	if base_action_name != "":
		for fcurve in get_action_fcurves(bpy.context.active_object.animation_data.action):
			if not "pose.bones" in fcurve.data_path:
				if "location"in fcurve.data_path or "rotation" in fcurve.data_path or "scale" in fcurve.data_path:
					is_animated=True
					break
	cur_act=None
	cur_rot=[bpy.context.active_object.rotation_euler.copy(),bpy.context.active_object.rotation_quaternion.copy()]
	if is_animated:
		cur_act=bpy.context.active_object.animation_data.action
		bpy.context.active_object.animation_data.action=None
		bpy.context.active_object.rotation_euler=[0,0,0]
		bpy.context.active_object.rotation_quaternion=[0,0,0,0]
	armature=get_object(arm_name)
	if len(armature.children):
		for obj in armature.children:
			if obj.type== "MESH":
				obj_mat=obj.matrix_world.copy()
				obj.parent=None
				bpy.context.evaluated_depsgraph_get().update()
				obj.matrix_world=obj_mat
		print("网格未租用")
	if is_animated:
		bpy.context.active_object.animation_data.action=cur_act
		bpy.context.active_object.rotation_euler=cur_rot[0]
		bpy.context.active_object.rotation_quaternion=cur_rot[1]
	if not is_animated:
		bpy.ops.object.transform_apply(location=False,rotation=True,scale=False)
		context.scene.arp_quick_freeze_check=False
		print("骨架旋转已初始化")
	else:
		bpy.context.active_object.rotation_euler=[0,0,0]
		bpy.context.active_object.rotation_quaternion=[0,0,0,0]
		bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},TRANSFORM_OT_translate={"value":(0,0,0), "remove_on_cancel":False, "release_confirm":False, "use_accurate":False})
		bpy.context.active_object.animation_data.action.name=base_action_name + "_TEMP_COPY"
		bpy.ops.object.mode_set(mode='POSE')
		for pbone in bpy.context.active_object.pose.bones:
			cns=pbone.constraints.new('COPY_TRANSFORMS')
			cns.target=bpy.data.objects[base_arm_name]
			cns.subtarget=pbone.name
			cns.name= "arp_remap_temp"
		bpy.context.scene.frame_set(0)
		fcurves=get_action_fcurves(bpy.context.active_object.animation_data.action)
		for fc_index,fc in enumerate(fcurves):
			if not "pose.bones" in fc.data_path:
				if "rotation" in fc.data_path or "location" in fc.data_path or "scale" in fc.data_path:
					delete_fcurve(bpy.context.active_object.animation_data.action,fc)
		bpy.ops.object.mode_set(mode='OBJECT')
		bpy.ops.object.transform_apply(location=True,rotation=True,scale=False)
		frame_range=bpy.context.active_object.animation_data.action.frame_range
		bake_anim(frame_start=frame_range[0],frame_end=frame_range[1],only_selected=False,bake_bones=True,bake_object=False)
		for pbone in bpy.context.active_object.pose.bones:
			pbone.constraints.remove(pbone.constraints["arp_remap_temp"])
		for obj in bpy.data.objects:
			if obj.type != "MESH":
				continue
			for mod in obj.modifiers:
				if mod.type != "ARMATURE":
					continue
				mod.object=bpy.context.active_object
		bpy.data.objects.remove(bpy.data.objects[base_arm_name],do_unlink=True)
		bpy.context.active_object.name=base_arm_name
		bpy.data.actions.remove(bpy.data.actions[base_action_name],do_unlink=True)
		try:
			bpy.data.actions.remove(bpy.data.actions[base_action_name + "_TEMP_COPY"],do_unlink=True)
		except:
			pass
		bpy.context.active_object.animation_data.action.name=base_action_name
		context.scene.frame_set(saved_frame)
		context.scene.arp_quick_freeze_check=False
		print("骨架现在静止不动.")
def check_freeze_armature():
	context=bpy.context
	if context.active_object.type== "ARMATURE":
		arm_obj=bpy.data.objects[context.active_object.name]
		for rot_axis in arm_obj.rotation_euler:
			if round(rot_axis,3) !=0.0:
				context.scene.arp_quick_freeze_check=True
				return
		if arm_obj.animation_data:
			if arm_obj.animation_data.action:
				for fcurve in get_action_fcurves(arm_obj.animation_data.action):
					if not fcurve.data_path.startswith("pose.bones"):
						if "location" in fcurve.data_path or "rotation" in fcurve.data_path or "scale" in fcurve.data_path:
							context.scene.arp_quick_freeze_check=True
							return
	else:
		context.scene.arp_quick_freeze_check=False
def bake_anim(frame_start=0,frame_end=10,only_selected=False,bake_bones=True,bake_object=False):
	scn=bpy.context.scene
	obj_data=[]
	bones_data=[]
	armature=get_object(bpy.context.active_object.name)
	def get_bones_matrix():
		matrix={}
		for pbone in armature.pose.bones:
			if only_selected and not pbone.bone.select:
				continue
			matrix[pbone.name]=armature.convert_space(pose_bone=pbone,matrix=pbone.matrix,from_space="POSE",to_space="LOCAL")
		return matrix
	def get_obj_matrix():
		parent=armature.parent
		matrix=armature.matrix_world
		if parent:
			return parent.matrix_world.inverted_safe() @ matrix
		else:
			return matrix.copy()
	current_frame=scn.frame_current
	for f in range(int(frame_start),int(frame_end+1)):
		scn.frame_set(f)
		bpy.context.view_layer.update()
		if bake_bones:
			bones_data.append((f,get_bones_matrix()))
		if bake_object:
			obj_data.append((f,get_obj_matrix()))
	action=bpy.data.actions.new("Action")
	anim_data=armature.animation_data_create()
	anim_data.action=action
	def store_keyframe(bone_name,prop_type,fc_array_index,frame,value):
		fc_data_path= 'pose.bones["' + bone_name + '"].' + prop_type
		fc_key=(fc_data_path,fc_array_index)
		if not keyframes.get(fc_key):
			keyframes[fc_key]=[]
		keyframes[fc_key].extend((frame,value))
	if bake_bones:
		for pbone in armature.pose.bones:
			if only_selected and not pbone.bone.select:
				continue
			euler_prev=None
			quat_prev=None
			keyframes={}
			for (f,matrix) in bones_data:
				pbone.matrix_basis=matrix[pbone.name].copy()
				for arr_idx,value in enumerate(pbone.location):
					store_keyframe(pbone.name, "location",arr_idx,f,value)
				rotation_mode=pbone.rotation_mode
				if rotation_mode== 'QUATERNION':
					if quat_prev is not None:
						quat=pbone.rotation_quaternion.copy()
						quat.make_compatible(quat_prev)
						pbone.rotation_quaternion=quat
						quat_prev=quat
						del quat
					else:
						quat_prev=pbone.rotation_quaternion.copy()
					for arr_idx,value in enumerate(pbone.rotation_quaternion):
						store_keyframe(pbone.name, "rotation_quaternion",arr_idx,f,value)
				elif rotation_mode== 'AXIS_ANGLE':
					for arr_idx,value in enumerate(pbone.rotation_axis_angle):
						store_keyframe(pbone.name, "rotation_axis_angle",arr_idx,f,value)
				else:
					if euler_prev is not None:
						euler=pbone.rotation_euler.copy()
						euler.make_compatible(euler_prev)
						pbone.rotation_euler=euler
						euler_prev=euler
						del euler
					else:
						euler_prev=pbone.rotation_euler.copy()
					for arr_idx,value in enumerate(pbone.rotation_euler):
						store_keyframe(pbone.name, "rotation_euler",arr_idx,f,value)
				for arr_idx,value in enumerate(pbone.scale):
					store_keyframe(pbone.name, "scale",arr_idx,f,value)
			for fc_key,key_values in keyframes.items():
				data_path,index=fc_key
				fcurve=find_fcurve(action,data_path,fc_index=index)
				if fcurve==None:
					create_fcurve(action,data_path,fc_index=index,action_group=pbone.name)
				num_keys=len(key_values) // 2
				fcurve.keyframe_points.add(num_keys)
				fcurve.keyframe_points.foreach_set('co',key_values)
				if bpy.app.version >=(2,90,0):
					linear_enum_value=bpy.types.Keyframe.bl_rna.properties['interpolation'].enum_items['LINEAR'].value
					fcurve.keyframe_points.foreach_set('interpolation',(linear_enum_value,) * num_keys)
				else:
					for kf in fcurve.keyframe_points:
						kf.interpolation= 'LINEAR'
	if bake_object:
		euler_prev=None
		quat_prev=None
		for (f,matrix) in obj_data:
			name= "Action Bake"
			armature.matrix_basis=matrix
			armature.keyframe_insert("location",index=-1,frame=f,group=name)
			rotation_mode=armature.rotation_mode
			if rotation_mode== 'QUATERNION':
				if quat_prev is not None:
					quat=armature.rotation_quaternion.copy()
					quat.make_compatible(quat_prev)
					armature.rotation_quaternion=quat
					quat_prev=quat
					del quat
				else:
					quat_prev=armature.rotation_quaternion.copy()
				armature.keyframe_insert("rotation_quaternion",index=-1,frame=f,group=name)
			elif rotation_mode== 'AXIS_ANGLE':
				armature.keyframe_insert("rotation_axis_angle",index=-1,frame=f,group=name)
			else:
				if euler_prev is not None:
					euler=armature.rotation_euler.copy()
					euler.make_compatible(euler_prev)
					armature.rotation_euler=euler
					euler_prev=euler
					del euler
				else:
					euler_prev=armature.rotation_euler.copy()
				armature.keyframe_insert("rotation_euler",index=-1,frame=f,group=name)
			armature.keyframe_insert("scale",index=-1,frame=f,group=name)
	scn.frame_set(current_frame)
def init_arp_scale(rig):
	if rig.scale==Vector((1.0,1.0,1.0)):
		return
	bpy.ops.object.mode_set(mode='OBJECT')
	bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
	bpy.ops.object.mode_set(mode='POSE')
	for pbone in bpy.context.active_object.pose.bones:
		if len(pbone.constraints):
			for cns in pbone.constraints:
				if cns.type != "STRETCH_TO":
					continue
				cns.rest_length=0.0
def find_primary_axis(bones_list,multi=False):
	multi_axes=[]
	first_primary_axis=None
	for i,bname in enumerate(bones_list):
		ebone=get_edit_bone(bname)
		if ebone==None:
			if multi:
				multi_axes.append('Y')
			continue
		if len(bones_list)==1:
			if multi:
				multi_axes.append('Y')
			else:
				return 'Y'
		if first_primary_axis==None or multi:
			if multi and i==len(bones_list)-1:
				multi_axes.append(multi_axes[len(multi_axes)-1])
				break
			child_idx=i+1
			child_ebone=get_edit_bone(bones_list[child_idx])
			dist_x=dist_y=dist_z=neg_dist_x=neg_dist_y=neg_dist_z=0.0
			point_on_vec=ebone.head + ebone.x_axis.normalized()
			dist_x=(child_ebone.head - point_on_vec).magnitude
			point_on_vec=ebone.head - ebone.x_axis.normalized()
			neg_dist_x=(child_ebone.head - point_on_vec).magnitude
			point_on_vec=ebone.head + ebone.y_axis.normalized()
			dist_y=(child_ebone.head - point_on_vec).magnitude
			point_on_vec=ebone.head - ebone.y_axis.normalized()
			neg_dist_y=(child_ebone.head - point_on_vec).magnitude
			point_on_vec=ebone.head + ebone.z_axis.normalized()
			dist_z=(child_ebone.head - point_on_vec).magnitude
			point_on_vec=ebone.head - ebone.z_axis.normalized()
			neg_dist_z=(child_ebone.head - point_on_vec).magnitude
			shortest_dist=sorted([dist_x,neg_dist_x,dist_y,neg_dist_y,dist_z,neg_dist_z])[0]
			if shortest_dist==dist_x:
				primary_axis= "X"
			elif shortest_dist==neg_dist_x:
				primary_axis= "-X"
			elif shortest_dist==dist_y:
				primary_axis= "Y"
			elif shortest_dist==neg_dist_y:
				primary_axis= "-Y"
			elif shortest_dist==dist_z:
				primary_axis= "Z"
			elif shortest_dist==neg_dist_z:
				primary_axis= "-Z"
			print("Primary Axis:",bname,primary_axis)
			if first_primary_axis==None:
				first_primary_axis=primary_axis
			if multi:
				multi_axes.append(primary_axis)
			else:
				break
	if first_primary_axis==None:
		first_primary_axis= "Y"
	if multi:
		print('multi_axes:',multi_axes)
		return first_primary_axis, ', '.join(multi_axes)
	else:
		return first_primary_axis
def reverse_dict(dico):
	new_dict={}
	if type(dico) !=dict:
		dico=dico.to_dict()
	for entry in dico:
		keys=dico[entry]
		if 'deform' in keys:
			new_dict[keys['deform']]=entry
		else:
			new_dict[keys]=entry
	return new_dict
def _revert(self):
	arp_armature=get_object(bpy.context.active_object.name)
	data=None
	preserved=False
	if 'arp_locked' in arp_armature.data.keys():
		preserved=True
	if len(arp_armature.data.keys()):
		if "arp_qr_data" in arp_armature.data.keys():
			data=arp_armature.data["arp_qr_data"]
	if data==None:
		err_mess= "Could not find quick rig data,exit"
		print(err_mess)
		GR(self,"ERROR",err_mess)
		return
	bpy.ops.object.mode_set(mode='POSE')
	for pbone in arp_armature.pose.bones:
		pbone.location=[0,0,0]
		pbone.scale=[1,1,1]
		pbone.rotation_euler=[0,0,0]
		pbone.rotation_quaternion=[1,0,0,0]
	base_armature_name=data["base_armature"]
	base_armature=get_object(base_armature_name)
	if base_armature==None:
		err_mess= "Base armature '"+base_armature_name+"' deleted,cannot revert"
		print(err_mess)
		GR(self,"ERROR",err_mess)
		return
	base_armature.hide_set(False)
	skinned_objects_dict=data["skinned_objects"]
	if type(skinned_objects_dict) !=dict:
		skinned_objects_dict=skinned_objects_dict.to_dict()
	meshes_parented_to_bones=data["meshes_parented_to_bones"]
	if type(meshes_parented_to_bones) !=dict:
		meshes_parented_to_bones=meshes_parented_to_bones.to_dict()
	meshes_transf_dict=None
	if 'meshes_transf' in data.keys():
		meshes_transf_dict=data['meshes_transf']
		if type(meshes_transf_dict) !=dict:
			meshes_transf_dict=meshes_transf_dict.to_dict()
	skin_dict=reverse_dict(data["vgroups"])
	for m_name in skinned_objects_dict:
		obj=get_object(m_name)
		if obj==None:
			continue
		for mod in obj.modifiers:
			if mod.type != "ARMATURE":
				continue
			mod.object=base_armature
	if not preserved:
		for m_name in skinned_objects_dict:
			obj=get_object(m_name)
			if obj==None:
				continue
			if len(obj.vertex_groups):
				vertex_group_names_list=[vgroup.name for vgroup in obj.vertex_groups]
				for vgroup in obj.vertex_groups:
					if vgroup.name in skin_dict:
						try:
							new_vgroup_name=skin_dict[vgroup.name]['deform']
						except:
							new_vgroup_name=skin_dict[vgroup.name]
						if new_vgroup_name !=vgroup.name:
							if new_vgroup_name in vertex_group_names_list and obj.vertex_groups.get(new_vgroup_name):
								obj.vertex_groups[new_vgroup_name].name=new_vgroup_name+"_OLDGROUP"
								skin_dict[new_vgroup_name+"_OLDGROUP"]=skin_dict[new_vgroup_name]
								del skin_dict[new_vgroup_name]
						vgroup.name=new_vgroup_name
			try:
				drivers_save=skinned_objects_dict[m_name]
			except: continue
			for fc_dp in drivers_save:
				sk=obj.data.shape_keys
				if sk==None:
					continue
				anim_data=obj.data.shape_keys.animation_data
				if anim_data==None:
					continue
				drivers=anim_data.drivers
				if drivers==None:
					continue
				fc=anim_data.drivers.find(fc_dp)
				if fc==None:
					continue
				dr=fc.driver
				if dr:
					dr.type=drivers_save[fc_dp][0]
					dr.expression=drivers_save[fc_dp][1]
					var_dict=drivers_save[fc_dp][2]
					for var_name in var_dict:
						var=dr.variables.get(var_name)
						if var:
							var.type=var_dict[var_name]['type']
							ids=var_dict[var_name]['ids']
							bone_targets=var_dict[var_name]['bone_targets']
							tspaces=var_dict[var_name]['tspaces']
							for i,tar in enumerate(var.targets):
								if len(ids):
									tar.id=get_object(ids[i])
								if len(bone_targets):
									tar.bone_target=bone_targets[i]
								if len(tspaces):
									tar.transform_space=tspaces[i]
	bpy.ops.object.mode_set(mode='OBJECT')
	bpy.ops.object.select_all(action='DESELECT')
	set_active_object(base_armature_name)
	bpy.ops.object.mode_set(mode='POSE')
	for pbone in base_armature.pose.bones:
		if len(pbone.constraints):
			for cns in pbone.constraints:
				if cns.name.endswith('_QR'):
					pbone.constraints.remove(cns)
	self.meshes_parented_to_bones=meshes_parented_to_bones
	_parent_meshes(self,arp_armature,base_armature)
	if meshes_transf_dict:
		for m_name in meshes_transf_dict:
			obj=get_object(m_name)
			if obj==None:
				continue
			obj.location,obj.rotation_euler,obj.rotation_quaternion,obj.scale=meshes_transf_dict[m_name]
			print('Reverted mesh transforms',obj.name)
	bpy.ops.object.mode_set(mode='OBJECT')
	bpy.ops.object.select_all(action='DESELECT')
	set_active_object(arp_armature.name)
	bpy.ops.arp.delete_arp()
	set_active_object(base_armature_name)
	bpy.ops.object.mode_set(mode='POSE')
	anim_temp=get_object(base_armature_name+'_ANIM_TEMP')
	if anim_temp:
		delete_object(anim_temp)
	print("已还原.")
def _parent_meshes(self,current_arm,target_arm):
	if len(current_arm.children):
		for obj_child in current_arm.children:
			if obj_child.type== "MESH" and not obj_child.name in self.meshes_parented_to_bones:
				mat=obj_child.matrix_world.copy()
				obj_child.parent=target_arm
				bpy.context.evaluated_depsgraph_get().update()
				obj_child.matrix_world=mat
	current_arm.data.pose_position= 'REST'
	target_arm.data.pose_position= 'REST'
	for obj_name in self.meshes_parented_to_bones:
		obj=get_object(obj_name)
		bpy.ops.object.mode_set(mode='OBJECT')
		bpy.ops.object.select_all(action='DESELECT')
		set_active_object(obj_name)
		bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
		original_parent_name=self.meshes_parented_to_bones[obj_name]
		new_parent_name=original_parent_name
		if len(self.skin_dict):
			if original_parent_name in self.skin_dict:
				new_parent_name=self.skin_dict[original_parent_name]['deform']
		if target_arm.data.bones.get(new_parent_name)==None:
			er_mes= "Error with: "+new_parent_name+",not found in armature. Check the limb list\nfor invalid bones."
			print(er_mes)
			if 'error_mess' in dir(self):
				if not er_mes in self.error_mess:
					self.error_mess += '\n'+er_mes
			continue
		obj.parent=target_arm
		obj.parent_type= 'BONE'
		obj.parent_bone=new_parent_name
		b=target_arm.data.bones.get(new_parent_name)
		b.use_relative_parent=False
		pb=target_arm.pose.bones.get(new_parent_name)
		trans=Matrix.Translation(pb.head - pb.tail)
		obj.matrix_parent_inverse=(pb.matrix.inverted() @ trans) @ target_arm.matrix_world.inverted()
	current_arm.data.pose_position= 'POSE'
	target_arm.data.pose_position= 'POSE'
	if len(self.meshes_parented_to_bones):
		bpy.ops.object.select_all(action='DESELECT')
		set_active_object(target_arm.name)
		bpy.ops.object.mode_set(mode='POSE')
def set_childof_inverse(self):
	parent_dict={}
	childof_vgroup=[]
	for or_name in self.orphan_bones_dict:
		orphan_pbone=get_pose_bone(or_name)
		if orphan_pbone==None:
			continue
		for cns in orphan_pbone.constraints:
			if cns.type== 'CHILD_OF':
				if cns.target:
					if cns.target.type== "ARMATURE" and cns.subtarget != '':
						parent_dict[or_name]=cns.subtarget
					elif cns.target.type== "MESH" and cns.subtarget != '':
						childof_vgroup.append([or_name,cns.name])
	sorted_hierarchy=[]
	roots=[]
	for child_name in parent_dict:
		parent_name=parent_dict[child_name]
		if not parent_name in parent_dict:
			roots.append(child_name)
	def find_children(name,sorted_hierarchy):
		for i,j in parent_dict.items():
			if j==name:
				sorted_hierarchy.append(i)
				find_children(i,sorted_hierarchy)
	for root_name in roots:
		sorted_hierarchy.append(root_name)
		find_children(root_name,sorted_hierarchy)
	for or_name in sorted_hierarchy:
		orphan_pbone=get_pose_bone(or_name)
		if orphan_pbone==None:
			continue
		for cns in orphan_pbone.constraints:
			if cns.type== 'CHILD_OF':
				set_constraint_inverse_matrix(cns,orphan_pbone)
	for i in childof_vgroup:
		or_name,cns_name=i[0],i[1]
		orphan_pbone=get_pose_bone(or_name)
		if orphan_pbone==None:
			continue
		cns=orphan_pbone.constraints.get(cns_name)
		set_constraint_inverse_matrix(cns,orphan_pbone)
def _remap_animation(self):
	if self.source_anim_rig_name== '':
		return
	print("\nRemapping animation...")
	print("  构建骨骼列表...")
	scn=bpy.context.scene
	scn.source_rig=self.source_anim_rig_name
	source_rig=get_object(self.source_anim_rig_name)
	scn.source_action=source_rig.animation_data.action.name
	scn.target_rig=self.arp_armature_name
	target_rig=get_object(scn.target_rig)
	if len(scn.remap_source_nodes):
		i=len(scn.remap_source_nodes)
		while i >=0:
			scn.remap_source_nodes.remove(i)
			i -=1
	for b in source_rig.data.bones:
		item=scn.remap_source_nodes.add()
		item.source_name=b.name
	if len(scn.bones_map_v2):
		i=len(scn.bones_map_v2)
		while i >=0:
			scn.bones_map_v2.remove(i)
			i -=1
	remap_dict={}
	scn.bones_map_index=-1
	for limb in scn.limb_map:
		dupli_idx=limb.dupli_idx
		if limb.type== 'SPINE':
			for i in range(1,8):
				source_name=get_limb_prop(limb, 'bone_0'+str(i))
				if source_name != '' and source_name !=None:
					item=scn.bones_map_v2.add()
					scn.bones_map_index +=1
					item.name= 'c_root_master'+dupli_idx+'.x' if i==1 else 'c_spine_0'+str(i-1)+dupli_idx+'.x'
					item.source_bone=source_name
					if i==1:
						item.set_as_root=True
					else:
						item.location=True
		elif limb.type== 'HEAD':
			if limb.neck_bones_amount==1:
				if limb.bone_01 != '' and limb.bone_01 !=None:
					source_name=limb.bone_01
					target_name= 'c_neck'+dupli_idx+'.x'
					item=scn.bones_map_v2.add()
					scn.bones_map_index +=1
					item.name=target_name
					item.source_bone=source_name
			else:
				neck_list=['bone_01', 'bone_04', 'neck3', 'neck4', 'neck5', 'neck6', 'neck7', 'neck8', 'neck9', 'neck10']
				for i in range(1,limb.neck_bones_amount):
					n=neck_list[i-1]
					if get_limb_prop(limb,n) != '':
						source_name=get_limb_prop(limb,n)
						target_name= 'c_subneck_'+str(i)+dupli_idx+'.x'
						item=scn.bones_map_v2.add()
						scn.bones_map_index +=1
						item.name=target_name
						item.source_bone=source_name
				print(neck_list[limb.neck_bones_amount-1])
				source_name=get_limb_prop(limb,neck_list[limb.neck_bones_amount-1])
				target_name= 'c_neck'+dupli_idx+'.x'
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
			source_name=limb.bone_02
			target_name= 'c_head'+dupli_idx+'.x'
			item=scn.bones_map_v2.add()
			scn.bones_map_index +=1
			item.name=target_name
			item.source_bone=source_name
		elif limb.type== 'LEG':
			side= '.l'
			if limb.side== 'RIGHT':
				side= '.r'
			if limb.leg_type.startswith('3'):
				source_name=limb.upper_thigh
				target_name= 'c_thigh_b'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
			if self.leg_ik_fk== 'IK':
				source_name=limb.bone_05
				target_name= 'c_foot_ik'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
				item.ik=True
				item.ik_pole= 'c_leg_pole'+dupli_idx+side
				item.ik_auto_pole= 'RELATIVE_CHAIN'
				item.ik_1=limb.bone_01
				item.ik_2=limb.bone_03
				if limb.bone_06 != '' and limb.bone_06 !=None:
					source_name=limb.bone_06
					target_name= 'c_toes_ik'+dupli_idx+side
					item=scn.bones_map_v2.add()
					scn.bones_map_index +=1
					item.name=target_name
					item.source_bone=source_name
			else:
				source_name=limb.bone_05
				target_name= 'c_foot_fk'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
				source_name=limb.bone_01
				target_name= 'c_thigh_fk'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
				source_name=limb.bone_03
				target_name= 'c_leg_fk'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
				if limb.bone_06 != '' and limb.bone_06 !=None:
					source_name=limb.bone_06
					target_name= 'c_toes_fk'+dupli_idx+side
					item=scn.bones_map_v2.add()
					scn.bones_map_index +=1
					item.name=target_name
					item.source_bone=source_name
		elif limb.type== 'ARM':
			side= '.l'
			if limb.side== 'RIGHT':
				side= '.r'
			item=scn.bones_map_v2.add()
			scn.bones_map_index +=1
			item.name= 'c_shoulder'+dupli_idx+side
			item.source_bone=limb.bone_01
			item.location=True
			if self.arm_ik_fk== 'IK':
				source_name=limb.bone_06
				target_name= 'c_hand_ik'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
				item.ik=True
				item.ik_pole= 'c_arms_pole'+dupli_idx+side
				item.ik_auto_pole= 'RELATIVE_CHAIN'
				item.ik_1=limb.bone_02
				item.ik_2=limb.bone_04
			else:
				source_name=limb.bone_06
				target_name= 'c_hand_fk'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
				source_name=limb.bone_02
				target_name= 'c_arm_fk'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
				source_name=limb.bone_04
				target_name= 'c_forearm_fk'+dupli_idx+side
				item=scn.bones_map_v2.add()
				scn.bones_map_index +=1
				item.name=target_name
				item.source_bone=source_name
	for bname in self.fingers_ctrl:
		source_name=bname
		target_name=self.fingers_ctrl[bname]
		item=scn.bones_map_v2.add()
		scn.bones_map_index +=1
		item.name=target_name
		item.source_bone=source_name
	for bname in self.toes_ctrl:
		source_name=bname
		target_name=self.toes_ctrl[bname]
		item=scn.bones_map_v2.add()
		scn.bones_map_index +=1
		item.name=target_name
		item.source_bone=source_name
	for bname in self.tail_ctrl:
		source_name=bname
		target_name=self.tail_ctrl[bname]
		item=scn.bones_map_v2.add()
		scn.bones_map_index +=1
		item.name=target_name
		item.source_bone=source_name
	for b in target_rig.data.bones:
		if 'cc' in b.keys():
			source_name=b.name
			target_name=b.name
			item=scn.bones_map_v2.add()
			scn.bones_map_index +=1
			item.name=target_name
			item.source_bone=source_name
			item.location=True if self.orphan_bones_loc_retarget== 'LOCAL' else False
			item.ik=True if self.orphan_bones_loc_retarget== 'IK' else False
	if self.animation== 'ANIM_BAKE':
		act=source_rig.animation_data.action
		bpy.ops.arp.retarget(frame_start=int(act.frame_range[0]),frame_end=int(act.frame_range[1]))
		scn.source_rig= ''
		scn.target_rig= ''
		delete_object(source_rig)
	elif self.animation== 'ANIM_BIND':
		bpy.ops.arp.retarget_bind_only(unbind=False)
		scn.arp_retarget_decoupled_expand_ui=True
	print("动画重新映射")
def get_limb_prop(limb,prop):
	if limb.get(prop)==None:
		return ''
	else:
		return limb.get(prop)
def _make_rig(self):
	scn=bpy.context.scene
	source_skeleton=get_object(bpy.context.active_object.name)
	source_anim_rig=get_object(self.source_anim_rig_name)
	ref_bones_fingers_3={"thumb":["thumb1_ref", "thumb2_ref", "thumb3_ref"], "index":["index1_ref", "index2_ref", "index3_ref"], "middle":["middle1_ref", "middle2_ref", "middle3_ref"], "ring":["ring1_ref", "ring2_ref", "ring3_ref"], "pinky":["pinky1_ref", "pinky2_ref", "pinky3_ref"]}
	ref_bones_fingers_4={"thumb":["thumb1_ref", "thumb2_ref", "thumb3_ref"], "index":["index1_base_ref", "index1_ref", "index2_ref", "index3_ref"], "middle":["middle1_base_ref", "middle1_ref", "middle2_ref", "middle3_ref"], "ring":["ring1_base_ref", "ring1_ref", "ring2_ref", "ring3_ref"], "pinky":["pinky1_base_ref","pinky1_ref", "pinky2_ref", "pinky3_ref"]}
	ref_bones_toes_3={"thumb":["toes_thumb1_ref", "toes_thumb2_ref"], "index":["toes_index1_ref", "toes_index2_ref", "toes_index3_ref"], "middle":["toes_middle1_ref", "toes_middle2_ref", "toes_middle3_ref"], "ring":["toes_ring1_ref", "toes_ring2_ref", "toes_ring3_ref"], "pinky":["toes_pinky1_ref", "toes_pinky2_ref", "toes_pinky3_ref"]}
	ref_bones_toes_4={"thumb":["toes_thumb1_base_ref", "toes_thumb1_ref", "toes_thumb2_ref"], "index":["toes_index1_base_ref", "toes_index1_ref", "toes_index2_ref", "index3_ref"], "middle":["toes_middle1_base_ref", "toes_middle1_ref", "toes_middle2_ref", "toes_middle3_ref"], "ring":["toes_ring1_base_ref", "toes_ring1_ref", "toes_ring2_ref", "toes_ring3_ref"], "pinky":["toes_pinky1_base_ref","toes_pinky1_ref", "toes_pinky2_ref", "toes_pinky3_ref"]}
	if self.match_origin:
		bpy.ops.object.mode_set(mode='OBJECT')
		arm_rot_euler,arm_rot_quat,arm_scale=source_skeleton.rotation_euler.copy(),source_skeleton.rotation_quaternion.copy(),source_skeleton.scale.copy()
		source_skeleton.matrix_world=Matrix()
		source_skeleton.rotation_euler,source_skeleton.rotation_quaternion,source_skeleton.scale=arm_rot_euler,arm_rot_quat,arm_scale
		bpy.context.evaluated_depsgraph_get().update()
	bpy.ops.object.mode_set(mode='POSE')
	for pbone in source_skeleton.pose.bones:
		pbone.location=[0,0,0]
		pbone.scale=[1,1,1]
		pbone.rotation_euler=[0,0,0]
		pbone.rotation_quaternion=[1,0,0,0]
	arm_mat=source_skeleton.matrix_world.copy()
	mat_loc=arm_mat.to_translation()
	mat_rot=arm_mat.to_quaternion()
	arm_mat_no_scale=Matrix.Translation(Vector((0,0,0))) @ mat_rot.to_matrix().to_4x4()
	arm_mat_inv=arm_mat.inverted()
	arm_mat_no_scale_inv=arm_mat_no_scale
	arm_mat_rot=mat_rot.to_matrix().to_4x4()
	arm_mat2=arm_mat.copy()
	bpy.ops.object.mode_set(mode='EDIT')
	orphan_bones=[b.name for b in source_skeleton.data.edit_bones]
	limb_valid_bones={}# limb_valid_bones[limb.name]=[bone_name1,bone_name2...]
	limbs_coords={}
	skin_dict={}# skin_dict[base_bone_name]={'deform':arp_deform_bone, 'head':base_bone_head, 'tail'...}
	if len(scn.limb_map)==0:
		error_message= "Add limbs first"
		GR(self,"ERROR",error_message)
		return
	for obj in bpy.data.objects:
		if (obj.type != 'MESH' and obj.type != 'EMPTY') or is_object_hidden(obj): continue
		if obj.parent:
			if obj.parent==source_skeleton and obj.parent_type== 'BONE':
				if obj.parent_bone != '':
					self.meshes_parented_to_bones[obj.name]=obj.parent_bone
	leg_limb_count_left=0
	leg_limb_count_right=0
	arm_limb_count_left=0
	arm_limb_count_right=0
	tail_limb_count_left=0
	tail_limb_count_right=0
	tail_limb_count_mid=0
	def get_bone_coords(bone_name):
		ebone=get_edit_bone(bone_name)
		if ebone==None:
			return None
		coords=[arm_mat @ ebone.head,arm_mat @ ebone.tail,(arm_mat_rot @ ebone.x_axis).normalized()]
		return coords
	for limb_idx in range(0,len(scn.limb_map)):
		limb=scn.limb_map[limb_idx]
		bones_coords={}
		if limb.type== 'LEG':
			side= '.l' if limb.side== 'LEFT' else '.r'
			ref_bones_leg=['thigh_ref', 'leg_ref', 'foot_ref', 'toes_ref']
			if limb.leg_type.startswith('3'):
				ref_bones_leg.insert(0, 'thigh_b_ref')
			limb.toes_parent_foot=False
			if side== '.l':
				leg_limb_count_left +=1
				leg_limb_count=leg_limb_count_left
			elif side== '.r':
				leg_limb_count_right +=1
				leg_limb_count=leg_limb_count_right
			dupli_id= ''
			if leg_limb_count > 1:
				ref_bones_leg_dupli=[]
				dupli_id= '{:03d}'.format(leg_limb_count-1)
				dupli_id= "_dupli_"+str(dupli_id)
				for ref_bone_name in ref_bones_leg:
					ref_bone_name_dupli=ref_bone_name+dupli_id
					ref_bones_leg_dupli.append(ref_bone_name_dupli)
				ref_bones_leg=ref_bones_leg_dupli
			upthigh_name=limb.upper_thigh
			thigh_name=limb.bone_01
			thigh_twist_name=limb.bone_02
			calf_name=limb.bone_03
			calf_twist=limb.bone_04
			foot_name=limb.bone_05
			toes_name=limb.bone_06
			toes_end_name=limb.bone_07
			if limb.leg_type.startswith("3"):
				def_bone_name= "c_thigh_b"
				if limb.leg_type== "3_2":
					def_bone_name= "thigh_b_str"
				if limb.weights_override and limb.override_upper_thigh != "":
					skin_dict[limb.override_upper_thigh]={"deform":def_bone_name+dupli_id+side, 'coords':get_bone_coords(limb.override_upper_thigh)}
				else:
					skin_dict[upthigh_name]={'deform':def_bone_name+dupli_id+side, 'coords':get_bone_coords(upthigh_name)}
			if limb.weights_override and limb.override_bone_01 != "":
				skin_dict[limb.override_bone_01]={'deform':"thigh_stretch"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_01)}
			else:
				skin_dict[thigh_name]={'deform':"thigh_stretch"+dupli_id+side, 'coords':get_bone_coords(thigh_name)}
			if limb.weights_override and limb.override_bone_02 != "":
				skin_dict[limb.override_bone_02]={'deform':"thigh_twist"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_02)}
			else:
				skin_dict[thigh_twist_name]={'deform':"thigh_twist"+dupli_id+side, 'coords':get_bone_coords(thigh_twist_name)}
			if limb.weights_override and limb.override_bone_03 != "":
				skin_dict[limb.override_bone_03]={'deform':"leg_stretch"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_03)}
			else:
				skin_dict[calf_name]={'deform':"leg_stretch"+dupli_id+side, 'coords':get_bone_coords(calf_name)}
			if limb.weights_override and limb.override_bone_04 != "":
				skin_dict[limb.override_bone_04]={'deform':"leg_twist"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_04)}
			else:
				skin_dict[calf_twist]={'deform':"leg_twist"+dupli_id+side, 'coords':get_bone_coords(calf_twist)}
			if limb.weights_override and limb.override_bone_05 != "":
				skin_dict[limb.override_bone_05]={'deform':"foot"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_05)}
			else:
				skin_dict[foot_name]={'deform':"foot"+dupli_id+side, 'coords':get_bone_coords(foot_name)}
			if limb.weights_override and limb.override_bone_06 != "":
				skin_dict[limb.override_bone_06]={'deform':"toes_01"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_06)}
			else:
				skin_dict[toes_name]={'deform':"toes_01"+dupli_id+side, 'coords':get_bone_coords(toes_name)}
			if limb.twist_bones_amount >=2:
				for i in range(2,limb.twist_bones_amount+1):
					id= '%02d' % (i)
					twist_1_name= 'bone_twist_'+id+'_01'
					twist_1_src_name=get_limb_prop(limb,twist_1_name)
					if twist_1_src_name != '':
						if get_edit_bone(twist_1_src_name):
							skin_dict[twist_1_src_name]={'deform':'thigh_twist_'+str(i)+dupli_id+side, 'coords':get_bone_coords(twist_1_src_name)}
					twist_2_name= 'bone_twist_'+id+'_02'
					twist_2_src_name=get_limb_prop(limb,twist_2_name)
					if twist_2_src_name != '':
						if get_edit_bone(twist_2_src_name):
							skin_dict[twist_2_src_name]={'deform':'leg_twist_'+str(i)+dupli_id+side, 'coords':get_bone_coords(twist_2_src_name)}
			leg_names=[thigh_name,calf_name,foot_name,toes_name]
			if limb.leg_type.startswith("3"):
				leg_names.insert(0,upthigh_name)
			for i,bname in enumerate(leg_names):
				ebone=get_edit_bone(bname)
				if ebone==None:
					continue
				bone_tail=ebone.tail.copy()
				if bname==toes_name:
					if toes_end_name != '':
						bone_tail=get_edit_bone(toes_end_name).head.copy()
				parent_name= "" if ebone.parent==None else ebone.parent.name
				if parent_name.startswith("c_thigh_b"):
					if ebone.parent.parent:
						parent_name= "" if ebone.parent.parent==None else ebone.parent.parent.name
				bones_coords[ref_bones_leg[i]]={'head':arm_mat @ ebone.head.copy(), 'tail':arm_mat @ bone_tail,'x_axis':(arm_mat_rot @ ebone.x_axis).normalized(),'y_axis':(arm_mat_rot @ ebone.y_axis).normalized(),'z_axis':(arm_mat_rot @ ebone.z_axis).normalized(),'name':ebone.name, 'parent_name':parent_name}# store bone data
			fingers_names={'thumb':[], 'index':[], 'middle':[], 'ring':[], 'pinky':[]}
			if limb.fingers != 'NONE':
				ref_bones_fingers={}
				if limb.fingers== "3":
					ref_bones_fingers=ref_bones_toes_3.copy()
				elif limb.fingers== "4":
					ref_bones_fingers=ref_bones_toes_4.copy()
				for finger_type in ref_bones_fingers:
					current_list=ref_bones_fingers[finger_type].copy()
					new_list=[]
					for ref_name in current_list:
						new_list.append(ref_name+dupli_id)
					ref_bones_fingers[finger_type]=new_list
				base_fingers_names={"thumb":limb.thumb, "index":limb.index, "middle":limb.middle, "ring":limb.ring, "pinky":limb.pinky}
				if limb.manual_phalanges:
					for finger_type in base_fingers_names:
						phalange1=get_edit_bone(base_fingers_names[finger_type])
						if phalange1:
							fingers_names[finger_type].append(phalange1.name)
						phal2_name=get_limb_prop(limb,finger_type+'2')
						if limb.fingers== '4':
							if finger_type != 'thumb':
								phal2_name=get_limb_prop(limb,finger_type+'1')
						if phal2_name:
							phalange2=get_edit_bone(phal2_name)
							if phalange2:
								fingers_names[finger_type].append(phalange2.name)
						phal3_name= ''
						if (finger_type != 'thumb' and limb.fingers== '3'):
							phal3_name=get_limb_prop(limb,finger_type+'3')
						if limb.fingers== '4':
							if finger_type== 'thumb':
								phal3_name=get_limb_prop(limb,finger_type+'3')
							else:
								phal3_name=get_limb_prop(limb,finger_type+'2')
						if phal3_name:
							phalange3=get_edit_bone(phal3_name)
							if phalange3:
								fingers_names[finger_type].append(phalange3.name)
						if limb.fingers== "4" and finger_type != 'thumb':
							phal4_name=get_limb_prop(limb,finger_type+'3')
							if phal4_name:
								phalange4=get_edit_bone(phal4_name)
								if phalange4:
									fingers_names[finger_type].append(phalange4.name)
				else:
					for finger_type in base_fingers_names:
						phalange1=phalange2=phalange3=phalange4=None
						finger_bone_name=base_fingers_names[finger_type]
						phalange1=get_edit_bone(finger_bone_name)
						if phalange1:
							fingers_names[finger_type].append(phalange1.name)
							if phalange1.children:
								phalange2=phalange1.children[0]
								fingers_names[finger_type].append(phalange2.name)
								if phalange2.children and (finger_type != 'thumb' or limb.fingers== '4'):
									phalange3=phalange2.children[0]
									fingers_names[finger_type].append(phalange3.name)
									if limb.fingers== "4" and finger_type != "thumb" !=0:
										if phalange3.children:
											phalange4=phalange3.children[0]
											fingers_names[finger_type].append(phalange4.name)
				valid_list=True
				expected_finger_count=0
				for fidx,fname in enumerate((limb.thumb,limb.index,limb.middle,limb.ring,limb.pinky)):
					if fname != "":
						if fidx==0:
							expected_finger_count +=2 if limb.fingers== '3' else 3
						else:
							expected_finger_count +=4 if limb.fingers== "4" else 3
				phalanges_count=0
				for finger_type in fingers_names:
					phalanges_count +=len(fingers_names[finger_type])
				if phalanges_count !=expected_finger_count:
					print("Error,found",len(fingers_names), "toes. Should have found",expected_finger_count)
					print("无法设置脚趾，设置为无")
					valid_list=False
					limb.fingers= "NONE"# set fingers to None
				if valid_list:
					for finger_type in fingers_names:
						phalange1_name=phalange2_name=phalange3_name=phalange4_name=None
						phal_list=fingers_names[finger_type]
						if len(phal_list) >=1:
							phalange1_name=phal_list[0]
						if len(phal_list) >=2:
							phalange2_name=phal_list[1]
						if len(phal_list) >=3:
							phalange3_name=phal_list[2]
						if len(phal_list) >=4:
							phalange4_name=phal_list[3]
						def add_finger_deforming_match_3(finger_type):
							if phalange1_name:
								skin_dict[phalange1_name]={'deform':'c_toes_'+finger_type+"1"+dupli_id+side, 'coords':get_bone_coords(phalange1_name)}
							if phalange2_name:
								skin_dict[phalange2_name]={'deform':"c_toes_"+finger_type+"2"+dupli_id+side, 'coords':get_bone_coords(phalange2_name)}
							if phalange3_name:
								skin_dict[phalange3_name]={'deform':"c_toes_"+finger_type+"3"+dupli_id+side, 'coords':get_bone_coords(phalange3_name)}
						def add_finger_deforming_match_4(finger_type):
							if phalange1_name:
								skin_dict[phalange1_name]={'deform':'c_toes_'+finger_type+'1_base'+dupli_id+side, 'coords':get_bone_coords(phalange1_name)}
							if phalange2_name:
								skin_dict[phalange2_name]={'deform':'c_toes_'+finger_type+'1'+dupli_id+side, 'coords':get_bone_coords(phalange2_name)}
							if phalange3_name:
								skin_dict[phalange3_name]={'deform':'c_toes_'+finger_type+'2'+dupli_id+side, 'coords':get_bone_coords(phalange3_name)}
							if phalange4_name:
								skin_dict[phalange4_name]={'deform':'c_toes_'+finger_type+'3'+dupli_id+side, 'coords':get_bone_coords(phalange4_name)}
						if phalange1_name:
							if limb.fingers== "3":
								add_finger_deforming_match_3(finger_type)
							elif limb.fingers== "4":
								add_finger_deforming_match_4(finger_type)
						for f in [phalange1_name,phalange2_name,phalange3_name,phalange4_name]:
							if f:
								if f in orphan_bones:
									orphan_bones.remove(f)
					for finger_type in fingers_names:
						phal_list=fingers_names[finger_type]
						for i,phal_name in enumerate(phal_list):
							finger_bone=get_edit_bone(phal_name)
							finger_ref_name=ref_bones_fingers[finger_type][i]
							bones_coords[finger_ref_name]={'head':arm_mat @ finger_bone.head.copy(), 'tail':arm_mat @ finger_bone.tail.copy(),'x_axis':(arm_mat_rot @ finger_bone.x_axis).normalized(), 'y_axis':(arm_mat_rot @ finger_bone.y_axis).normalized(),'z_axis':(arm_mat_rot @ finger_bone.z_axis).normalized(),'name':finger_bone.name}# store bone data
							c_toes_name= 'c_toes_'+finger_ref_name.replace('_ref', '')+side
							self.toes_ctrl[finger_bone.name]=c_toes_name
							if i==0 and finger_bone.parent:
								if finger_bone.parent.name==foot_name:
									limb.toes_parent_foot=True
		elif limb.type== 'ARM':
			side= '.l' if limb.side== 'LEFT' else '.r'
			ref_bones_arm=['shoulder_ref', 'arm_ref', 'forearm_ref', 'hand_ref']
			if side== '.l':
				arm_limb_count_left +=1
				arm_limb_count=arm_limb_count_left
			elif side== '.r':
				arm_limb_count_right +=1
				arm_limb_count=arm_limb_count_right
			dupli_id= ''
			if arm_limb_count > 1:
				ref_bones_arm_dupli=[]
				dupli_id= '{:03d}'.format(arm_limb_count-1)
				dupli_id= "_dupli_"+str(dupli_id)
				for ref_bone_name in ref_bones_arm:
					ref_bone_name_dupli=ref_bone_name+dupli_id
					ref_bones_arm_dupli.append(ref_bone_name_dupli)
				ref_bones_arm=ref_bones_arm_dupli
			shoulder_name=limb.bone_01
			arm_name=limb.bone_02
			arm_twist_name=limb.bone_03
			forearm_name=limb.bone_04
			forearm_twist_name=limb.bone_05
			hand_name=limb.bone_06
			arm_limb_count +=1
			if limb.weights_override and limb.override_bone_01 != "":
				skin_dict[limb.override_bone_01]={'deform':"shoulder"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_01)}
			else:
				skin_dict[shoulder_name]={'deform':"shoulder"+dupli_id+side, 'coords':get_bone_coords(shoulder_name)}
			if limb.weights_override and limb.override_bone_02 != "":
				skin_dict[limb.override_bone_02]={'deform':"arm_stretch"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_02)}
			else:
				skin_dict[arm_name]={'deform':"arm_stretch"+dupli_id+side, 'coords':get_bone_coords(arm_name)}
			if limb.weights_override and limb.override_bone_03 != "":
				skin_dict[limb.override_bone_03]={'deform':"c_arm_twist_offset"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_03)}
			else:
				skin_dict[arm_twist_name]={'deform':"c_arm_twist_offset"+dupli_id+side, 'coords':get_bone_coords(arm_twist_name)}
			if limb.weights_override and limb.override_bone_04 != "":
				skin_dict[limb.override_bone_04]={'deform':"forearm_stretch"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_04)}
			else:
				skin_dict[forearm_name]={'deform':"forearm_stretch"+dupli_id+side, 'coords':get_bone_coords(forearm_name)}
			if limb.weights_override and limb.override_bone_05 != "":
				skin_dict[limb.override_bone_05]={'deform':"forearm_twist"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_05)}
			else:
				skin_dict[forearm_twist_name]={'deform':"forearm_twist"+dupli_id+side, 'coords':get_bone_coords(forearm_twist_name)}
			if limb.weights_override and limb.override_bone_06 != "":
				skin_dict[limb.override_bone_06]={'deform':"hand"+dupli_id+side, 'coords':get_bone_coords(limb.override_bone_06)}
			else:
				skin_dict[hand_name]={'deform':"hand"+dupli_id+side, 'coords':get_bone_coords(hand_name)}
			if limb.twist_bones_amount >=2:
				for i in range(2,limb.twist_bones_amount+1):
					id= '%02d' % (i)
					twist_1_name= 'bone_twist_'+id+'_01'
					twist_1_src_name=get_limb_prop(limb,twist_1_name)
					if twist_1_src_name != '':
						skin_dict[twist_1_src_name]={'deform':'arm_twist_'+str(i)+dupli_id+side, 'coords':get_bone_coords(twist_1_src_name)}
					twist_2_name= 'bone_twist_'+id+'_02'
					twist_2_src_name=get_limb_prop(limb,twist_2_name)
					if twist_2_src_name != '':
						skin_dict[twist_2_src_name]={'deform':'forearm_twist_'+str(i)+dupli_id+side, 'coords':get_bone_coords(twist_2_src_name)}
			bones_arm_list=[shoulder_name,arm_name,forearm_name,hand_name]
			if limb.primary_axis_auto:
				limb.primary_axis,limb.primary_axis_auto_multi=find_primary_axis(bones_arm_list,multi=True)
			for i,bname in enumerate(bones_arm_list):
				ebone=get_edit_bone(bname)
				if ebone==None:
					continue
				parent_name= "" if ebone.parent==None else ebone.parent.name
				bones_coords[ref_bones_arm[i]]={'head':arm_mat @ ebone.head.copy(), 'tail':arm_mat @ ebone.tail.copy(),'x_axis':(arm_mat_rot @ ebone.x_axis).normalized(), 'y_axis':(arm_mat_rot @ ebone.y_axis).normalized(),'z_axis':(arm_mat_rot @ ebone.z_axis).normalized(),'name':ebone.name, 'parent_name':parent_name}# store bone data
			fingers_names={"thumb":[], "index":[], "middle":[], "ring":[], "pinky":[]}
			if limb.fingers != "NONE":
				ref_bones_fingers={}
				if limb.fingers== "3":
					ref_bones_fingers=ref_bones_fingers_3.copy()
				elif limb.fingers== "4":
					ref_bones_fingers=ref_bones_fingers_4.copy()
				for finger_type in ref_bones_fingers:
					current_list=ref_bones_fingers[finger_type].copy()
					new_list=[]
					for ref_name in current_list:
						new_list.append(ref_name+dupli_id)
					ref_bones_fingers[finger_type]=new_list
				base_fingers_names={"thumb":limb.thumb, "index":limb.index, "middle":limb.middle, "ring":limb.ring, "pinky":limb.pinky}
				if limb.manual_phalanges:
					for finger_type in base_fingers_names:
						print('base_fingers_names[finger_type]',base_fingers_names[finger_type])
						phalange1=get_edit_bone(base_fingers_names[finger_type])
						fingers_names[finger_type].append(phalange1.name)
						phal2_name=get_limb_prop(limb,finger_type+'2')
						if limb.fingers== "4" and finger_type != "thumb" !=0:
							phal2_name=get_limb_prop(limb,finger_type+'1')
						if phal2_name:
							phalange2=get_edit_bone(phal2_name)
							fingers_names[finger_type].append(phalange2.name)
						phal3_name=get_limb_prop(limb,finger_type+'3')
						if limb.fingers== "4" and finger_type != "thumb" !=0:
							phal3_name=get_limb_prop(limb,finger_type+'2')
						if phal3_name:
							phalange3=get_edit_bone(phal3_name)
							fingers_names[finger_type].append(phalange3.name)
						if limb.fingers== "4" and finger_type != "thumb" !=0:
							phal4_name=get_limb_prop(limb,finger_type+'3')
							if phal4_name:
								phalange4=get_edit_bone(phal4_name)
								fingers_names[finger_type].append(phalange4.name)
				else:
					for finger_type in base_fingers_names:
						phalange1=phalange2=phalange3=phalange4=None
						finger_bone_name=base_fingers_names[finger_type]
						phalange1=get_edit_bone(finger_bone_name)
						if phalange1:
							fingers_names[finger_type].append(phalange1.name)
							if phalange1.children:
								phalange2=phalange1.children[0]
								fingers_names[finger_type].append(phalange2.name)
								if phalange2.children:
									phalange3=phalange2.children[0]
									fingers_names[finger_type].append(phalange3.name)
									if limb.fingers== "4" and finger_type != "thumb" !=0:
										if phalange3.children:
											phalange4=phalange3.children[0]
											fingers_names[finger_type].append(phalange4.name)
				valid_list=True
				expected_finger_count=0
				for fidx,fname in enumerate((limb.thumb,limb.index,limb.middle,limb.ring,limb.pinky)):
					if fname != "":
						if fidx==0:
							expected_finger_count +=3
						else:
							expected_finger_count +=4 if limb.fingers== "4" else 3
				phalanges_count=0
				for finger_type in fingers_names:
					phalanges_count +=len(fingers_names[finger_type])
				if phalanges_count !=expected_finger_count:
					print("Error,found",len(fingers_names), "fingers. Should have found",expected_finger_count)
					print("无法设置手指，设置为无")
					valid_list=False
					limb.fingers= "NONE"# set fingers to None
				if valid_list:
					for finger_type in fingers_names:
						limb.primary_axis_fingers=find_primary_axis(fingers_names[finger_type])
						print('Fingers Primary Axis',limb.primary_axis_fingers)
						break
					for finger_type in fingers_names:
						phalange1_name=phalange2_name=phalange3_name=phalange4_name=None
						phal_list=fingers_names[finger_type]
						if len(phal_list) >=1:
							phalange1_name=phal_list[0]
						if len(phal_list) >=2:
							phalange2_name=phal_list[1]
						if len(phal_list) >=3:
							phalange3_name=phal_list[2]
						if len(phal_list) >=4:
							phalange4_name=phal_list[3]
						def add_finger_deforming_match_3(finger_type):
							if phalange1_name:
								skin_dict[phalange1_name]={'deform':finger_type+"1"+dupli_id+side, 'coords':get_bone_coords(phalange1_name)}
							if phalange2_name:
								skin_dict[phalange2_name]={'deform':"c_"+finger_type+"2"+dupli_id+side, 'coords':get_bone_coords(phalange2_name)}
							if phalange3_name:
								skin_dict[phalange3_name]={'deform':"c_"+finger_type+"3"+dupli_id+side, 'coords':get_bone_coords(phalange3_name)}
						def add_finger_deforming_match_4(finger_type):
							if phalange1_name:
								skin_dict[phalange1_name]={'deform':"c_"+finger_type+"1_base"+dupli_id+side, 'coords':get_bone_coords(phalange1_name)}
							if phalange2_name:
								skin_dict[phalange2_name]={'deform':finger_type+"1"+dupli_id+side, 'coords':get_bone_coords(phalange2_name)}
							if phalange3_name:
								skin_dict[phalange3_name]={'deform':"c_"+finger_type+"2"+dupli_id+side, 'coords':get_bone_coords(phalange3_name)}
							if phalange4_name:
								skin_dict[phalange4_name]={'deform':"c_"+finger_type+"3"+dupli_id+side, 'coords':get_bone_coords(phalange4_name)}
						if phalange1_name:
							if limb.fingers== "3":
								add_finger_deforming_match_3(finger_type)
							elif limb.fingers== "4":
								if finger_type== "thumb":
									add_finger_deforming_match_3(finger_type)
								else:
									add_finger_deforming_match_4(finger_type)
						for f in [phalange1_name,phalange2_name,phalange3_name,phalange4_name]:
							if f:
								if f in orphan_bones:
									orphan_bones.remove(f)
					for finger_type in fingers_names:
						phal_list=fingers_names[finger_type]
						for i,phal_name in enumerate(phal_list):
							finger_bone=get_edit_bone(phal_name)
							finger_ref_name=ref_bones_fingers[finger_type][i]
							bones_coords[finger_ref_name]={'head':arm_mat @ finger_bone.head.copy(), 'tail':arm_mat @ finger_bone.tail.copy(),'x_axis':(arm_mat_rot @ finger_bone.x_axis).normalized(), 'y_axis':(arm_mat_rot @ finger_bone.y_axis).normalized(), 'z_axis':(arm_mat_rot @ finger_bone.z_axis).normalized(),'name':finger_bone.name}# store bone data
							self.fingers_ctrl[finger_bone.name]= 'c_'+finger_ref_name.replace('_ref', '')+side
		elif limb.type== 'SPINE':
			side= '.x'# maybe add other sides later,but ARP only supports spine bones of center side so far
			limb.side= 'CENTER'
			bones_spine_list=[]
			ref_bones_spine=[]
			pelvis=limb.bone_01
			spine_01=limb.bone_02
			spine_02=limb.bone_03
			spine_03=limb.bone_04
			spine_04=limb.bone_05
			spine_05=limb.bone_06
			spine_06=limb.bone_07
			for spine_idx in range(1,limb.spine_amount+1):
				stri= '%02d' % spine_idx
				stri_prev= '%02d' % (spine_idx-1)
				ref_name= ''
				if spine_idx==1:
					if limb.weights_override and limb.override_bone_01 != '':
						skin_dict[limb.override_bone_01]={'deform':'root'+side, 'coords':get_bone_coords(limb.override_bone_01)}
					else:
						skin_dict[pelvis]={'deform':'root'+side, 'coords':get_bone_coords(pelvis)}
					ref_name= 'root_ref'
				else:
					spine_name=getattr(limb, 'bone_'+stri)
					override_bone_val=getattr(limb, 'override_bone_'+stri)
					if limb.weights_override and override_bone_val != '':
						skin_dict[override_bone_val]={'deform': 'spine_'+stri_prev+side, 'coords':get_bone_coords(override_bone_val)}
					else:
						skin_dict[spine_name]={'deform': 'spine_'+stri_prev+side, 'coords':get_bone_coords(spine_name)}
					ref_name= 'spine_'+stri_prev+'_ref'
				bones_spine_list.append(getattr(limb, 'bone_'+stri))
				ref_bones_spine.append(ref_name)
			if limb.primary_axis_auto:
				limb.primary_axis=find_primary_axis(bones_spine_list)
			for i,bname in enumerate(bones_spine_list):
				ebone=get_edit_bone(bname)
				if ebone:
					bones_coords[ref_bones_spine[i]]={'head':arm_mat @ ebone.head.copy(), 'tail':arm_mat @ ebone.tail.copy(), 'x_axis':(arm_mat_rot @ ebone.x_axis).normalized(), 'y_axis':(arm_mat_rot @ ebone.y_axis).normalized(), 'z_axis':(arm_mat_rot @ ebone.z_axis).normalized(), 'name':ebone.name}# store bone data
		elif limb.type== 'HEAD':
			side= '.x'
			limb.side= 'CENTER'
			limb_valid_bones[limb.name]=[]
			neck=limb.bone_01
			neck2=limb.bone_04
			neck3=limb.neck3
			neck4=limb.neck4
			neck5=limb.neck5
			neck6=limb.neck6
			neck7=limb.neck7
			neck8=limb.neck8
			neck9=limb.neck9
			neck10=limb.neck10
			necks_list=[neck,neck2,neck3,neck4,neck5,neck6,neck7,neck8,neck9,neck10]
			head=limb.bone_02
			head_end=limb.bone_03
			ref_bones_head={head: 'head_ref'}
			def_bones=[head]
			skin_dict[head]={'deform':'head'+side, 'coords':get_bone_coords(head)}
			if limb.facial:
				if limb.facial_eyebrows:
					for eyebside in ['left', 'right']:
						if (eyebside== 'left' and not limb.facial_left) or (eyebside== 'right' and not limb.facial_right):
							continue
						suff_side= '.l' if eyebside== 'left' else '.r'
						for eyebidx in range(1,limb.facial_eyebrows_amount+1):
							stri= '%02d' % eyebidx
							stri_prev= '%02d' % (eyebidx-1)
							prop_name= 'eyebrow_'+stri+'_'+eyebside
							eyebrow=getattr(limb,prop_name)
							if eyebrow != '':
								c_eyebrow_name= 'c_eyebrow_01_end'+suff_side if eyebidx==1 else 'c_eyebrow_'+stri_prev+suff_side
								skin_dict[eyebrow]={'deform':c_eyebrow_name, 'coords':get_bone_coords(eyebrow)}
								ref_bones_head[eyebrow]= 'eyebrow_01_end_ref'+suff_side if eyebidx==1 else 'eyebrow_'+stri_prev+'_ref'+suff_side
								limb_valid_bones[limb.name].append(prop_name)
								if eyebrow in orphan_bones:
									orphan_bones.remove(eyebrow)
				if limb.facial_eyes:
					for eyeside in ['left', 'right']:
						if (eyeside== 'left' and not limb.facial_left) or (eyeside== 'right' and not limb.facial_right):
							continue
						suff_side= '.l' if eyeside== 'left' else '.r'
						prop_name= 'eye_'+eyeside
						limb_eye=getattr(limb,prop_name)
						if limb_eye != '':
							skin_dict[limb_eye]={'deform':'c_eye'+suff_side, 'coords':get_bone_coords(limb_eye)}
							ref_bones_head[limb_eye]= 'eye_offset_ref'+suff_side
							limb_valid_bones[limb.name].append(prop_name)
							if limb_eye in orphan_bones:
								orphan_bones.remove(limb_eye)
				if limb.facial_eyelids > 0:
					for eyelidside in ['left', 'right']:
						if (eyelidside== 'left' and not limb.facial_left) or (eyelidside== 'right' and not limb.facial_right):
							continue
						suff_side= '.l' if eyelidside== 'left' else '.r'
						for eyelidx in range(1,limb.facial_eyelids+1):
							stri= '%02d' % eyelidx
							prop_name= 'eyelid_top_'+stri+'_'+eyelidside
							eyelid_top=getattr(limb,prop_name)
							if eyelid_top != '':
								skin_dict[eyelid_top]={'deform':'c_eyelid_top_'+stri+suff_side, 'coords':get_bone_coords(eyelid_top), 'prop_name':prop_name}
								ref_bones_head[eyelid_top]= 'eyelid_top_'+stri+'_ref'+suff_side
								limb_valid_bones[limb.name].append(prop_name)
								if eyelid_top in orphan_bones:
									orphan_bones.remove(eyelid_top)
							prop_name= 'eyelid_bot_'+stri+'_'+eyelidside
							eyelid_bot=getattr(limb,prop_name)
							if eyelid_bot != '':
								skin_dict[eyelid_bot]={'deform':'c_eyelid_bot_'+stri+suff_side, 'coords':get_bone_coords(eyelid_bot), 'prop_name':prop_name}
								ref_bones_head[eyelid_bot]= 'eyelid_bot_'+stri+'_ref'+suff_side
								limb_valid_bones[limb.name].append(prop_name)
								if eyelid_bot in orphan_bones:
									orphan_bones.remove(eyelid_bot)
						prop_name= 'eyelid_corner_in_'+eyelidside
						eyelid_corner_in=getattr(limb,prop_name)
						if eyelid_corner_in != '':
							skin_dict[eyelid_corner_in]={'deform': 'c_eyelid_corner_01'+suff_side, 'coords':get_bone_coords(eyelid_corner_in), 'prop_name':prop_name}
							ref_bones_head[eyelid_corner_in]= 'eyelid_corner_01_ref'+suff_side
							limb_valid_bones[limb.name].append(prop_name)
							if eyelid_corner_in in orphan_bones:
								orphan_bones.remove(eyelid_corner_in)
						prop_name= 'eyelid_corner_out_'+eyelidside
						eyelid_corner_out=getattr(limb,prop_name)
						if eyelid_corner_out != '':
							skin_dict[eyelid_corner_out]={'deform': 'c_eyelid_corner_02'+suff_side, 'coords':get_bone_coords(eyelid_corner_out), 'prop_name':prop_name}
							ref_bones_head[eyelid_corner_out]= 'eyelid_corner_02_ref'+suff_side
							limb_valid_bones[limb.name].append(prop_name)
							if eyelid_corner_out in orphan_bones:
								orphan_bones.remove(eyelid_corner_out)
				if limb.facial_cheeks:
					for cheekside in ['left', 'right']:
						if (cheekside== 'left' and not limb.facial_left) or (cheekside== 'right' and not limb.facial_right):
							continue
						suff_side= '.l' if cheekside== 'left' else '.r'
						prop_name= 'cheek_'+cheekside
						cheek_bone=getattr(limb,prop_name)
						if cheek_bone != '':
							skin_dict[cheek_bone]={'deform':'c_cheek_inflate'+suff_side, 'coords':get_bone_coords(cheek_bone)}
							ref_bones_head[cheek_bone]= 'cheek_inflate_ref'+suff_side
							limb_valid_bones[limb.name].append(prop_name)
							if cheek_bone in orphan_bones:
								orphan_bones.remove(cheek_bone)
						prop_name= 'cheek_smile_'+cheekside
						cheek_smile_bone=getattr(limb,prop_name)
						if cheek_smile_bone != '':
							skin_dict[cheek_smile_bone]={'deform':'c_cheek_smile'+suff_side, 'coords':get_bone_coords(cheek_smile_bone)}
							ref_bones_head[cheek_smile_bone]= 'cheek_smile_ref'+suff_side
							limb_valid_bones[limb.name].append(prop_name)
							if cheek_smile_bone in orphan_bones:
								orphan_bones.remove(cheek_smile_bone)
				if limb.facial_nose:
					prop_name= 'nose_root'
					nose_bone=getattr(limb,prop_name)
					if nose_bone != '':
						skin_dict[nose_bone]={'deform':'c_nose_03.x', 'coords':get_bone_coords(nose_bone)}
						ref_bones_head[nose_bone]= 'nose_03_ref.x'
						limb_valid_bones[limb.name].append(prop_name)
						if nose_bone in orphan_bones:
							orphan_bones.remove(nose_bone)
					prop_name= 'nose_tip1'
					nose_bone=getattr(limb,prop_name)
					if nose_bone != '':
						skin_dict[nose_bone]={'deform':'c_nose_01.x', 'coords':get_bone_coords(nose_bone)}
						ref_bones_head[nose_bone]= 'nose_01_ref.x'
						limb_valid_bones[limb.name].append(prop_name)
						if nose_bone in orphan_bones:
							orphan_bones.remove(nose_bone)
					prop_name= 'nose_tip2'
					nose_bone=getattr(limb,prop_name)
					if nose_bone != '':
						skin_dict[nose_bone]={'deform':'c_nose_02.x', 'coords':get_bone_coords(nose_bone)}
						ref_bones_head[nose_bone]= 'nose_02_ref.x'
						limb_valid_bones[limb.name].append(prop_name)
						if nose_bone in orphan_bones:
							orphan_bones.remove(nose_bone)
				if limb.facial_mouth:
					prop_name= 'jaw'
					jaw_name=getattr(limb,prop_name)
					if jaw_name != '':
						skin_dict[jaw_name]={'deform':'jawbone'+side, 'coords':get_bone_coords(jaw_name)}
						ref_bones_head[jaw_name]= 'jaw_ref'
						limb_valid_bones[limb.name].append(prop_name)
						if jaw_name in orphan_bones:
							orphan_bones.remove(jaw_name)
					if limb.lips_amount > 0:
						for lvl in ['top', 'bot']:
							prop_name= 'lip_'+lvl+'_mid'
							lip_mid=getattr(limb,prop_name)
							if lip_mid != '':
								c_lips_lvl_name= 'c_lips_'+lvl+'.x'
								skin_dict[lip_mid]={'deform':c_lips_lvl_name, 'coords':get_bone_coords(lip_mid), 'prop_name':prop_name}
								ref_bones_head[lip_mid]= 'lips_'+lvl+'_ref'
								limb_valid_bones[limb.name].append(prop_name)
								if lip_mid in orphan_bones:
									orphan_bones.remove(lip_mid)
						for lips_side in ['left', 'right']:
							suff_side= '.l' if lips_side== 'left' else '.r'
							prop_name= 'lip_corner_'+lips_side
							corner=getattr(limb,prop_name)
							if corner != '':
								skin_dict[corner]={'deform':'c_lips_corner_mini'+suff_side, 'coords':get_bone_coords(corner), 'prop_name':prop_name}
								ref_bones_head[corner]= 'lips_smile_ref'+suff_side
								limb_valid_bones[limb.name].append(prop_name)
								if corner in orphan_bones:
									orphan_bones.remove(corner)
							for lipidx in range(1,limb.lips_amount+1):
								for lvl in ['top', 'bot']:
									prop_name= 'lip_'+lvl+'_'+'%02d' % lipidx+'_'+lips_side
									lip=getattr(limb,prop_name)
									if lip != '':
										c_lips_name= 'c_lips_'+lvl+'_'+'%02d' % (lipidx-1)+suff_side if lipidx > 1 else 'c_lips_'+lvl+suff_side
										skin_dict[lip]={'deform':c_lips_name, 'coords':get_bone_coords(lip), 'prop_name':prop_name}
										ref_bones_head[lip]= 'lips_'+lvl+'_'+'%02d' % (lipidx-1)+'_ref'+suff_side if lipidx > 1 else 'lips_'+lvl+'_ref'+suff_side
										limb_valid_bones[limb.name].append(prop_name)
										if lip in orphan_bones:
											orphan_bones.remove(lip)
					if limb.tongues_amount > 0:
						for tongueidx in range(1,limb.tongues_amount+1):
							prop_name= 'tongue_'+'%02d' % tongueidx
							tongue=getattr(limb,prop_name)
							if tongue != '':
								def_tongue_name= 'tong_'+'%02d' % tongueidx+'.x'
								skin_dict[tongue]={'deform':def_tongue_name, 'coords':get_bone_coords(tongue), 'prop_name':prop_name}
								ref_bones_head[tongue]= 'tong_'+'%02d' % tongueidx+'_ref.x'
								limb_valid_bones[limb.name].append(prop_name)
								if tongue in orphan_bones:
									orphan_bones.remove(tongue)
					if limb.facial_teeth:
						for lvl in ['top', 'bot']:
							prop_mid_name= 'teeth_'+lvl+'_mid'
							teeth_mid_bone=getattr(limb,prop_mid_name)
							if teeth_mid_bone != '':
								skin_dict[teeth_mid_bone]={'deform':'c_teeth_'+lvl+'.x', 'coords':get_bone_coords(teeth_mid_bone)}
								ref_bones_head[teeth_mid_bone]= 'teeth_'+lvl+'_ref.x'
								limb_valid_bones[limb.name].append(prop_mid_name)
								if teeth_mid_bone in orphan_bones:
									orphan_bones.remove(teeth_mid_bone)
							for teeth_side in ['left', 'right']:
								suff_side= '.l' if teeth_side== 'left' else '.r'
								prop_side_name= 'teeth_'+lvl+'_'+teeth_side
								teeth_side_bone=getattr(limb,prop_side_name)
								if teeth_side_bone != '':
									skin_dict[teeth_side_bone]={'deform':'c_teeth_'+lvl+suff_side, 'coords':get_bone_coords(teeth_side_bone)}
									ref_bones_head[teeth_side_bone]= 'teeth_'+lvl+'_ref'+suff_side
									limb_valid_bones[limb.name].append(prop_side_name)
									if teeth_side_bone in orphan_bones:
										orphan_bones.remove(teeth_side_bone)
					if limb.facial_chin:
						for chinidx in range(1,3):
							stri= '%02d' % chinidx
							prop_name= 'chin_'+stri
							chin=getattr(limb,prop_name)
							if chin != '':
								def_chin_name= 'c_chin_'+stri+'.x'
								skin_dict[chin]={'deform': def_chin_name, 'coords':get_bone_coords(chin), 'prop_name':prop_name}
								ref_bones_head[chin]= 'chin_'+stri+'_ref.x'
								limb_valid_bones[limb.name].append(prop_name)
								if chin in orphan_bones:
									orphan_bones.remove(chin)
			if neck != '':
				if limb.neck_bones_amount==1:
					skin_dict[neck]={'deform':'neck'+side, 'coords':get_bone_coords(neck)}
					def_bones.insert(0,neck)
					ref_bones_head[neck]= 'neck_ref'
				else:
					for i in range(1,limb.neck_bones_amount):
						cur_neck=necks_list[i-1]
						if self.neck_auto_twist:
							skin_dict[cur_neck]={'deform':'subneck_twist_'+str(i)+side, 'coords':get_bone_coords(cur_neck)}
						else:
							skin_dict[cur_neck]={'deform':'c_subneck_'+str(i)+side, 'coords':get_bone_coords(cur_neck)}
						ref_bones_head[cur_neck]= 'subneck_'+str(i)+'_ref'
						def_bones.insert(i-1,cur_neck)
					last_neck=necks_list[limb.neck_bones_amount-1]
					skin_dict[last_neck]={'deform':'neck'+side, 'coords':get_bone_coords(last_neck)}
					ref_bones_head[last_neck]= 'neck_ref'
					def_bones.insert(len(def_bones)-2,last_neck)
			if limb.primary_axis_auto:
				limb.primary_axis=find_primary_axis(def_bones)
			for bname in ref_bones_head:
				ebone=get_edit_bone(bname)
				if ebone:
					bone_tail=ebone.tail.copy()
					if bname==head:
						if head_end != '':
							bone_tail=get_edit_bone(head_end).head.copy()
					parent_name= '' if ebone.parent==None else ebone.parent.name
					ref_bone_name=ref_bones_head[bname]
					bones_coords[ref_bone_name]={'head':arm_mat @ ebone.head.copy(), 'tail':arm_mat @ bone_tail,'x_axis':(arm_mat_rot @ ebone.x_axis).normalized(), 'y_axis':(arm_mat_rot @ ebone.y_axis).normalized(), 'z_axis':(arm_mat_rot @ ebone.z_axis).normalized(),'name':ebone.name, 'parent_name':parent_name}# store bone data
		elif limb.type== 'TAIL':
			tail_root_name=limb.bone_01
			tail_tip_name=limb.bone_02
			ref_bones_tail=[]
			tail_children_bones=[tail_root_name] + get_bone_children(tail_root_name,single_child_only=True,tip_child=tail_tip_name)
			for i,b in enumerate(tail_children_bones):
				stri= '%02d' % i
				ref_name= 'tail_'+stri+'_ref'
				ref_bones_tail.append(ref_name)
			side= '.x'
			if limb.side== 'RIGHT':
				side= '.r'
			elif limb.side== 'LEFT':
				side= '.l'
			tail_limb_count=0
			if side== ".l":
				tail_limb_count_left +=1
				tail_limb_count=leg_limb_count_left
			elif side== ".r":
				tail_limb_count_right +=1
				tail_limb_count=tail_limb_count_right
			elif side== ".x":
				tail_limb_count_mid +=1
				tail_limb_count=tail_limb_count_mid
			dupli_id= ''
			if tail_limb_count > 1:
				ref_bones_tail_dupli=[]
				dupli_id= '{:03d}'.format(tail_limb_count-1)
				dupli_id= "_dupli_"+str(dupli_id)
				for ref_bone_name in ref_bones_tail:
					ref_bone_name_dupli=ref_bone_name+dupli_id
					ref_bones_tail_dupli.append(ref_bone_name_dupli)
				ref_bones_tail=ref_bones_tail_dupli
			for i,bname in enumerate(tail_children_bones):
				ebone=get_edit_bone(bname)
				stri= '%02d' % i
				c_name= 'c_tail_'+stri+dupli_id+side
				skin_dict[bname]={'deform':c_name, 'coords':get_bone_coords(bname)}
				self.tail_ctrl[ebone.name]=c_name
				parent_name= '' if ebone.parent==None else ebone.parent.name
				bones_coords[ref_bones_tail[i]]={'head':arm_mat @ ebone.head.copy(), 'tail':arm_mat @ ebone.tail.copy(),'x_axis':(arm_mat_rot @ ebone.x_axis).normalized(), 'y_axis':(arm_mat_rot @ ebone.y_axis).normalized(), 'z_axis':(arm_mat_rot @ ebone.z_axis).normalized(),'name':ebone.name, 'parent_name':parent_name}# store bone data
		limbs_coords[limb_idx]=bones_coords
	for limb_idx,limb in enumerate(scn.limb_map):
		main_bones=[limb.bone_01,limb.bone_02,limb.bone_03,limb.bone_04,limb.bone_05,limb.bone_06,limb.bone_07]
		if limb.twist_bones_amount==0:
			if limb.type== 'ARM':
				main_bones.remove(limb.bone_03)
				main_bones.remove(limb.bone_05)
			if limb.type== 'LEG':
				main_bones.remove(limb.bone_02)
				main_bones.remove(limb.bone_04)
		else:
			for i in range(2,limb.twist_bones_amount+1):
				id= '%02d' % (i)
				main_bones.append(get_limb_prop(limb, 'bone_twist_'+id+'_01'))
				main_bones.append(get_limb_prop(limb, 'bone_twist_'+id+'_02'))
		if limb.type== "HEAD":
			if limb.neck_bones_amount > 2:
				necks_list=[limb.neck3,limb.neck4,limb.neck5,limb.neck6,limb.neck7,limb.neck8,limb.neck9,limb.neck10]
				for i in range(3,limb.neck_bones_amount+1):
					main_bones.append(necks_list[i-3])
		if limb.type== "LEG":
			if limb.leg_type.startswith("3"):
				main_bones.append(limb.upper_thigh)
		if limb.type== 'TAIL':
			bones_coords=limbs_coords[limb_idx]
			for ref_name in bones_coords:
				bname=bones_coords[ref_name]['name']
				main_bones.append(bname)
		excluded_orphan_bones=["c_thigh_b"]
		if self.remove_root:
			root_names=['root', 'Root']
			for rn in root_names:
				r_bone=get_edit_bone(rn)
				if r_bone==None:
					continue
				if r_bone.parent==None:
					excluded_orphan_bones.append(rn)
		for mb_name in main_bones:
			if mb_name in orphan_bones:
				orphan_bones.remove(mb_name)
		for ex_name in excluded_orphan_bones:
			for b in orphan_bones:
				if b.startswith(ex_name):
					orphan_bones.remove(b)
	for or_name in orphan_bones:
		b=get_edit_bone(or_name)
		last_parent=b.parent
		original_parent_name=last_parent.name if last_parent !=None else ''
		search_for_parent=True
		matching_parent_name=None
		iter=0
		while search_for_parent and iter < 500:
			iter +=1
			if last_parent:
				for limb_idx,limb in enumerate(scn.limb_map):
					main_bones=[limb.bone_01,limb.bone_02,limb.bone_03,limb.bone_04,limb.bone_05,limb.bone_06,limb.bone_07]
					if limb.manual_phalanges:
						for phal_name in ['thumb2', 'thumb3', 'index1', 'index2', 'index3', 'middle1', 'middle2', 'middle3', 'ring1', 'ring2', 'ring3', 'pinky1', 'pinky2', 'pinky3']:
							main_bones.append(get_limb_prop(limb,phal_name))
					if limb.name in limb_valid_bones:
						for prop_name in limb_valid_bones[limb.name]:
							main_bones.append(get_limb_prop(limb,prop_name))
					if limb.type== 'TAIL':
						bones_coords=limbs_coords[limb_idx]
						for ref_name in bones_coords:
							bname=bones_coords[ref_name]['name']
							main_bones.append(bname)
					override_bones=[limb.override_bone_01,limb.override_bone_02,limb.override_bone_03,limb.override_bone_04,limb.override_bone_05,limb.override_bone_06,limb.override_bone_07]
					if last_parent.name in main_bones:
						idx=main_bones.index(last_parent.name)
						search_for_parent=False
						matching_parent_name=last_parent.name
						if idx < len(override_bones):
							if limb.weights_override and override_bones[idx] != "":
								if override_bones[idx] !=or_name:
									search_for_parent=False
									matching_parent_name=override_bones[idx]
					if search_for_parent==False:
						break
				last_parent=last_parent.parent
			else:
				search_for_parent=False
		if matching_parent_name==None:
			if b.parent:
				if b.parent.name in orphan_bones:
					matching_parent_name=b.parent.name
			else:
				matching_parent_name= "c_traj"
		if matching_parent_name !=None:
			self.orphan_bones_dict[or_name]={'original_name':or_name, 'parent':matching_parent_name,'original_parent':original_parent_name, 'head':arm_mat @ b.head.copy(), 'tail':arm_mat @ b.tail.copy(), 'roll':b.roll, 'x_axis':(arm_mat_rot @ b.x_axis).normalized()}
	bpy.ops.object.mode_set(mode='POSE')
	if len(self.orphan_bones_dict) and self.orphan_copy_cns:
		for or_name in self.orphan_bones_dict:
			orphan_pbone=get_pose_bone(or_name)
			if len(orphan_pbone.constraints):
				bones_cns_dict=pose_bones_constraints_to_dict(source_skeleton,[orphan_pbone])
				cns_dict=bones_cns_dict[or_name]
				base_dict=self.orphan_bones_dict[or_name].copy()
				new_dict={'constraints':cns_dict}
				base_dict.update(new_dict)
				self.orphan_bones_dict[or_name]=base_dict
	existing_rig=get_object('rig')
	if existing_rig:
		print("重命名“绑定”对象")
		existing_rig.name=existing_rig.name+'_old'
	if self.arp_ver_int >= 36820:
		bpy.ops.arp.append_arp(rig_preset='free')
	else:
		bpy.ops.arp.append_arp(rig_presets='free')
	for limb_idx,limb in enumerate(scn.limb_map):
		_side= ".l"
		if limb.side== "RIGHT":
			_side= ".r"
		elif limb.side== "CENTER":
			_side= ".x"
		if limb.type== "LEG":
			bpy.ops.arp.add_limb(limbs_presets='leg'+_side)
			enable_thumb=False
			enable_index=False
			enable_middle=False
			enable_ring=False
			enable_pinky=False
			if limb.fingers != "NONE":
				if limb.thumb != "":
					enable_thumb=True
				if limb.index != "":
					enable_index=True
				if limb.middle != "":
					enable_middle=True
				if limb.ring != "":
					enable_ring=True
				if limb.pinky  != "":
					enable_pinky=True
			if enable_thumb==False and enable_index==False and enable_middle==False and enable_ring==False and enable_pinky==False:
				limb.fingers= "NONE"
			_leg_twist_bones=limb.twist_bones_amount
			if _leg_twist_bones==0:
				_leg_twist_bones=1
			ctrl_bone_3= 'c_thigh_b'
			if limb.leg_type== '3_2':
				ctrl_bone_3= 'leg'
			bpy.ops.arp.show_limb_params(limb_type="leg",side=_side,leg_twist_bones=_leg_twist_bones,toes_thumb=enable_thumb,toes_index=enable_index,toes_middle=enable_middle,toes_ring=enable_ring,toes_pinky=enable_pinky,toes_metatarsal=limb.fingers== '4',toes_parent_foot=limb.toes_parent_foot,reset_to_default_settings=False,three_bones_leg=limb.leg_type.startswith('3'),three_bones_leg_ctrl=ctrl_bone_3,foot_ik_offset=False,leg_ikfk_default=self.leg_ik_fk,leg_auto_ik_roll=limb.auto_ik_roll)
		elif limb.type== "ARM":
			bpy.ops.arp.add_limb(limbs_presets='arm'+_side)
			enable_thumb=False
			enable_index=False
			enable_middle=False
			enable_ring=False
			enable_pinky=False
			if limb.fingers != "NONE":
				if limb.thumb != "":
					enable_thumb=True
				if limb.index != "":
					enable_index=True
				if limb.middle != "":
					enable_middle=True
				if limb.ring != "":
					enable_ring=True
				if limb.pinky  != "":
					enable_pinky=True
			if enable_thumb==False and enable_index==False and enable_middle==False and enable_ring==False and enable_pinky==False:
				limb.fingers= "NONE"
			_arm_twist_bones=limb.twist_bones_amount
			if _arm_twist_bones==0:
				_arm_twist_bones=1
			bpy.ops.arp.show_limb_params(limb_type="arm",side=_side,arm_twist_bones=_arm_twist_bones,finger_thumb=enable_thumb,finger_index=enable_index,finger_middle=enable_middle,finger_ring=enable_ring,finger_pinky=enable_pinky,reset_to_default_settings=False,arm_ikfk_default=self.arm_ik_fk,arm_auto_ik_roll=limb.auto_ik_roll)
		elif limb.type== "SPINE":
			bpy.ops.arp.add_limb(limbs_presets='spine')
			if self.arp_ver_int >=37110:
				bpy.ops.arp.show_limb_params(limb_type="spine",spine_count=limb.spine_amount,reset_to_default_settings=False)
			else:
				bpy.context.active_object.rig_spine_count=limb.spine_amount
				bpy.ops.arp.show_limb_params(limb_type="spine",reset_to_default_settings=False)
			if not limb.connect:
				for idx in range(1,limb.spine_amount+1):
					str_idx= '%02d' % (idx)
					spine_ref_name= 'spine_'+str_idx+'_ref.x'
					spine_ref=get_edit_bone(spine_ref_name)
					if spine_ref:
						spine_ref.use_connect=False
			"""# disable it for now,not always relevant. Depends on the skeleton proportions
			bpy.ops.object.mode_set(mode='POSE')
			get_pose_bone("c_root_master.x").custom_shape_scale=1.0
			get_pose_bone("c_root.x").custom_shape_scale=2.0
			bpy.ops.object.mode_set(mode='EDIT')
			"""
		elif limb.type== "HEAD":
			bpy.ops.arp.add_limb(limbs_presets='head')
			bpy.ops.arp.show_limb_params(limb_type='head',facial=limb.facial,facial_eye_l=limb.facial_eyes,facial_eye_r=limb.facial_eyes,eyeb_amount=limb.facial_eyebrows_amount,eyelids_amount=limb.facial_eyelids if limb.facial_eyelids > 0 else 1,facial_mouth=limb.facial_mouth,lips_amount=limb.lips_amount,lips_offset=limb.lips_offset,lips_roll_cns=not limb.lips_roll_sk,facial_cheeks=limb.facial_cheeks,facial_noses=limb.facial_nose,facial_tongue=limb.tongues_amount > 0,tongue_amount=limb.tongues_amount,facial_teeth=limb.facial_teeth,facial_chins=limb.facial_chin,reset_to_default_settings=False)
			if limb.neck_bones_amount > 1:
				bpy.ops.arp.show_limb_params(limb_type='neck',neck_count=limb.neck_bones_amount,neck_twist=self.neck_auto_twist,neck_bendy=1,reset_to_default_settings=False)
		elif limb.type== 'TAIL':
			bpy.ops.arp.add_limb(limbs_presets='tail')
			bones_coords=limbs_coords[limb_idx]
			_tail_count=len(bones_coords)
			bpy.ops.arp.show_limb_params(limb_type="tail",tail_count=_tail_count,tail_side=_side,tail_master_at_root=True,reset_to_default_settings=False)
	if "arp_rig_type" in bpy.context.active_object.keys():
		bpy.context.active_object.arp_rig_type= "quadruped"
	else:
		bpy.context.active_object.rig_type= "quadruped"
	self.arp_armature_name=bpy.context.active_object.name
	arp_armature=get_object(self.arp_armature_name)
	max_dim=0.0
	for d in source_skeleton.dimensions:
		if d > max_dim:
			max_dim=d
	arp_armature.dimensions[2]=max_dim
	arp_armature.scale[1]=arp_armature.scale[0]=arp_armature.scale[2]
	init_arp_scale(arp_armature)
	bpy.ops.object.mode_set(mode='EDIT')
	print("\nAdd orphan bones")
	for or_name in self.orphan_bones_dict.copy():
		if or_name.startswith("cor_"):
			continue
		or_bone=get_edit_bone(or_name)
		if or_bone==None:
			or_bone=arp_armature.data.edit_bones.new(or_name)
			or_bone.head,or_bone.tail=[0,0,0],[0,0,0.2]
		else:
			print('孤儿骨骼冲突:',or_name, '已存在于ARP骨架中')
			or_bone=arp_armature.data.edit_bones.new("cor_"+or_name)
			self.orphan_bones_dict["cor_"+or_name]=self.orphan_bones_dict[or_name]
			del self.orphan_bones_dict[or_name]
			skin_dict[or_name]={'deform':"cor_"+or_name, 'coords':None}
			for orname in self.orphan_bones_dict:
				if self.orphan_bones_dict[orname]['parent']==or_name:
					self.orphan_bones_dict[orname]={'original_name':self.orphan_bones_dict[orname]['original_name'],'parent':"cor_"+or_name, 'original_parent':self.orphan_bones_dict[orname]['original_parent'], 'head':self.orphan_bones_dict[orname]['head'], 'tail':self.orphan_bones_dict[orname]['tail'], 'roll':self.orphan_bones_dict[orname]['roll'], 'x_axis':self.orphan_bones_dict[orname]['x_axis']}
			or_name= "cor_"+or_name
		set_bone_layer(or_bone,self.orphan_bones_collection,idx=self.orphan_bones_layer)
	print("\nSet orphan bones transforms and parent...")
	for or_name in self.orphan_bones_dict.copy():
		or_bone=get_edit_bone(or_name)
		matching_bone_parent_name=self.orphan_bones_dict[or_name]['parent']
		original_parent_name=self.orphan_bones_dict[or_name]['original_parent']
		or_bone.head=self.orphan_bones_dict[or_name]['head']
		or_bone.tail=self.orphan_bones_dict[or_name]['tail']
		or_bone.roll=self.orphan_bones_dict[or_name]['roll']
		or_bone_x_axis=self.orphan_bones_dict[or_name]['x_axis']
		align_bone_x_axis(or_bone,or_bone_x_axis)
		has_child_of_cns=False
		if 'constraints' in self.orphan_bones_dict[or_name]:
			or_bone_cns=self.orphan_bones_dict[or_name]['constraints']
			for cns in or_bone_cns:
				if cns['type']== 'CHILD_OF':
					has_child_of_cns=True
		parent_name=None
		parent_name_main=None
		parent_name_or=None
		if original_parent_name in self.orphan_bones_dict:
			parent_name_or=original_parent_name
		elif matching_bone_parent_name in self.orphan_bones_dict:
			parent_name_or=matching_bone_parent_name
		if matching_bone_parent_name in skin_dict:
			parent_name_main=skin_dict[matching_bone_parent_name]['deform']
		elif or_name in skin_dict:
			parent_name_main=skin_dict[or_name]['deform']
		if parent_name_main and parent_name_or==None:
			parent_name=parent_name_main
		elif parent_name_main==None and parent_name_or:
			parent_name=parent_name_or
		if parent_name_main and parent_name_or:
			if self.orphan_bones_parent_to_def:
				parent_name=parent_name_main
			else:
				parent_name=parent_name_or
		if parent_name==None:
			print("找不到孤立骨骼的父级：: "+or_name+".改为设置为c_traj")
			parent_name= "c_traj"
		if parent_name:
			if has_child_of_cns==False:
				parent=get_edit_bone(parent_name)
				or_bone.parent=parent
	def get_source_ref_match(limb_type,ref_bone_name):
		ref_list=[]
		spine_source_ref_matches=["root_ref", "spine_01_ref", "spine_02_ref", "spine_03_ref", "spine_04_ref", "spine_05_ref", "spine_06_ref"]
		if limb_type== "SPINE":
			ref_list=spine_source_ref_matches
		limb=None
		limb_side= ""
		for _limb in scn.limb_map:
			if _limb.type==limb_type:
				limb=_limb
				if _limb.side== "CENTER":
					limb_side= ".x"
				elif limb_side== "LEFT":
					limb_side= ".l"
				elif limb_side== "RIGHT":
					limb_side= ".r"
				break
		bone_parent_match=None
		if limb:
			limb_bones_list=[limb.bone_01,limb.bone_02,limb.bone_03,limb.bone_04,limb.bone_05,limb.bone_06,limb.bone_07]
			for i,bones_name in enumerate(ref_list):
				if limb_bones_list[i]==ref_bone_name:
					bone_parent_match=bones_name+limb_side
					break
		if bone_parent_match==None:
			print("Bone parent seems to be an orphan bone,parent to "+ref_bone_name)
			bone_parent_match=ref_bone_name
		return bone_parent_match
	if self.mode== 'PRESERVE':
		for base_bone_name in skin_dict:
			if skin_dict[base_bone_name]['coords']==None:
				continue
			h_bone=arp_armature.data.edit_bones.new(base_bone_name+'_qr_offset')
			h_bone.head,h_bone.tail=skin_dict[base_bone_name]['coords'][0],skin_dict[base_bone_name]['coords'][1]
			h_bone_x_axis=skin_dict[base_bone_name]['coords'][2]
			align_bone_x_axis(h_bone,h_bone_x_axis)
			h_bone.parent=get_edit_bone(skin_dict[base_bone_name]['deform'])
			set_bone_layer(h_bone, 'qr_helpers',idx=15)
			h_bone.use_deform=False
	skinned_objects=[]
	for obj in bpy.data.objects:
		if obj.type != 'MESH':
			continue
		if len(obj.modifiers):
			for mod in obj.modifiers:
				if mod.type != 'ARMATURE':
					continue
				if mod.object==source_skeleton:
					if not obj in skinned_objects:
						skinned_objects.append(obj)
	eyelids_weights_centers={}
	evaluate_eyelid_weights_centroids=False
	for limb_idx in range(0,len(scn.limb_map)):
		limb=scn.limb_map[limb_idx]
		if limb.type== 'HEAD' and limb.facial and limb.eyelids_align_engine== 'WEIGHTS':
			evaluate_eyelid_weights_centroids=True
			break
	if evaluate_eyelid_weights_centroids:
		print('收集眼睑骨骼...')
		for def_bone_name in skin_dict:
			if not 'prop_name' in skin_dict[def_bone_name]: continue
			pname=skin_dict[def_bone_name]['prop_name']
			if pname.startswith('eyelid_top_') or pname.startswith('eyelid_bot_') or pname.startswith('eyelid_corner_in') or pname.startswith('eyelid_corner_out'):
				if not def_bone_name in eyelids_weights_centers:
					eyelids_weights_centers[def_bone_name]=None
		eyelid_weights={}
		for obj in skinned_objects:
			for vert in obj.data.vertices:
				for grp in vert.groups:
					grp_name=obj.vertex_groups[grp.group].name
					if not grp_name in eyelids_weights_centers or grp.weight < 0.001: continue
					vert_pos=obj.matrix_world @ vert.co
					if not grp_name in eyelid_weights:
						eyelid_weights[grp_name]=[(vert_pos,grp.weight)]
					else:
						eyelid_weights[grp_name].append((vert_pos,grp.weight))
		print('计算眼睑顶点权重质心...')
		for eyelid_name in eyelid_weights:
			tot_sum=Vector((0,0,0))
			tot_weights=0.0
			for w in eyelid_weights[eyelid_name]:
				vpos,vweight=w
				tot_sum +=vpos * vweight
				tot_weights +=vweight
			average_pos=tot_sum / tot_weights
			eyelids_weights_centers[eyelid_name]=average_pos
	shape_keys_drivers={}# shape_key_name: bone_driver,prop_path,expression
	for limb_idx in range(0,len(scn.limb_map)):
		limb=scn.limb_map[limb_idx]
		print("\nAligning limb:",limb.type)
		bones_coords=limbs_coords[limb_idx]
		if limb.type== 'LEG':
			side= '.l' if limb.side== 'LEFT' else '.r'
			dupli_idx= ''
			for bone_ref_name in bones_coords:
				if "_dupli_" in bone_ref_name:
					dupli_idx= "_dupli_"+str(bone_ref_name[-3:])
				break
			limb.dupli_idx=dupli_idx
			if limb.leg_type.startswith("3"):
				thigh_b_ref=get_edit_bone("thigh_b_ref"+dupli_idx+side)
				thigh_b_ref.head=bones_coords["thigh_b_ref"+dupli_idx]['head']
				thigh_b_ref.tail=bones_coords["thigh_ref"+dupli_idx]['head']
				roll_fac=1 if side== ".l" else -1
				align_bone_x_axis(thigh_b_ref,Vector((0,1*roll_fac,0)))
			thigh_ref=get_edit_bone("thigh_ref"+dupli_idx+side)
			thigh_ref.head=bones_coords["thigh_ref"+dupli_idx]['head']
			thigh_ref.tail=bones_coords["leg_ref"+dupli_idx]['head']
			if limb.leg_type.startswith("3"):
				bone_parent_name=bones_coords["thigh_b_ref"+dupli_idx]['parent_name']
				bone_parent_match_name=get_source_ref_match("SPINE",bone_parent_name)
				print("  Upper Thigh parent:",bone_parent_name, ">",bone_parent_match_name)
				if bone_parent_match_name:
					thigh_b_ref.parent=get_edit_bone(bone_parent_match_name)
			elif limb.leg_type== "2":
				bone_parent_name=bones_coords["thigh_ref"+dupli_idx]['parent_name']
				bone_parent_match_name=get_source_ref_match("SPINE",bone_parent_name)
				print("  Thigh parent:",bone_parent_name, ">",bone_parent_match_name)
				if bone_parent_match_name:
					thigh_ref.parent=get_edit_bone(bone_parent_match_name)
			leg_ref=get_edit_bone("leg_ref"+dupli_idx+side)
			leg_ref.head=bones_coords["leg_ref"+dupli_idx]['head']
			if limb.connect_foot_to_calf:
				leg_ref.tail=bones_coords["leg_ref"+dupli_idx]['tail']
			else:
				leg_ref.tail=bones_coords["foot_ref"+dupli_idx]['head']
			foot_ref_name= "foot_ref"+dupli_idx
			foot_ref=get_edit_bone(foot_ref_name+side)
			if limb.connect_foot_to_calf:
				foot_ref.head=leg_ref.tail.copy()
			else:
				foot_ref.head=bones_coords[foot_ref_name]['head']
			toes_ref_name= "toes_ref"+dupli_idx
			if toes_ref_name in bones_coords:
				foot_ref.tail=bones_coords[toes_ref_name]['head']
			else:
				foot_length=(bones_coords[foot_ref_name]['head'] - bones_coords[foot_ref_name]['tail']).magnitude*0.5
				dir_vec=1 if not '-' in limb.foot_dir_axis else -1
				if  'X' in limb.foot_dir_axis:
					foot_ref.tail=foot_ref.head + bones_coords[foot_ref_name]['x_axis'] * dir_vec * foot_length
				elif 'Y' in limb.foot_dir_axis:
					foot_ref.tail=foot_ref.head + (bones_coords[foot_ref_name]['y_axis'] * dir_vec) * foot_length
				elif 'Z' in limb.foot_dir_axis:
					foot_ref.tail=foot_ref.head + bones_coords[foot_ref_name]['z_axis'] * dir_vec * foot_length
			if limb.force_up_axis:
				align_bone_z_axis(foot_ref,Vector((0,0,1)))
			else:
				align_bone_x_axis(foot_ref,bones_coords["foot_ref"+dupli_idx]['x_axis'])
				if limb.up_axis== "-Z":
					foot_ref.roll +=math.radians(180)
				elif limb.up_axis== "X":
					foot_ref.roll +=math.radians(90)
				elif limb.up_axis== "-X":
					foot_ref.roll +=math.radians(-90)
			if limb.auto_knee:
				median_point=(foot_ref.head + thigh_ref.head) * 0.5
				if thigh_ref.tail[1] > median_point[1]:
					print("  膝盖指向向后，纠正它")
					thigh_ref.tail[1]=median_point[1] + (median_point[1] - thigh_ref.tail[1])*0.1
				thigh_ref.tail=project_point_onto_plane(thigh_ref.tail,thigh_ref.head,(foot_ref.tail-foot_ref.head).cross(foot_ref.tail-thigh_ref.head))
			toes_ref=get_edit_bone(toes_ref_name+side)
			if toes_ref_name in bones_coords:
				toes_ref.head=bones_coords[toes_ref_name]['head']
				if limb.bone_07 != "":
					toes_ref.tail=bones_coords["toes_ref"+dupli_idx]['tail']
				else:
					toes_ref.tail=toes_ref.head + (foot_ref.tail-foot_ref.head)*0.5
			else:
				toes_ref.head=foot_ref.tail.copy()
				toes_ref.tail=toes_ref.head + (foot_ref.tail-foot_ref.head)*0.5
				toes_ref.roll=foot_ref.roll
			align_bone_x_axis(toes_ref,foot_ref.x_axis)
			if not limb.force_up_axis:
				if limb.up_axis== "-Z":
					toes_ref.roll +=math.radians(180)
				elif limb.up_axis== "X":
					toes_ref.roll +=math.radians(90)
				elif limb.up_axis== "-X":
					toes_ref.roll +=math.radians(-90)
			heel_mid=get_edit_bone("foot_heel_ref"+dupli_idx+side)
			heel_mid.head[0],heel_mid.head[1],heel_mid.head[2]=foot_ref.head[0],foot_ref.head[1],foot_ref.tail[2]
			heel_mid.tail=foot_ref.tail.copy()
			heel_mid.tail[2]=heel_mid.head[2]
			heel_mid.tail=heel_mid.head + (heel_mid.tail-heel_mid.head)*0.5
			align_bone_x_axis(heel_mid,foot_ref.x_axis)
			heel_in=get_edit_bone("foot_bank_02_ref"+dupli_idx+side)
			heel_in.head,heel_in.tail,heel_in.roll=heel_mid.head.copy(),heel_mid.tail.copy(),heel_mid.roll
			foot_x_axis=foot_ref.x_axis
			vec_test_in=foot_ref.head
			vec_test_out=foot_ref.head + foot_ref.x_axis
			if vec_test_out[0] < vec_test_in[0] and side== ".r":
				foot_x_axis *=-1
			if vec_test_out[0] > vec_test_in[0] and side== ".l":
				foot_x_axis *=-1
			heel_in.head +=foot_x_axis.normalized() * foot_ref.length*0.3
			heel_in.tail +=foot_x_axis.normalized() * foot_ref.length*0.3
			heel_out=get_edit_bone("foot_bank_01_ref"+dupli_idx+side)
			heel_out.head,heel_out.tail,heel_out.roll=heel_mid.head.copy(),heel_mid.tail.copy(),heel_mid.roll
			foot_x_axis *=-1
			heel_out.head +=foot_x_axis.normalized() * foot_ref.length*0.3
			heel_out.tail +=foot_x_axis.normalized() * foot_ref.length*0.3
			thigh_proj_z=project_vec_onto_plane(thigh_ref.y_axis,thigh_ref.z_axis)
			leg_proj_z=project_vec_onto_plane(leg_ref.y_axis,thigh_ref.z_axis)
			leg_angle=math.degrees(thigh_proj_z.angle(leg_proj_z))
			if abs(leg_angle) < 0.1:
				print("  警告：直腿角度。添加偏移...")
				iter=0
				while abs(leg_angle) < 0.1 and iter < 1000:
					print("iter",iter)
					foot_dir=foot_ref.tail-foot_ref.head
					leg_ref.head +=foot_dir*0.001
					leg_angle=math.degrees(leg_ref.y_axis.angle(thigh_ref.y_axis))
					iter +=1
					if iter >=1000:
						print("  达到最大迭代次数，退出")
				print("  New angle:",leg_angle)
			if limb.fingers != 'NONE':
				print('对齐脚趾和手指...')
				ref_bones_fingers={}
				if limb.fingers== "3":
					ref_bones_fingers=ref_bones_toes_3
				elif limb.fingers== "4":
					ref_bones_fingers=ref_bones_toes_4
				for finger_type in ref_bones_fingers:
					for finger_ref_name in ref_bones_fingers[finger_type]:
						finger_ref=get_edit_bone(finger_ref_name+dupli_idx+side)
						if not finger_ref_name+dupli_idx in bones_coords or finger_ref==None:
							print("  Finger not found",finger_ref_name+dupli_idx,finger_ref)
							continue
						finger_ref.head,finger_ref.tail=bones_coords[finger_ref_name+dupli_idx]['head'],bones_coords[finger_ref_name+dupli_idx]['tail']
						if len(finger_ref.children)==0:
							bone_primary_axis=get_bone_primary_axis(limb.primary_axis,bones_coords,finger_ref_name+dupli_idx)
							finger_length=(finger_ref.tail - finger_ref.head).magnitude
							finger_ref.tail=finger_ref.head + (bone_primary_axis.normalized() * finger_length)
				for finger_type in ref_bones_fingers:
					for finger_ref_name in ref_bones_fingers[finger_type]:
						finger_ref=get_edit_bone(finger_ref_name+dupli_idx+side)
						if not finger_ref_name+dupli_idx in bones_coords or finger_ref==None:
							continue
						if "Y" in limb.up_axis:
							align_bone_z_axis(finger_ref,bones_coords[finger_ref_name+dupli_idx]['y_axis'])
							if "-" in limb.up_axis:
								finger_ref.roll +=math.radians(180)
						else:
							align_bone_x_axis(finger_ref,bones_coords[finger_ref_name+dupli_idx]['x_axis'])
							if limb.up_axis== "-Z":
								finger_ref.roll +=math.radians(180)
							elif limb.up_axis== "X":
								finger_ref.roll +=math.radians(90)
							elif limb.up_axis== "-X":
								finger_ref.roll +=math.radians(-90)
				'''
				if limb.fingers== "3":
					base_fingers_names=["index1_base_ref", "middle1_base_ref", "ring1_base_ref", "pinky1_base_ref"]
					for bfinger_name in base_fingers_names:
						base_finger=get_edit_bone(bfinger_name+dupli_idx+side)
						if base_finger==None:
							continue
						base_finger.head=hand_ref.head + (base_finger.tail - hand_ref.head)*0.2
						align_bone_x_axis(base_finger,hand_ref.x_axis)
				'''
		elif limb.type== 'ARM':
			side= '.l' if limb.side== "LEFT" else '.r'
			dupli_idx= ""
			for bone_ref_name in bones_coords:
				if '_dupli_' in bone_ref_name:
					dupli_idx= '_dupli_'+str(bone_ref_name[-3:])
				break
			print('  '+dupli_idx+side)
			limb.dupli_idx=dupli_idx
			shoulder_ref_name= 'shoulder_ref'+dupli_idx
			shoulder_ref=get_edit_bone(shoulder_ref_name+side)
			if shoulder_ref_name in bones_coords:
				shoulder_ref.head=bones_coords[shoulder_ref_name]['head']
				shoulder_ref.tail=bones_coords['arm_ref'+dupli_idx]['head']
				align_bone_z_axis(shoulder_ref,Vector((0,0,1)))
				bone_parent_name=bones_coords[shoulder_ref_name]['parent_name']
				bone_parent_match_name=get_source_ref_match("SPINE",bone_parent_name)
				print("  Shoulder parent:",bone_parent_name, ">",bone_parent_match_name)
				if bone_parent_match_name:
					shoulder_ref.parent=get_edit_bone(bone_parent_match_name)
			else:
				shoulder_ref.tail=bones_coords["arm_ref"+dupli_idx]['head']
				forearm_head=bones_coords["forearm_ref"+dupli_idx]['head']
				shoulder_ref.head=shoulder_ref.tail - (forearm_head - shoulder_ref.tail)/2
				align_bone_z_axis(shoulder_ref,Vector((0,0,1)))
				bone_parent_name=bones_coords["arm_ref"+dupli_idx]['parent_name']
				bone_parent_match_name=get_source_ref_match("SPINE",bone_parent_name)
				print("  Shoulder parent:",bone_parent_name, ">",bone_parent_match_name)
				if bone_parent_match_name:
					shoulder_ref.parent=get_edit_bone(bone_parent_match_name)
			arm_ref=get_edit_bone("arm_ref"+dupli_idx+side)
			arm_ref.head=bones_coords["arm_ref"+dupli_idx]['head']
			arm_ref.tail=bones_coords["forearm_ref"+dupli_idx]['head']
			hand_ref_name= "hand_ref"+dupli_idx
			forearm_ref=get_edit_bone("forearm_ref"+dupli_idx+side)
			forearm_ref.head=bones_coords["forearm_ref"+dupli_idx]['head']
			forearm_ref.tail=bones_coords[hand_ref_name]['head']
			if "Y" in limb.up_axis_arm:
				align_bone_z_axis(arm_ref,bones_coords["arm_ref"+dupli_idx]['y_axis'])
				align_bone_z_axis(forearm_ref,bones_coords["forearm_ref"+dupli_idx]['y_axis'])
			elif "Z" in limb.up_axis_arm:
				align_bone_z_axis(arm_ref,bones_coords["arm_ref"+dupli_idx]['z_axis'])
				align_bone_z_axis(forearm_ref,bones_coords["forearm_ref"+dupli_idx]['z_axis'])
			elif "X" in limb.up_axis_arm:
				align_bone_z_axis(arm_ref,bones_coords["arm_ref"+dupli_idx]['x_axis'])
				align_bone_z_axis(forearm_ref,bones_coords["forearm_ref"+dupli_idx]['x_axis'])
			if "-" in limb.up_axis_arm:
				arm_ref.roll +=math.radians(180)
				forearm_ref.roll +=math.radians(180)
			hand_ref=get_edit_bone(hand_ref_name+side)
			hand_ref.head=bones_coords[hand_ref_name]['head']
			hand_length=(bones_coords[hand_ref_name]['tail'] - bones_coords[hand_ref_name]['head']).magnitude
			hand_primary_axis=None
			if limb.primary_axis_auto:
				multi_axes_list=limb.primary_axis_auto_multi.replace(' ','').split(',')
				hand_primary_axis=multi_axes_list[len(multi_axes_list)-1]
			else:
				hand_primary_axis=limb.primary_axis
			bone_primary_axis=get_bone_primary_axis(hand_primary_axis,bones_coords,hand_ref_name)
			hand_ref.tail=hand_ref.head + bone_primary_axis.normalized() * hand_length
			if "Y" in limb.up_axis:
				align_bone_z_axis(hand_ref,bones_coords[hand_ref_name]['y_axis'])
			elif "Z" in limb.up_axis:
				align_bone_z_axis(hand_ref,bones_coords[hand_ref_name]['z_axis'])
			elif "X" in limb.up_axis:
				align_bone_x_axis(hand_ref,bones_coords[hand_ref_name]['x_axis'])
				hand_ref.roll +=math.radians(90)
			if "-" in limb.up_axis:
				hand_ref.roll +=math.radians(180)
			arm_proj_z=project_vec_onto_plane(arm_ref.y_axis,arm_ref.z_axis)
			forearm_proj_z=project_vec_onto_plane(forearm_ref.y_axis,arm_ref.z_axis)
			arm_angle=math.degrees(arm_proj_z.angle(forearm_proj_z))
			if abs(arm_angle) < 0.1:
				print("  警告：直臂角度。添加偏移...")
				fac=-1 if '-' in limb.IK_axis_correc else 1
				vec=Vector((fac*1,0,0))
				if 'Y' in limb.IK_axis_correc:
					vec=Vector((0,fac*1,0))
				elif 'Z' in limb.IK_axis_correc:
					vec=Vector((0,0,fac*1))
				t=0
				while abs(arm_angle) < 0.1 and t < 1000:
					add_vec=vec * (arm_ref.tail - arm_ref.head).magnitude*0.5
					forearm_ref.head +=add_vec * 0.001
					arm_angle=math.degrees(arm_ref.y_axis.angle(forearm_ref.y_axis))
					t +=1
				print("  New angle:",arm_angle)
			if limb.auto_elbow:
				arm_vec=(hand_ref.head - arm_ref.head).normalized()
				mid_point=(hand_ref.head + arm_ref.head) * 0.5
				mid_vec=(forearm_ref.head - mid_point).normalized()
				local_z=arm_vec.cross(mid_vec)
				_arm_side= 'left' if hand_ref.head[0] > arm_ref.head[0] else 'right'
				inverted=False
				if local_z[2] < 0 and _arm_side== 'left':
					inverted=True
				elif local_z[2] > 0 and _arm_side== 'right':
					inverted=True
				if inverted:
					print("  肘部倒置，纠正它...")
					push_vec=mid_point - forearm_ref.head
					arm_length=(arm_ref.tail - arm_ref.head).magnitude
					add_offset=(push_vec.normalized() * arm_length*0.08)
					forearm_ref.head=forearm_ref.head + push_vec + add_offset
			if limb.fingers != 'NONE':
				ref_bones_fingers={}
				if limb.fingers== '3':
					ref_bones_fingers=ref_bones_fingers_3
				elif limb.fingers== '4':
					ref_bones_fingers=ref_bones_fingers_4
				for finger_type in ref_bones_fingers:
					for finger_ref_name in ref_bones_fingers[finger_type]:
						finger_ref=get_edit_bone(finger_ref_name+dupli_idx+side)
						if not finger_ref_name+dupli_idx in bones_coords or finger_ref==None:
							print('  Finger not found',finger_ref_name+dupli_idx,finger_ref)
							continue
						finger_ref.head,finger_ref.tail=bones_coords[finger_ref_name+dupli_idx]['head'],bones_coords[finger_ref_name+dupli_idx]['tail']
						if len(finger_ref.children)==0:
							finger_primary_axis=get_bone_primary_axis(limb.primary_axis_fingers,bones_coords,finger_ref_name+dupli_idx)
							finger_length=(finger_ref.tail - finger_ref.head).magnitude
							finger_ref.tail=finger_ref.head + (finger_primary_axis.normalized() * finger_length)
				for finger_type in ref_bones_fingers:
					for finger_ref_name in ref_bones_fingers[finger_type]:
						finger_ref=get_edit_bone(finger_ref_name+dupli_idx+side)
						if not finger_ref_name+dupli_idx in bones_coords or finger_ref==None:
							continue
						if 'Y' in limb.up_axis:
							align_bone_z_axis(finger_ref,bones_coords[finger_ref_name+dupli_idx]['y_axis'])
						elif 'X' in limb.up_axis:
							align_bone_z_axis(finger_ref,bones_coords[finger_ref_name+dupli_idx]['x_axis'])
						elif 'Z' in limb.up_axis:
							align_bone_z_axis(finger_ref,bones_coords[finger_ref_name+dupli_idx]['z_axis'])
						if '-' in limb.up_axis:
							finger_ref.roll +=math.radians(180)
				if limb.fingers== "3":
					base_fingers_names=["index1_base_ref", "middle1_base_ref", "ring1_base_ref", "pinky1_base_ref"]
					for bfinger_name in base_fingers_names:
						base_finger=get_edit_bone(bfinger_name+dupli_idx+side)
						if base_finger==None:
							continue
						base_finger.head=hand_ref.head + (base_finger.tail - hand_ref.head)*0.2
						align_bone_x_axis(base_finger,hand_ref.x_axis)
		elif limb.type== 'SPINE':
			side= '.x'
			root_ref=get_edit_bone('root_ref'+side)
			root_ref.head=bones_coords['root_ref']['head']
			if 'spine_01_ref' in bones_coords:
				spine_01_head=bones_coords['spine_01_ref']['head']
			else:
				spine_01_head=bones_coords['root_ref']['tail']
			same_pos=[False,False,False]
			for i in range(0,3):
				if round(spine_01_head[i],4)==round(root_ref.head[i],4):
					same_pos[i]=True
			if same_pos==[True,True,True]:
				print('警告，root_ref头部位置相同(空长度)，然后改用尾部位置作为头部')
				root_ref.head=bones_coords["root_ref"]['tail']
			if limb.connect:
				root_ref.tail=spine_01_head
			else:
				bone_primary_axis=get_bone_primary_axis(limb.primary_axis,bones_coords, 'root_ref')
				root_ref_length=(spine_01_head-root_ref.head).magnitude
				root_ref.tail=root_ref.head + (bone_primary_axis.normalized() * root_ref_length)
			if limb.force_z_axis:
				align_bone_z_axis(root_ref,Vector((0,-1,0)))
			else:
				align_bone_x_axis(root_ref,bones_coords["root_ref"]['x_axis'])
			prev_spine_ref_name= 'root_ref'+side
			for idx in range(2,limb.spine_amount+1):
				str_idx= '%02d' % idx
				stri_ref= '%02d' % (idx-1)
				prop_name= 'bone_'+str_idx
				source_spine_name=getattr(limb,prop_name)
				if source_spine_name != '':
					prev_stri_ref= '%02d' % (idx-2)
					spine_ref_name_no_side= 'spine_'+stri_ref+'_ref'
					spine_ref_name=spine_ref_name_no_side+side
					spine_ref=get_edit_bone(spine_ref_name)
					if idx > 2:
						prev_spine_ref_name= 'spine_'+prev_stri_ref+'_ref'+side
					prev_spine_ref=get_edit_bone(prev_spine_ref_name)
					spine_ref.head=bones_coords[spine_ref_name_no_side]['head']
					if limb.connect:
						spine_ref.tail=spine_ref.head + (prev_spine_ref.tail - prev_spine_ref.head)
					else:
						bone_primary_axis=get_bone_primary_axis(limb.primary_axis,bones_coords,spine_ref_name_no_side)
						spine_ref_length=(prev_spine_ref.tail - prev_spine_ref.head).magnitude
						spine_ref.tail=spine_ref.head + (bone_primary_axis.normalized() * spine_ref_length)
			for idx in range(2,limb.spine_amount+1):
				str_idx= '%02d' % idx
				prop_name= 'bone_'+str_idx
				source_spine_name=getattr(limb,prop_name)
				if source_spine_name != '':
					stri_ref= '%02d' % (idx-1)
					spine_ref_name_no_side= 'spine_'+stri_ref+'_ref'
					spine_ref_name=spine_ref_name_no_side+side
					spine_ref=get_edit_bone(spine_ref_name)
					if limb.force_z_axis:
						align_bone_z_axis(spine_ref,Vector((0,-1,0)))
					else:
						align_bone_x_axis(spine_ref,bones_coords[spine_ref_name_no_side]['x_axis'])
			if limb.pelvis_up:
				first_spine_name= 'spine_01_ref.x'
				first_spine=get_edit_bone(first_spine_name)
				if first_spine:
					first_spine.use_connect=False
				last_spine_idx=limb.spine_amount-1
				str_idx= '%02d' % last_spine_idx
				last_spine_name= 'spine_'+str_idx+'_ref.x' if str_idx != '00' else 'root_ref.x'
				last_spine=get_edit_bone(last_spine_name)
				spine_vec=last_spine.tail - root_ref.head
				root_ref.tail=root_ref.head + Vector((0,0,spine_vec.magnitude*0.2))
				if limb.force_z_axis:
					align_bone_z_axis(root_ref,Vector((0,-1,0)))
				else:
					align_bone_x_axis(root_ref,bones_coords['root_ref']['x_axis'])
		elif limb.type== 'HEAD':
			side= '.x'
			subneck_ref=None
			last_subneck_ref=None
			if limb.neck_bones_amount > 1:
				for sni in range(1,limb.neck_bones_amount):
					subneck_name= 'subneck_'+str(sni)+'_ref'
					next_subneck_name= 'subneck_'+str(sni+1)+'_ref'
					subneck_ref=get_edit_bone(subneck_name+side)
					last_subneck_ref=subneck_ref
					subneck_ref.use_connect=False
					subneck_ref.head=bones_coords[subneck_name]['head']
					if sni==limb.neck_bones_amount-1:
						subneck_ref.tail=bones_coords['neck_ref']['head']
					else:
						subneck_ref.tail=bones_coords[next_subneck_name]['head']
					if limb.force_z_axis:
						align_bone_z_axis(subneck_ref,Vector((0,-1,0)))
					else:
						align_bone_x_axis(subneck_ref,bones_coords[subneck_name]['x_axis'])
					bone_parent_name=bones_coords[subneck_name]['parent_name']
					bone_parent_match_name=get_source_ref_match('SPINE',bone_parent_name)
					print('  Neck parent: '+str(bone_parent_name)+' > '+str(bone_parent_match_name))
					if bone_parent_match_name:
						subneck_ref.parent=get_edit_bone(bone_parent_match_name)
			neck_ref=get_edit_bone('neck_ref'+side)
			neck_ref.use_connect=False
			parent_ref= 'neck_ref'
			if 'neck_ref' in bones_coords:
				neck_ref.head=bones_coords['neck_ref']['head']
				neck_ref.tail=bones_coords['head_ref']['head']
				if limb.force_z_axis:
					align_bone_z_axis(neck_ref,Vector((0,-1,0)))
				else:
					align_bone_x_axis(neck_ref,bones_coords['neck_ref']['x_axis'])
			else:
				parent_ref= "head_ref"
				neck_ref.tail=bones_coords["head_ref"]['head']
				head_end=bones_coords["head_ref"]['tail']
				neck_ref.head=neck_ref.tail - (head_end - neck_ref.tail)/2
				align_bone_x_axis(neck_ref,bones_coords["head_ref"]['x_axis'])
			if limb.neck_bones_amount==1:
				bone_parent_name=bones_coords[parent_ref]['parent_name']
				bone_parent_match_name=get_source_ref_match("SPINE",bone_parent_name)
				print('  Neck parent:',bone_parent_name, '>',bone_parent_match_name)
				if bone_parent_match_name:
					neck_ref.parent=get_edit_bone(bone_parent_match_name)
			else:
				neck_ref.parent=last_subneck_ref
			head_ref_name= 'head_ref'
			head_ref=get_edit_bone(head_ref_name+side)
			head_ref.head=bones_coords[head_ref_name]['head']
			head_length=(bones_coords[head_ref_name]['tail'] - bones_coords[head_ref_name]['head']).magnitude
			bone_primary_axis=get_bone_primary_axis(limb.primary_axis,bones_coords,head_ref_name)
			head_axis=bone_primary_axis if not limb.straight_head else Vector((0,0,1))
			head_ref.tail=head_ref.head + head_axis.normalized() * head_length
			if limb.force_z_axis:
				align_bone_z_axis(head_ref,Vector((0,-1,0)))
			else:
				align_bone_x_axis(head_ref,bones_coords[head_ref_name]['x_axis'])
			if limb.facial:
				if limb.facial_eyebrows:
					for fside in ['left', 'right']:
						if fside== 'left' and not limb.facial_left or fside== 'right' and not limb.facial_right: continue
						side_dir=1 if fside== 'left' else -1
						suff_side= '.l' if fside== 'left' else '.r'
						eyeb_dist=0.0
						length=0.0
						average_len=0
						average_pos=Vector((0,0,0))
						for eyebidx in range(1,limb.facial_eyebrows_amount+1):
							stri= '%02d' % eyebidx
							stri_prev= '%02d' % (eyebidx-1)
							eyebrow_prop_name= 'eyebrow_'+stri+'_'+fside
							eyebrow_name=getattr(limb,eyebrow_prop_name)
							if eyebrow_name != '':
								eyebrow_ref_name= 'eyebrow_01_end_ref'+suff_side if eyebidx==1 else 'eyebrow_'+stri_prev +'_ref'+suff_side
								eyebrow_ref_eb=get_edit_bone(eyebrow_ref_name)
								if eyebidx==1 and limb.facial_eyebrows_amount > 1:
									eyebrow_02_name=getattr(limb, 'eyebrow_'+'%02d' % (eyebidx+1)+'_'+fside)
									if eyebrow_02_name != '':
										eyebrow_01_ref_name= 'eyebrow_01_ref'+suff_side
										eyeb_dist=(bones_coords[eyebrow_01_ref_name]['head'] - bones_coords[eyebrow_ref_name]['head']).magnitude * 0.3
								eyebrow_ref_eb.head=bones_coords[eyebrow_ref_name]['head']
								length=eyeb_dist if eyeb_dist !=0.0 else max_dim / 80
								eyebrow_ref_eb.tail=eyebrow_ref_eb.head + Vector((0,0,length))
								align_bone_z_axis(eyebrow_ref_eb,Vector((1*side_dir,0,0)))
								average_pos +=eyebrow_ref_eb.tail
								average_len +=1
								if getattr(limb, 'eyebrow_'+stri+'_sk_'+fside):
									sk_up=getattr(limb, 'eyebrow_'+stri+'_sk_up_'+fside)
									c_eyebrow_name= 'c_eyebrow_01_end'+suff_side if eyebidx==1 else 'c_eyebrow_'+stri_prev+suff_side
									c_eyebrow_full_name= 'c_eyebrow_full'+suff_side
									if sk_up != '':
										shape_keys_drivers[sk_up]={'exp': '(var + var_full) * '+str(head_length*400),'vars':{'var':['pose.bones["'+c_eyebrow_name+'"].location[1]', 'PROP'], 'var_full':['pose.bones["'+c_eyebrow_full_name+'"].location[1]', 'PROP']}}
									sk_down=getattr(limb, 'eyebrow_'+stri+'_sk_down_'+fside)
									if sk_down != '':
										shape_keys_drivers[sk_down]={'exp': '(-var - var_full) * '+str(head_length*400),'vars':{'var':['pose.bones["'+c_eyebrow_name+'"].location[1]', 'PROP'], 'var_full':['pose.bones["'+c_eyebrow_full_name+'"].location[1]', 'PROP']}}
						average_pos=average_pos / average_len
						eyebrow_full_ref_name= 'eyebrow_full_ref'+suff_side
						eyebrow_full_ref=get_edit_bone(eyebrow_full_ref_name)
						eyebrow_full_ref.head=average_pos + Vector((0,0,length*2))
						eyebrow_full_ref.tail=eyebrow_full_ref.head + Vector((0,0,length*2))
						align_bone_z_axis(eyebrow_full_ref,Vector((0,-1,0)))
				if limb.facial_eyes:
					for fside in ['left', 'right']:
						if fside== 'left' and not limb.facial_left or fside== 'right' and not limb.facial_right: continue
						suff_side= '.l' if fside== 'left' else '.r'
						eye_name=limb.eye_left if fside== 'left' else limb.eye_right
						if eye_name != '':
							eye_ref_name= 'eye_offset_ref.l' if fside== 'left' else 'eye_offset_ref.r'
							eye_ref=get_edit_bone(eye_ref_name)
							eye_ref.head=bones_coords[eye_ref_name]['head']
							eye_head_dist=(eye_ref.head-head_ref.head).magnitude
							eye_ref.tail=eye_ref.head + Vector((0,-eye_head_dist*0.3,0))
							align_bone_z_axis(eye_ref,Vector((0,0,1)))
							head_length=eye_head_dist * 1.5
							head_ref.tail=head_ref.head + (head_ref.tail - head_ref.head).normalized() * head_length
							side_dir= '-' if fside== 'left' else ''
							if getattr(limb, 'eye_cor_sk_'+fside):
								sk_up=getattr(limb, 'eye_cor_sk_up_'+fside)
								if sk_up != '':
									shape_keys_drivers[sk_up]={'exp': 'var * 1.5','vars': {'var':['c_eye'+suff_side, 'ROT_X']}}
								sk_down=getattr(limb, 'eye_cor_sk_down_'+fside)
								if sk_down != '':
									shape_keys_drivers[sk_down]={'exp': '-var * 1.5','vars': {'var':['c_eye'+suff_side, 'ROT_X']}}
								sk_in=getattr(limb, 'eye_cor_sk_in_'+fside)
								if sk_in != '':
									shape_keys_drivers[sk_in]={'exp': side_dir+'var * 1.5','vars': {'var': ['c_eye'+suff_side, 'ROT_Z']}}
								sk_out=getattr(limb, 'eye_cor_sk_out_'+fside)
								if sk_out != '':
									shape_keys_drivers[sk_out]={'exp': side_dir+'-var * 1.5','vars': {'var': ['c_eye'+suff_side, 'ROT_Z']}}
							if limb.facial_eyelids > 0:
								eyelids_top_ref=[]
								eyelids_bot_ref=[]
								for eyelidx in range(1,limb.facial_eyelids+1):
									stri= '%02d' % eyelidx
									eyelid_top_prop_name= 'eyelid_top_'+stri+'_'+fside
									eyelid_top=getattr(limb,eyelid_top_prop_name)
									if eyelid_top != '':
										eyelid_top_ref_name= 'eyelid_top_'+stri+'_ref'+suff_side
										eyelid_top_ref=get_edit_bone(eyelid_top_ref_name)
										eyelid_top_ref.head=eye_ref.head.copy()
										if limb.eyelids_align_engine== 'BONES':
											eyelid_top_ref.tail=bones_coords[eyelid_top_ref_name]['tail']
										elif limb.eyelids_align_engine== 'WEIGHTS':
											eyelid_top_ref.tail=eyelids_weights_centers[eyelid_top]
											eyelid_top_ref.tail=eyelid_top_ref.head + (eyelid_top_ref.tail-eyelid_top_ref.head)*1.4
										align_bone_z_axis(eyelid_top_ref,Vector((0,0,1)))
										eyelids_top_ref.append(eyelid_top_ref.name)
										if eyelidx==1:
											if getattr(limb, 'eyelid_top_sk_'+fside):
												sk_up=getattr(limb, 'eyelid_top_sk_up_'+fside)
												if sk_up != '':
													shape_keys_drivers[sk_up]={'exp': 'var * '+str(head_length*400),'vars':{'var': ['pose.bones["c_eyelid_top'+suff_side+'"].location[2]', 'PROP']}}
												sk_down=getattr(limb, 'eyelid_top_sk_down_'+fside)
												if sk_down != '':
													shape_keys_drivers[sk_down]={'exp': '-var * '+str(head_length*400),'vars': {'var':['pose.bones["c_eyelid_top'+suff_side+'"].location[2]', 'PROP']}}
									eyelid_bot_prop_name= 'eyelid_bot_'+stri+'_'+fside
									eyelid_bot=getattr(limb,eyelid_bot_prop_name)
									if eyelid_bot != '':
										eyelid_bot_ref_name= 'eyelid_bot_'+stri+'_ref'+suff_side
										eyelid_bot_ref=get_edit_bone(eyelid_bot_ref_name)
										eyelid_bot_ref.head=eye_ref.head.copy()
										if limb.eyelids_align_engine== 'BONES':
											eyelid_bot_ref.tail=bones_coords[eyelid_bot_ref_name]['tail']
										elif limb.eyelids_align_engine== 'WEIGHTS':
											eyelid_bot_ref.tail=eyelids_weights_centers[eyelid_bot]
											eyelid_bot_ref.tail=eyelid_bot_ref.head + (eyelid_bot_ref.tail-eyelid_bot_ref.head)*1.4
										align_bone_z_axis(eyelid_bot_ref,Vector((0,0,1)))
										eyelids_bot_ref.append(eyelid_bot_ref.name)
										if eyelidx==1:
											if getattr(limb, 'eyelid_bot_sk_'+fside):
												sk_up=getattr(limb, 'eyelid_bot_sk_up_'+fside)
												if sk_up != '':
													shape_keys_drivers[sk_up]={'exp': 'var * '+str(head_length*400),'vars': {'var':['pose.bones["c_eyelid_bot'+suff_side+'"].location[2]', 'PROP']}}
												sk_down=getattr(limb, 'eyelid_bot_sk_down_'+fside)
												if sk_down != '':
													shape_keys_drivers[sk_down]={'exp': '-var * '+str(head_length*400),'vars': {'var':['pose.bones["c_eyelid_bot'+suff_side+'"].location[2]', 'PROP']}}
								eyelid_top_main_ref_name= 'eyelid_top_ref'+suff_side
								eyelid_top_main=get_edit_bone(eyelid_top_main_ref_name)
								eyelid_top_main.head=eye_ref.head.copy()
								if limb.facial_eyelids==1:
									copy_bone_transforms(eyelid_top_ref,eyelid_top_main)
								elif limb.facial_eyelids==2:
									sum=Vector((0,0,0))
									for ename in eyelids_top_ref:
										sum +=get_edit_bone(ename).tail
									mid_pos=sum / len(eyelids_top_ref)
									eyelid_top_main.tail=mid_pos
								else:
									mid_eyel_bone_name=eyelids_top_ref[len(eyelids_top_ref)//2]
									mid_eyel_bone=get_edit_bone(mid_eyel_bone_name)
									copy_bone_transforms(mid_eyel_bone,eyelid_top_main)
								align_bone_z_axis(eyelid_top_main,Vector((0,0,1)))
								eyelid_bot_main_ref_name= 'eyelid_bot_ref'+suff_side
								eyelid_bot_main=get_edit_bone(eyelid_bot_main_ref_name)
								eyelid_bot_main.head=eye_ref.head.copy()
								if limb.facial_eyelids==1:
									copy_bone_transforms(eyelid_bot_ref,eyelid_bot_main)
								elif limb.facial_eyelids==2:
									sum=Vector((0,0,0))
									for ename in eyelids_bot_ref:
										sum +=get_edit_bone(ename).tail
									mid_pos=sum / len(eyelids_bot_ref)
									eyelid_bot_main.tail=mid_pos
								else:
									mid_eyel_bone_name=eyelids_bot_ref[len(eyelids_bot_ref)//2]
									mid_eyel_bone=get_edit_bone(mid_eyel_bone_name)
									copy_bone_transforms(mid_eyel_bone,eyelid_bot_main)
								align_bone_z_axis(eyelid_bot_main,Vector((0,0,1)))
								eyelid_corner_in_ref_name= 'eyelid_corner_01_ref'+suff_side
								eyelid_corner_in_ref=get_edit_bone(eyelid_corner_in_ref_name)
								eyelid_corner_in_ref.head=eye_ref.head.copy()
								eyelid_corner_in_name=getattr(limb, 'eyelid_corner_in_'+fside)
								if eyelid_corner_in_name != '':
									if limb.eyelids_align_engine== 'BONES':
										eyelid_corner_in_ref.tail=bones_coords[eyelid_corner_in_ref_name]['tail']
									elif limb.eyelids_align_engine== 'WEIGHTS':
										eyelid_corner_in_ref.tail=eyelids_weights_centers[eyelid_corner_in_name]
								else:
									forward_pos=(eyelid_bot_main.tail + eyelid_top_main.tail) * 0.5
									z_axis=(eyelid_bot_main.z_axis + eyelid_top_main.z_axis) * 0.5
									side_fac=1 if fside== 'right' else -1
									tailpos=rotate_point(forward_pos,math.radians(60),z_axis*side_fac,eye_ref.head.copy())
									eyelid_corner_in_ref.tail=tailpos
									align_bone_z_axis(eyelid_corner_in_ref,Vector((0,0,1)))
								eyelid_corner_out_ref_name= 'eyelid_corner_02_ref'+suff_side
								eyelid_corner_out_ref=get_edit_bone(eyelid_corner_out_ref_name)
								eyelid_corner_out_ref.head=eye_ref.head.copy()
								eyelid_corner_out_name=getattr(limb, 'eyelid_corner_out_'+fside)
								if eyelid_corner_out_name != '':
									if limb.eyelids_align_engine== 'BONES':
										eyelid_corner_out_ref.tail=bones_coords[eyelid_corner_out_ref_name]['tail']
									elif limb.eyelids_align_engine== 'WEIGHTS':
										eyelid_corner_out_ref.tail=eyelids_weights_centers[eyelid_corner_out_name]
								else:
									forward_pos=(eyelid_bot_main.tail + eyelid_top_main.tail) * 0.5
									z_axis=(eyelid_bot_main.z_axis + eyelid_top_main.z_axis) * 0.5
									side_fac=1 if fside== 'right' else -1
									tailpos=rotate_point(forward_pos,math.radians(60),z_axis*-side_fac,eye_ref.head.copy())
									eyelid_corner_out_ref.tail=tailpos
									align_bone_z_axis(eyelid_corner_out_ref,Vector((0,0,1)))
				if limb.facial_cheeks:
					for fside in ['left', 'right']:
						if fside== 'left' and not limb.facial_left or fside== 'right' and not limb.facial_right: continue
						suff_side= '.l' if fside== 'left' else '.r'
						side_dir=1 if fside== 'left' else -1
						cheek_name=getattr(limb, 'cheek_'+fside)
						cheek_ref_name= 'cheek_inflate_ref'+suff_side
						cheek_ref=get_edit_bone(cheek_ref_name)
						if cheek_name != '':
							cheek_ref.head=bones_coords[cheek_ref_name]['head']
							cheek_ref.tail=cheek_ref.head + Vector((0,-head_length*0.2,0))
							align_bone_z_axis(cheek_ref,Vector((-1*side_dir,0,0)))
						else:
							head_mid=head_ref.head + (head_ref.tail-head_ref.head)*0.1
							flank_pos=((head_ref.z_axis + head_ref.x_axis*side_dir) * 0.5).normalized() * head_ref.length*0.5
							cheek_ref.head=head_mid + flank_pos
							cheek_ref.tail=cheek_ref.head + Vector((0,-head_length*0.2,0))
							align_bone_z_axis(cheek_ref,Vector((-1*side_dir,0,0)))
						if getattr(limb, 'cheek_sk_'+fside):
							sk_inflate=getattr(limb, 'cheek_sk_inflate_'+fside)
							if sk_inflate != '':
								shape_keys_drivers[sk_inflate]={'exp': 'var-1','vars': {'var': ['pose.bones["c_cheek_inflate'+suff_side+'"].scale[0]', 'PROP']}}
						cheek_up_name=getattr(limb, 'cheek_smile_'+fside)
						if cheek_up_name != '':
							cheek_up_ref_name= 'cheek_smile_ref'+suff_side
							cheek_ref=get_edit_bone(cheek_up_ref_name)
							cheek_ref.head=bones_coords[cheek_up_ref_name]['head']
							cheek_ref.tail=cheek_ref.head + Vector((0,0,head_length*0.2))
							align_bone_z_axis(cheek_ref,Vector((0,-1,0)))
							if getattr(limb, 'cheek_smile_sk_'+fside):
								sk_up=getattr(limb, 'cheek_smile_sk_up_'+fside)
								if sk_up != '':
									shape_keys_drivers[sk_up]={'exp': 'var *'+str(head_length*400),'vars':{'var': ['pose.bones["c_cheek_smile'+suff_side+'"].location[1]', 'PROP']}}
								sk_down=getattr(limb, 'cheek_smile_sk_down_'+fside)
								if sk_down != '':
									shape_keys_drivers[sk_down]={'exp': '-var *'+str(head_length*400),'vars': {'var': ['pose.bones["c_cheek_smile'+suff_side+'"].location[1]', 'PROP']}}
				if limb.facial_nose:
					nose_name=getattr(limb, 'nose_root')
					if nose_name != '':
						nose_ref_name= 'nose_03_ref.x'
						nose_ref=get_edit_bone(nose_ref_name)
						nose_ref.head=bones_coords[nose_ref_name]['head']
						nose_ref.tail=nose_ref.head + Vector((0,-head_length*0.1,0))
						align_bone_z_axis(nose_ref,Vector((0,0,1)))
					nose1_name=getattr(limb, 'nose_tip1')
					if nose1_name != '':
						nose1_ref_name= 'nose_01_ref.x'
						nose1_ref=get_edit_bone(nose1_ref_name)
						nose1_ref.head=bones_coords[nose1_ref_name]['head']
						nose1_ref.tail=nose1_ref.head + Vector((0,-head_length*0.1,0))
						align_bone_z_axis(nose1_ref,Vector((0,0,1)))
					nose2_name=getattr(limb, 'nose_tip2')
					nose2_ref_name= 'nose_02_ref.x'
					nose2_ref=get_edit_bone(nose2_ref_name)
					if nose2_name != '':
						nose2_ref.head=bones_coords[nose2_ref_name]['head']
						nose2_ref.tail=nose2_ref.head + Vector((0,-head_length*0.1,0))
					else:
						copy_bone_transforms(nose1_ref,nose2_ref)
						nose2_ref.tail +=nose1_ref.tail-nose1_ref.head
						nose2_ref.head +=nose1_ref.tail-nose1_ref.head
				if limb.facial_mouth:
					lip_scale=1/400
					jaw_ref_name= 'jaw_ref'
					jaw_ref=get_edit_bone(jaw_ref_name+side)
					if limb.jaw != '':
						jaw_ref.head=bones_coords[jaw_ref_name]['head']
						jaw_ref.tail=jaw_ref.head + (Vector((0,-1,-0.6)).normalized() * head_length*0.6)
						align_bone_z_axis(jaw_ref,Vector((0,0,-1)))
					else:
						jaw_ref.head=head_ref.head.copy()
						jaw_ref.tail=jaw_ref.head + (Vector((0,-1,-0.6)).normalized() * head_length*0.6)
						align_bone_z_axis(jaw_ref,Vector((0,0,-1)))
					if limb.lips_offset:
						lips_offset_ref_name= 'lips_offset_ref'
						lips_offset_ref=get_edit_bone(lips_offset_ref_name+side)
						copy_bone_transforms(jaw_ref,lips_offset_ref)
						lips_offset_ref.tail=lips_offset_ref.head + (lips_offset_ref.tail-lips_offset_ref.head)*0.8
						if getattr(limb, 'jaw_sk'):
							jaw_sk=getattr(limb, 'jaw_sk_open')
							if jaw_sk != '':
								shape_keys_drivers[jaw_sk]={'exp': 'var * '+str(head_length*400),'vars': {'var':[ 'pose.bones["c_jawbone.x"].location[2]', 'PROP']}}
							jaw_sk_left=getattr(limb, 'jaw_sk_left')
							if jaw_sk_left != '':
								shape_keys_drivers[jaw_sk_left]={'exp': 'var * '+str(head_length*400),'vars': {'var':['pose.bones["c_jawbone.x"].location[0]', 'PROP']}}
							jaw_sk_right=getattr(limb, 'jaw_sk_right')
							if jaw_sk_right != '':
								shape_keys_drivers[jaw_sk_right]={'exp': '-var * '+str(head_length*400),'vars': {'var':['pose.bones["c_jawbone.x"].location[0]', 'PROP']}}
					if limb.lips_offset and limb.lips_offset_sk:
						sk_up=getattr(limb, 'lips_offset_sk_up')
						if sk_up != '':
							shape_keys_drivers[sk_up]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_offset.x"].location[2]', 'PROP']}}
						sk_down=getattr(limb, 'lips_offset_sk_down')
						if sk_down != '':
							shape_keys_drivers[sk_down]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_offset.x"].location[2]', 'PROP']}}
						sk_left=getattr(limb, 'lips_offset_sk_left')
						if sk_left != '':
							shape_keys_drivers[sk_left]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_offset.x"].location[0]', 'PROP']}}
						sk_right=getattr(limb, 'lips_offset_sk_right')
						if sk_right != '':
							shape_keys_drivers[sk_right]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_offset.x"].location[0]', 'PROP']}}
						sk_forward=getattr(limb, 'lips_offset_sk_forward')
						if sk_forward != '':
							shape_keys_drivers[sk_forward]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_offset.x"].location[1]', 'PROP']}}
					if limb.lips_roll_sk:
						sk_up_in=getattr(limb, 'lips_roll_sk_up_in')
						if sk_up_in != '':
							shape_keys_drivers[sk_up_in]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_roll_top.x"].location[2]', 'PROP']}}
						sk_up_out=getattr(limb, 'lips_roll_sk_up_out')
						if sk_up_out != '':
							shape_keys_drivers[sk_up_out]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_roll_top.x"].location[2]', 'PROP']}}
						sk_low_in=getattr(limb, 'lips_roll_sk_low_in')
						if sk_low_in != '':
							shape_keys_drivers[sk_low_in]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_roll_bot.x"].location[2]', 'PROP']}}
						sk_low_out=getattr(limb, 'lips_roll_sk_low_out')
						if sk_low_out != '':
							shape_keys_drivers[sk_low_out]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_roll_bot.x"].location[2]', 'PROP']}}
					if limb.lips_amount > 0:
						for lvl in ['top', 'bot']:
							mid_lvl_ref_name= 'lips_'+lvl+'_ref'
							mid_lvl_eb=get_edit_bone(mid_lvl_ref_name+side)
							mid_lvl_eb.head=bones_coords[mid_lvl_ref_name]['head']
							mid_lvl_eb.tail=mid_lvl_eb.head + Vector((0,0,max_dim * lip_scale))
							if getattr(limb, 'lip_'+lvl+'_mid_sk'):
								c_lip_name= 'c_lips_'+lvl+'.x'
								sk_up=getattr(limb, 'lip_'+lvl+'_mid_sk_up')
								if sk_up != '':
									shape_keys_drivers[sk_up]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["'+c_lip_name+'"].location[1]', 'PROP']}}
								sk_down=getattr(limb, 'lip_'+lvl+'_mid_sk_down')
								if sk_down != '':
									shape_keys_drivers[sk_down]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["'+c_lip_name+'"].location[1]', 'PROP']}}
							lips_roll_ref_name= 'lips_roll_'+lvl+'_ref.x'
							lips_roll_ref=get_edit_bone(lips_roll_ref_name)
							dir_fac=1 if lvl== 'top' else -1
							start_pos=mid_lvl_eb.tail if lvl== 'top' else mid_lvl_eb.head
							lips_roll_ref.head=start_pos + (mid_lvl_eb.x_axis.normalized() * mid_lvl_eb.length*2) + ((mid_lvl_eb.tail-mid_lvl_eb.head) * 2 )* dir_fac
							lips_roll_ref.tail=lips_roll_ref.head + Vector((0,-max_dim * lip_scale,0))
							align_bone_z_axis(lips_roll_ref,Vector((0,0,1*dir_fac)))
						for fside in ['left', 'right']:
							suff_side= '.l' if fside== 'left' else '.r'
							side_dir=1 if fside== 'left' else -1
							lips_corner_ref_name= 'lips_smile_ref'+suff_side
							lips_corner_ref=get_edit_bone(lips_corner_ref_name)
							lips_corner_ref.head=bones_coords[lips_corner_ref_name]['head']
							lips_corner_ref.tail=lips_corner_ref.head + Vector((0,0,max_dim * lip_scale))
							align_bone_x_axis(lips_corner_ref,Vector((0,-1*side_dir,0)))
							lips_corner_mini_ref_name= 'lips_corner_mini_ref'+suff_side
							lips_corner_mni_ref=get_edit_bone(lips_corner_mini_ref_name)
							copy_bone_transforms(lips_corner_ref,lips_corner_mni_ref)
							lips_corner_mni_ref.tail=lips_corner_mni_ref.head + (lips_corner_mni_ref.tail-lips_corner_mni_ref.head)*0.5
							if getattr(limb, 'lip_corner_'+fside+'_sk'):
								sk_corner_out=getattr(limb, 'lip_corner_'+fside+'_sk_out')
								if sk_corner_out != '':
									shape_keys_drivers[sk_corner_out]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_smile'+suff_side+'"].location[2]', 'PROP']}}
								sk_corner_in=getattr(limb, 'lip_corner_'+fside+'_sk_in')
								if sk_corner_in != '':
									shape_keys_drivers[sk_corner_in]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_smile'+suff_side+'"].location[2]', 'PROP']}}
								sk_corner_up=getattr(limb, 'lip_corner_'+fside+'_sk_up')
								if sk_corner_up != '':
									shape_keys_drivers[sk_corner_up]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_smile'+suff_side+'"].location[1]', 'PROP']}}
								sk_corner_down=getattr(limb, 'lip_corner_'+fside+'_sk_down')
								if sk_corner_down != '':
									shape_keys_drivers[sk_corner_down]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["c_lips_smile'+suff_side+'"].location[1]', 'PROP']}}
							for lipidx in range(1,limb.lips_amount+1):
								stri= '%02d' % lipidx
								stri_prev= '%02d' % (lipidx-1)
								for lvl in ['top', 'bot']:
									lip_prop_name= 'lip_'+lvl+'_'+stri+'_'+fside
									lip_name=getattr(limb,lip_prop_name)
									if lip_name != '':
										lip_ref_name= 'lips_'+lvl+'_ref'+suff_side if lipidx==1 else 'lips_'+lvl+'_'+stri_prev+'_ref'+suff_side
										lip_ref_eb=get_edit_bone(lip_ref_name)
										lip_ref_eb.head=bones_coords[lip_ref_name]['head']
										lip_ref_eb.tail=lip_ref_eb.head + Vector((0,0,max_dim * lip_scale))
										align_bone_x_axis(lips_corner_ref,Vector((0,-1*side_dir,0)))
										if getattr(limb, 'lip_'+lvl+'_'+stri+'_sk_'+fside):
											c_lip_name= 'c_lips_'+lvl+suff_side if lipidx==1 else 'c_lips_'+lvl+'_'+stri_prev+suff_side
											sk_up=getattr(limb, 'lip_'+lvl+'_'+stri+'_sk_up_'+fside)
											if sk_up != '':
												shape_keys_drivers[sk_up]={'exp': 'var * '+str(head_length*400),'vars':{'var':['pose.bones["'+c_lip_name+'"].location[1]', 'PROP']}}
											sk_down=getattr(limb, 'lip_'+lvl+'_'+stri+'_sk_down_'+fside)
											if sk_down != '':
												shape_keys_drivers[sk_down]={'exp': '-var * '+str(head_length*400),'vars':{'var':['pose.bones["'+c_lip_name+'"].location[1]', 'PROP']}}
					if limb.tongues_amount > 0:
						prev_tongue=None
						for i in range(1,limb.tongues_amount+1):
							stri= '%02d' % i
							tongue_ref_name= 'tong_'+stri+'_ref.x'
							tongue_ref=get_edit_bone(tongue_ref_name)
							if tongue_ref_name in bones_coords:
								tongue_ref.head=bones_coords[tongue_ref_name]['head']
								if prev_tongue:
									prev_tongue.tail=tongue_ref.head.copy()
									tongue_ref.tail=tongue_ref.head + (prev_tongue.tail-prev_tongue.head)
								else:
									tongue_ref.tail=tongue_ref.head + (Vector((0,-1,0)).normalized() * head_length*0.1)
								align_bone_z_axis(tongue_ref,Vector((0,0,1)))
							else:
								tongue_ref.head=prev_tongue.tail.copy()
								tongue_ref.tail=tongue_ref.head + (prev_tongue.tail-prev_tongue.head)*0.5
								align_bone_z_axis(tongue_ref,prev_tongue.z_axis)
							prev_tongue=tongue_ref
					if limb.facial_teeth:
						for lvl in ['top', 'bot']:
							teeth_mid_name=getattr(limb, 'teeth_'+lvl+'_mid')
							if teeth_mid_name != '':
								teeth_ref_name= 'teeth_'+lvl+'_ref.x'
								teeth_ref_mid=get_edit_bone(teeth_ref_name)
								teeth_ref_mid.head=bones_coords[teeth_ref_name]['head']
								teeth_ref_mid.tail=teeth_ref_mid.head + Vector((0,-max_dim * lip_scale*2,0))
								align_bone_z_axis(teeth_ref_mid,Vector((0,0,1)))
							for fside in ['left', 'right']:
								if fside== 'left' and not limb.facial_left or fside== 'right' and not limb.facial_right: continue
								suff_side= '.l' if fside== 'left' else '.r'
								teeth_side_name=getattr(limb, 'teeth_'+lvl+'_'+fside)
								teeth_ref_name= 'teeth_'+lvl+'_ref'+suff_side
								teeth_ref_side=get_edit_bone(teeth_ref_name)
								if teeth_side_name != '':
									teeth_ref_side.head=bones_coords[teeth_ref_name]['head']
									teeth_ref_side.tail=bones_coords[teeth_ref_name]['tail']
								else:
									if teeth_mid_name != '':
										side_dir=1 if fside== 'right' else -1
										teeth_ref_side.head=teeth_ref_mid.head + teeth_ref_mid.x_axis.normalized()*side_dir * (teeth_ref_mid.tail - teeth_ref_mid.head).magnitude
										teeth_ref_side.tail=teeth_ref_side.head + (teeth_ref_mid.tail - teeth_ref_mid.head)
								align_bone_z_axis(teeth_ref_side,Vector((0,0,1)))
				if limb.facial_chin:
					last_chin= ''
					for i in range(1,3):
						stri= '%02d' % i
						chin_ref_name= 'chin_'+stri+'_ref.x'
						chin_ref=get_edit_bone(chin_ref_name)
						if chin_ref_name in bones_coords:
							chin_ref.head=bones_coords[chin_ref_name]['head']
							chin_ref.tail=chin_ref.head + (Vector((0,-1,0)) * 1/200 * max_dim)
						else:
							chin_ref.head=bones_coords[last_chin]['head'] + (Vector((0,0,-1)) * 1/200 * max_dim)
							chin_ref.tail=chin_ref.head + (Vector((0,-1,0)) * 1/200 * max_dim)
						align_bone_z_axis(chin_ref,Vector((0,0,1)))
						last_chin=chin_ref_name
		elif limb.type== 'TAIL':
			side= '.x'
			if limb.side== 'LEFT':
				side= '.l'
			elif limb.side== 'RIGHT':
				side= '.r'
			dupli_idx= ''
			for bone_ref_name in bones_coords:
				if "_dupli_" in bone_ref_name:
					dupli_idx= "_dupli_"+str(bone_ref_name[-3:])
				break
			limb.dupli_idx=dupli_idx
			for idx in range(0,len(bones_coords)):
				bones_coords_keys=list(bones_coords.keys())
				ref_name_no_side=bones_coords_keys[idx]
				tail_ref_name=ref_name_no_side+side
				tail_ref=get_edit_bone(tail_ref_name)
				tail_ref_prev=None
				if idx > 0:
					tail_prev_name=bones_coords_keys[idx-1]+side
					tail_ref_prev=get_edit_bone(tail_prev_name)
				else:
					bone_parent_name=bones_coords["tail_00_ref"+dupli_idx]['parent_name']
					bone_parent_match_name=get_source_ref_match("SPINE",bone_parent_name)
					print("  Tail parent:",bone_parent_name, ">",bone_parent_match_name)
					if bone_parent_match_name:
						tail_ref.parent=get_edit_bone(bone_parent_match_name)
				tail_ref.head=bones_coords[ref_name_no_side]['head']
				if limb.connect and tail_ref_prev:
					tail_ref.tail=tail_ref.head + (tail_ref_prev.tail - tail_ref_prev.head)
				else:
					bone_primary_axis=get_bone_primary_axis(limb.primary_axis,bones_coords,ref_name_no_side)
					tail_ref_length=1.0
					if tail_ref_prev:
						tail_ref_length=(tail_ref_prev.tail - tail_ref_prev.head).magnitude
					else:
						tail_next_name=bones_coords_keys[idx+1]+side
						tail_next=get_edit_bone(tail_next_name)
						tail_ref_length=(tail_next.head - tail_ref.head).magnitude
					tail_ref.tail=tail_ref.head + (bone_primary_axis.normalized() * tail_ref_length)
			target_axis=None
			for idx,ref_name_no_side in enumerate(bones_coords):
				if ref_name_no_side != "":
					str_idx= '%02d' % idx
					prev_str_idx= '%02d' % (idx-1)
					tail_ref_name=ref_name_no_side+side
					tail_ref=get_edit_bone(tail_ref_name)
					if target_axis==None:
						angle_x=get_short_angle(tail_ref.z_axis,bones_coords[ref_name_no_side]['x_axis'])
						angle_y=get_short_angle(tail_ref.z_axis,bones_coords[ref_name_no_side]['y_axis'])
						angle_z=get_short_angle(tail_ref.z_axis,bones_coords[ref_name_no_side]['z_axis'])
						if angle_x < angle_y and angle_x < angle_z:
							target_axis= 'x_axis'
						if angle_y < angle_x and angle_y < angle_z:
							target_axis= 'y_axis'
						if angle_z < angle_x and angle_z < angle_y:
							target_axis= 'z_axis'
						print('Tail target axis',target_axis)
					align_bone_z_axis(tail_ref,bones_coords[ref_name_no_side][target_axis])
	for ebone in arp_armature.data.edit_bones:
		if not is_bone_in_layer(ebone.name, 'Reference',idx=17):
			continue
		if len(ebone.children):
			continue
		bparent=ebone.parent
		if bparent:
			ebone_length=(ebone.tail-ebone.head).magnitude
			bparent_length=(bparent.tail-bparent.head).magnitude
			if ebone_length < bparent_length/20:
				ebone.tail=ebone.head + (ebone.tail-ebone.head).normalized() * bparent_length
	bot=float('inf')
	top=-float('inf')
	top_tail=-float('inf')
	for b in arp_armature.data.edit_bones:
		if not is_bone_in_layer(b.name, 'Reference',idx=17):
			continue
		if b.head[2] < bot:
			bot=b.head[2]
		if b.head[2] > top:
			top=b.head[2]
		if b.tail[2] > top_tail:
			top_tail=b.tail[2]
	height=top - bot
	if round(height,3)==0.0:
		height=top_tail - bot
	print('Armature height:',height)
	root_ref=get_edit_bone('root_ref.x')
	c_root_master_scale_fac=1.0
	if root_ref:
		length=(root_ref.tail - root_ref.head).magnitude
		print('length',length)
		ratio=length/height
		c_root_master_scale_fac=1 / (ratio/0.06)
	bpy.ops.object.mode_set(mode='POSE')
	if c_root_master_scale_fac !=1.0:
		c_root_master=get_pose_bone('c_root_master.x')
		set_custom_shape_scale(c_root_master,c_root_master_scale_fac)
	if len(self.orphan_bones_dict) and self.orphan_copy_cns:
		print("复制孤立骨骼ChildOf约束")
		enable_layer(self.orphan_bones_collection,idx=self.orphan_bones_layer)
		for or_name in self.orphan_bones_dict:
			orphan_pbone=get_pose_bone(or_name)
			if orphan_pbone==None:
				continue
			if not 'constraints' in self.orphan_bones_dict[or_name]:
				continue
			cns_multi_dict=self.orphan_bones_dict[or_name]['constraints']
			pose_bone_constraints_from_dict(arp_armature,orphan_pbone,cns_multi_dict)
		print('  集合反转矩阵')
		set_childof_inverse(self)
	if len(self.orphan_bones_dict):
		if bpy.app.version < (4,0,0):
			group_name= "Custom Controllers"
			group=arp_armature.pose.bone_groups.get(group_name)
			if group==None:
				group=arp_armature.pose.bone_groups.new(name=group_name)
				group.color_set= "CUSTOM"
			group.colors.normal=self.color_orphan_group
			for i,channel in enumerate(group.colors.select):
				group.colors.select[i]=self.color_orphan_group[i] + 0.4
			for i,channel in enumerate(group.colors.active):
				group.colors.active[i]=self.color_orphan_group[i] + 0.5
		if self.orphan_bones_shape != 'None':
			for or_name in self.orphan_bones_dict:
				orphan_pbone=get_pose_bone(or_name)
				if orphan_pbone==None:
					print("Warning,orphan bone not found:",or_name)
				if bpy.app.version >=(4,0,0):
					normal_color=self.color_orphan_group
					sel_color=[i+0.4 for i in normal_color]
					active_color=[i+0.6 for i in normal_color]
					set_bone_color(orphan_pbone.bone,[normal_color,sel_color,active_color])
				else:
					orphan_pbone.bone_group=group
				orphan_pbone.custom_shape=get_object(self.orphan_bones_shape)
				if orphan_pbone.custom_shape:
					set_custom_shape_scale(orphan_pbone,self.orphan_bones_scale)
				orphan_pbone["cc"]=1
				orphan_pbone.bone["cc"]=1
	for pbone in arp_armature.pose.bones:
		if pbone.name.startswith("c_shoulder"):
			pbone.custom_shape_transform=None
	if self.neck_auto_twist:
		for limb_item in scn.limb_map:
			if limb_item.type== "HEAD":
				side= ".x"
				for i in range(2,limb_item.neck_bones_amount+1):
					subneck=get_pose_bone("c_subneck_"+str(i-1)+side)
					if subneck:
						subneck["neck_twist"]=1.0
	bpy.ops.object.mode_set(mode='EDIT')
	for obj in bpy.data.objects:
		if obj.type != 'MESH':
			continue
		if len(obj.modifiers):
			for mod in obj.modifiers:
				if mod.type != 'ARMATURE':
					continue
				if mod.object==source_skeleton:
					if self.mode== 'CONVERT':
						mod.object=arp_armature
					mod.use_deform_preserve_volume=self.preserve_volume
	if self.mode== 'PRESERVE':
		bpy.ops.object.mode_set(mode='OBJECT')
		bpy.ops.object.select_all(action='DESELECT')
		set_active_object(source_skeleton.name)
		bpy.ops.object.mode_set(mode='POSE')
		for pbone in source_skeleton.pose.bones:
			bone_qr_offset_name=pbone.name+'_qr_offset'
			bone_qr_offset=arp_armature.data.bones.get(bone_qr_offset_name)
			if bone_qr_offset:
				cns=pbone.constraints.new('COPY_TRANSFORMS')
				cns.name= 'CopyTransforms_QR'
				cns.target=arp_armature
				cns.subtarget=bone_qr_offset_name
				cns2=pbone.constraints.new('COPY_SCALE')
				cns2.name= 'CopyScale_QR'
				cns2.target=arp_armature
				cns2.subtarget=bone_qr_offset_name
				cns2.target_space=cns2.owner_space= 'POSE'
		for or_name in orphan_bones:
			or_pbone=source_skeleton.pose.bones.get(or_name)
			cor_bone=arp_armature.data.bones.get(or_name)
			if cor_bone==None:
				cor_bone=arp_armature.data.bones.get('cor_'+or_name)
			if or_pbone and cor_bone:
				cns=or_pbone.constraints.get('CopyTransforms_QR')
				if cns==None:
					cns=or_pbone.constraints.new('COPY_TRANSFORMS')
					cns.name= 'CopyTransforms_QR'
					cns.target=arp_armature
					cns.subtarget=cor_bone.name
				cns2=or_pbone.constraints.get('CopyScale_QR')
				if cns2==None:
					cns2=or_pbone.constraints.new('COPY_SCALE')
					cns2.name= 'CopyScale_QR'
					cns2.target=arp_armature
					cns2.subtarget=cor_bone.name
					cns2.target_space=cns2.owner_space= 'POSE'
		bpy.ops.object.mode_set(mode='OBJECT')
		bpy.ops.object.select_all(action='DESELECT')
		set_active_object(arp_armature.name)
		arp_armature.data["arp_locked"]=True
	if self.mode== 'CONVERT':
		create_groups=[]
		for obj in skinned_objects:
			if len(obj.vertex_groups):
				for vgroup in obj.vertex_groups:
					if vgroup.name in skin_dict:
						new_name=skin_dict[vgroup.name]['deform']
						create_groups.append(new_name)
						new_grp=obj.vertex_groups.get(new_name)
						if new_grp !=None:
							new_grp.name=new_name+"_OLDGROUP"
						if new_name in skin_dict:
							skin_dict[new_name+"_OLDGROUP"]=skin_dict[new_name]
							del skin_dict[new_name]
						vgroup.name=new_name
		for n in skin_dict.copy():
			if n.endswith("_OLDGROUP"):
				skin_dict[n.replace("_OLDGROUP", "")]=skin_dict[n]
				del skin_dict[n]
	skinned_objects_dict={}
	meshes_transf_dict={}
	for obj in skinned_objects:
		skinned_objects_dict[obj.name]={}
		meshes_transf_dict[obj.name]=obj.location,obj.rotation_euler,obj.rotation_quaternion,obj.scale
	def save_driver(dr,dict):
		var_save={}
		for var in dr.driver.variables:
			ids=[]
			bone_targets=[]
			tspaces=[]
			for tar in var.targets:
				if tar.id !=None:
					try: ids.append(tar.id.name)
					except: pass
				if tar.bone_target != '':
					bone_targets.append(tar.bone_target)
				tspaces.append(tar.transform_space)
			var_save[var.name]={'type':var.type, 'ids':ids, 'bone_targets':bone_targets, 'tspaces': tspaces}
		dict[dr.data_path]=[dr.driver.type,dr.driver.expression,var_save]
		return dict
	for obj in skinned_objects:
		drivers_save={}
		sk=obj.data.shape_keys
		if sk==None: continue
		anim_data=obj.data.shape_keys.animation_data
		if anim_data==None: continue
		drivers=anim_data.drivers
		if drivers==None: continue
		sk_drivers_done=[]
		for shape_key_name in shape_keys_drivers:
			exp=shape_keys_drivers[shape_key_name]['exp']
			dp= 'key_blocks["'+shape_key_name+'"].value'
			dr=drivers.find(dp)
			if dr==None:
				shape_index=get_shape_key_index(shape_key_name,sk.key_blocks)
				if shape_index==None: continue
				dr=sk.key_blocks[shape_index].driver_add('value')
			else:
				drivers_save=save_driver(dr,drivers_save)
			for vari,var_name in enumerate(shape_keys_drivers[shape_key_name]['vars']):
				var=dr.driver.variables[vari] if len(dr.driver.variables)-1 >=vari else None
				if var==None:
					var=dr.driver.variables.new()
				prop_dp,var_type=shape_keys_drivers[shape_key_name]['vars'][var_name]
				if var_type== 'PROP':
					var.type= 'SINGLE_PROP'
					var.targets[0].data_path=prop_dp
				else:
					var.type= 'TRANSFORMS'
					var.targets[0].transform_space= 'LOCAL_SPACE'
					var.targets[0].transform_type=var_type
					var.targets[0].bone_target=prop_dp
				var.name=var_name
				print('var',var.name,var.type, 'object',obj.name, 'shape_key_name',shape_key_name)
				var.targets[0].id=arp_armature
				dr.driver.expression=exp
			sk_drivers_done.append(dp)
		if (len(self.orphan_bones_dict) and self.retarget_sk_drivers):
			print('重定位形态键驱动程序...')
			for fc_driver in drivers:
				dr=fc_driver.driver
				if fc_driver.data_path in sk_drivers_done: continue
				drivers_save=save_driver(fc_driver,drivers_save)
				for var in dr.variables:
					for i,tar in enumerate(var.targets):
						if tar.id==source_skeleton:
							tar.id=arp_armature
						if tar.bone_target != '':
							for or_name in self.orphan_bones_dict:
								if self.orphan_bones_dict[or_name]['original_name']==tar.bone_target:
									tar.bone_target=or_name
									break
		skinned_objects_dict[obj.name]=drivers_save
	arp_qr_data={'skinned_objects': skinned_objects_dict, 'vgroups': skin_dict, 'base_armature': source_skeleton.name, 'meshes_parented_to_bones': self.meshes_parented_to_bones, 'meshes_transf': meshes_transf_dict,}
	arp_armature.data['arp_qr_data']=arp_qr_data
	if self.mode== 'CONVERT':
		bpy.ops.object.mode_set(mode='POSE')
		arm_col=arp_armature.users_collection[0]
		master_rig_col=bpy.data.collections.get(arm_col.name[:-4])# trim '_rig'
		if master_rig_col:
			for obj in skinned_objects:
				try:
					master_rig_col.objects.link(obj)
				except:
					pass
			for obj_name in self.meshes_parented_to_bones:
				o=get_object(obj_name)
				try:
					master_rig_col.objects.link(o)
				except:
					pass
		else:
			print("找不到绑定集合，无法在中设置对象")
		bpy.ops.object.mode_set(mode='EDIT')
	self.skin_dict=skin_dict
def get_bone_primary_axis(primary_axis,bones_coords,bone_name):
	if primary_axis== "X":
		return bones_coords[bone_name]['x_axis']
	elif primary_axis== "-X":
		return -bones_coords[bone_name]['x_axis']
	elif primary_axis== "Y":
		return bones_coords[bone_name]['y_axis']
	elif primary_axis== "-Y":
		return -bones_coords[bone_name]['y_axis']
	elif primary_axis== "Z":
		return bones_coords[bone_name]['z_axis']
	elif primary_axis== "-Z":
		return -bones_coords[bone_name]['z_axis']
	else:
		print('Invalid primary_axis given:',primary_axis)
		return None
def _pick_bone(self):
	current_mode=get_current_mode()
	scn=bpy.context.scene
	bpy.ops.object.mode_set(mode='EDIT')
	rig=get_object(bpy.context.active_object.name)
	xmirror_state=rig.data.use_mirror_x
	rig.data.use_mirror_x=False
	valid=True
	if len(bpy.context.selected_editable_bones)==0:
		GR(self,'ERROR', "No bone selected: select a bone.")
		valid=False
	if valid:
		selected_bone_name=bpy.context.selected_editable_bones[0].name
		setattr(scn.limb_map[scn.limb_map_index],self.value,selected_bone_name)
	restore_current_mode(current_mode)
	rig.data.use_mirror_x=xmirror_state
def get_mirror_side(side_word,sides_dict):
	mirror_word=None
	for dict_word in sides_dict:
		if dict_word==side_word:
			mirror_word=sides_dict[dict_word]
		if dict_word.upper()==side_word:
			mirror_word=sides_dict[dict_word].upper()
		if dict_word.title()==side_word:
			mirror_word=sides_dict[dict_word].title()
	return mirror_word
def get_side_dict():
	sides_dict={'l': 'r', 'left': 'right'}
	reverse_dict={}
	for i in sides_dict:
		reverse_dict[sides_dict[i]]=i
	sides_dict.update(reverse_dict)
	return sides_dict
def get_mirror_name_separator(val,sides_dict):
	for sep in ['.', '_', ' ']:
		split=val.split(sep)
		suff=split[len(split)-1]
		mirror_word=get_mirror_side(suff,sides_dict)
		if mirror_word:
			val=val[:-len(suff)]+mirror_word
			break
		pref=split[0]
		mirror_word=get_mirror_side(pref,sides_dict)
		if mirror_word:
			val=mirror_word + val[len(pref):]
			break
		for wordi,word in enumerate(split):
			mirror_word=get_mirror_side(word,sides_dict)
			if mirror_word:
				val= ''
				for _i,_word in enumerate(split):
					val +=_word if _i !=wordi else mirror_word
					if _i !=len(split)-1:
					  val +=sep
	return val
def get_mirror_name_nested(val,sides_dict,check_list=None):
	for _si in sides_dict:
		if val.lower().startswith(_si):
			prefix=val[:len(_si)]
			mirror_word=get_mirror_side(prefix,sides_dict)
			valmirror=mirror_word + val[len(_si):]
			if check_list !=None:
				if valmirror in check_list:
					val=valmirror
					break
			else:
				val=valmirror
				break
		elif val.lower().endswith(_si):
			suffix=val[-len(_si):]
			mirror_word=get_mirror_side(suffix,sides_dict)
			valmirror=val[:-len(_si)] + mirror_word
			if check_list !=None:
				if valmirror in check_list:
					val=valmirror
					break
			else:
				val=valmirror
				break
	return val
def _mirror_facial(self):
	scn=bpy.context.scene
	head_limb=scn.limb_map[scn.limb_map_index]
	rig=bpy.context.active_object
	skinned_meshes=[]
	for obj in bpy.data.objects:
		if obj.type != 'MESH': continue
		for mod in obj.modifiers:
			if mod.type != 'ARMATURE': continue
			if mod.object==rig:
				skinned_meshes.append(obj.name)
	shape_keys_list=[]
	for objname in skinned_meshes:
		if get_object(objname).data.shape_keys==None: continue
		for sk in get_object(objname).data.shape_keys.key_blocks:
			shape_keys_list.append(sk.name)
	_bone_names=[b.name for b in rig.data.bones]
	for prop_name in dir(head_limb):
		if not prop_name.startswith(('eye_', 'eyelid_', 'eyebrow_', 'cheek_', 'jaw_sk_', 'lips_', 'lip_', 'teeth_')):
			continue
		if not '_left' in prop_name and not '_right' in prop_name:
			continue
		sides_dict=get_side_dict()
		val=getattr(head_limb,prop_name)
		prop_mirror=get_mirror_name_separator(prop_name,sides_dict)
		if isinstance(val,bool):
			setattr(head_limb,prop_mirror,val)
			continue
		if type(val) !=str: continue
		if getattr(head_limb,prop_mirror) != '':
			continue
		val_mirror=get_mirror_name_separator(val,sides_dict)
		if val_mirror==val:
			checklist=None
			if '_sk_' in prop_name or prop_name.endswith('_sk'):
				checklist=shape_keys_list
			else:
				checklist=_bone_names
			val_mirror=get_mirror_name_nested(val,sides_dict,check_list=checklist)
		if val_mirror==val:
			continue
		if '_sk_' in prop_name or prop_name.endswith('_sk'):
			setattr(head_limb,prop_mirror,val_mirror)
		elif rig.data.bones.get(val):
			if rig.data.bones.get(val_mirror):
				setattr(head_limb,prop_mirror,val_mirror)
		print("Set mirror:",prop_name,val_mirror)
def _mirror_limb(self):
	scn=bpy.context.scene
	limb=scn.limb_map[scn.limb_map_index]
	rig=bpy.context.active_object
	if not limb.side in ['LEFT', 'RIGHT']:
		GR(self,'ERROR', 'This is not a left or right limb,cannot be mirrored')
		return
	print(limb.name)
	print(limb.side)
	mirror_side= 'RIGHT' if limb.side== 'LEFT' else 'LEFT'
	mirror_limb=None
	print('Look for mirror limb',mirror_side,limb.type)
	for l in scn.limb_map:
		if limb.type==l.type and l.side==mirror_side:
			print('Found mirror',l.name)
			if '_dupli_' in limb.name:
				if get_bone_side(limb.name)==get_bone_side(l.name):
					mirror_limb=l
					break
			mirror_limb=l
			break
	_bone_names=[b.name for b in rig.data.bones]
	if mirror_limb: print('Mirror limb found:',mirror_limb.name)
	else:
		cur_side=get_bone_side(limb.name)
		mirror_side_name=cur_side[:-2]+'.l' if cur_side.endswith('.r') else cur_side[:-2]+'.r'
		mirror_limb_name=get_bone_base_name(limb.name)+mirror_side_name
		mirror_limb=scn.limb_map.add()
		mirror_limb.name=mirror_limb_name
		mirror_limb.side=mirror_side
		mirror_limb.type=limb.type
	for prop_name in dir(limb):
		invalid_prop=False
		if prop_name in ['name', 'side']:
			invalid_prop=True
		for i in ['__', 'rna_', 'bl_rna']:
			if prop_name.startswith(i):
				invalid_prop=True
		if invalid_prop:
			continue
		val=getattr(limb,prop_name)
		sides_dict=get_side_dict()
		if type(val)==str:
			if rig.data.bones.get(val):
				val_mirror=get_mirror_name_separator(val,sides_dict)
				if val_mirror==val:
					val_mirror=get_mirror_name_nested(val,sides_dict,check_list=_bone_names)
				if rig.data.bones.get(val_mirror):
					setattr(mirror_limb,prop_name,val_mirror)
				else:
					self.mirrors_not_found.append(val_mirror)
			else:
				setattr(mirror_limb,prop_name,val)
		else:
			setattr(mirror_limb,prop_name,val)
	current_mode=get_current_mode()
	bpy.ops.object.mode_set(mode='EDIT')
	if mirror_limb.type== "ARM":
		hand_bone=get_edit_bone(mirror_limb.bone_06)
		arm_bone=get_edit_bone(mirror_limb.bone_02)
		if hand_bone and arm_bone:
			evaluate_hand_up_axis(mirror_limb,hand_bone,arm_bone)
			evaluate_arm_up_axis(mirror_limb,hand_bone,arm_bone)
	elif mirror_limb.type== "LEG":
		foot_bone=get_edit_bone(mirror_limb.bone_05)
		if foot_bone:
			evaluate_foot_up_axis(mirror_limb,foot_bone)
	restore_current_mode(current_mode)
	mirror_index=0
	for i in range(0,len(scn.limb_map)):
		if scn.limb_map[i]==mirror_limb:
			mirror_index=i
			break
	try:
		scn.limb_map.move(mirror_index,scn.limb_map_index+1)
	except:
		pass
def evaluate_foot_up_axis(limb,foot_bone):
	print("评估脚上轴")
	rig=bpy.context.active_object
	vec_in=rig.matrix_world @ foot_bone.head.copy()
	vec_out=vec_in + (rig.matrix_world @ foot_bone.x_axis * 10)
	x_z_vec=(vec_out[2] - vec_in[2])
	vec_out=vec_in + (rig.matrix_world @ foot_bone.z_axis * 10)
	z_z_vec=(vec_out[2] - vec_in[2])
	up_axis=x_z_vec if abs(x_z_vec) > abs(z_z_vec) else z_z_vec
	up_axis_string= "X" if up_axis==x_z_vec else "Z"
	if up_axis < 0:
		up_axis_string= "-"+up_axis_string
	limb.up_axis=up_axis_string
def evaluate_arm_up_axis(limb,hand_bone,arm_bone):
	print("评估arm_up_axis")
	rig=bpy.context.active_object
	world_x=Vector((1,0,0))
	hand_pos=rig.matrix_world @ hand_bone.head
	arm_pos=rig.matrix_world @ arm_bone.head
	if hand_pos[0] < arm_pos[0]:
		world_x *=-1
	world_y=Vector((0,1,0))
	arm_dir_vec=hand_pos - arm_pos
	arm_dir_proj_y=project_vec_onto_plane(arm_dir_vec,world_y)
	angle=signed_angle(arm_dir_proj_y,world_x,world_y)
	print('Arm Angle:',math.degrees(angle))
	vec_in=arm_pos
	x_axis_tpose=rotate_vec_mat(rig.matrix_world @ arm_bone.x_axis,angle,Vector((0,0,0)),world_y)
	vec_out=vec_in + (x_axis_tpose*10)
	x_z_vec=vec_out[2] - vec_in[2]
	y_axis_tpose=rotate_vec_mat(rig.matrix_world @ arm_bone.y_axis,angle,Vector((0,0,0)),world_y)
	vec_out=vec_in + (y_axis_tpose*10)
	y_z_vec=vec_out[2] - vec_in[2]
	z_axis_tpose=rotate_vec_mat(rig.matrix_world @ arm_bone.z_axis,angle,Vector((0,0,0)),world_y)
	vec_out=vec_in + (z_axis_tpose*10)
	z_z_vec=vec_out[2] - vec_in[2]
	up_axis_dict={abs(x_z_vec): ["X",x_z_vec],abs(y_z_vec): ["Y",y_z_vec],abs(z_z_vec):["Z",z_z_vec]}
	longer_dist=sorted([abs(x_z_vec),abs(y_z_vec),abs(z_z_vec)],reverse=True)[0]
	up_axis_string=up_axis_dict[longer_dist][0]
	up_axis_value=up_axis_dict[longer_dist][1]
	if up_axis_value < 0:
		up_axis_string= "-"+up_axis_string
	limb.up_axis_arm=up_axis_string
def evaluate_hand_up_axis(limb,hand_bone,arm_bone):
	print("评估_处理_向上_轴")
	rig=bpy.context.active_object
	world_x=Vector((1,0,0))
	hand_pos=rig.matrix_world @ (hand_bone.head)
	arm_pos=rig.matrix_world @ (arm_bone.head)
	if hand_pos[0] < arm_pos[0]:
		world_x *=-1
	world_y=Vector((0,1,0))
	arm_dir_vec=hand_pos - arm_pos
	arm_dir_proj_y=project_vec_onto_plane(arm_dir_vec,world_y)
	angle=signed_angle(arm_dir_proj_y,world_x,world_y)
	print('Arm Angle:',math.degrees(angle))
	vec_in=rig.matrix_world @ hand_bone.head.copy()
	x_axis_tpose=rotate_vec_mat(rig.matrix_world @ hand_bone.x_axis,angle,Vector((0,0,0)),world_y)
	vec_out=vec_in + (x_axis_tpose*10)
	x_z_vec=vec_out[2] - vec_in[2]
	y_axis_tpose=rotate_vec_mat(rig.matrix_world @ hand_bone.y_axis,angle,Vector((0,0,0)),world_y)
	vec_out=vec_in + (y_axis_tpose*10)
	y_z_vec=vec_out[2] - vec_in[2]
	z_axis_tpose=rotate_vec_mat(rig.matrix_world @ hand_bone.z_axis,angle,Vector((0,0,0)),world_y)
	vec_out=vec_in + (z_axis_tpose*10)
	z_z_vec=vec_out[2] - vec_in[2]
	up_axis_dict={abs(x_z_vec): ["X",x_z_vec],abs(y_z_vec): ["Y",y_z_vec],abs(z_z_vec):["Z",z_z_vec]}
	longer_dist=sorted([abs(x_z_vec),abs(y_z_vec),abs(z_z_vec)],reverse=True)[0]
	up_axis_string=up_axis_dict[longer_dist][0]
	up_axis_value=up_axis_dict[longer_dist][1]
	if up_axis_value < 0:
		up_axis_string= "-"+up_axis_string
	limb.up_axis=up_axis_string
def _add_limb(self):
	input_type=self.type
	current_mode=get_current_mode()
	scn=bpy.context.scene
	bpy.ops.object.mode_set(mode='EDIT')
	rig=get_object(bpy.context.active_object.name)
	xmirror_state=rig.data.use_mirror_x
	rig.data.use_mirror_x=False
	new_item=scn.limb_map.add()
	new_item.name=input_type.title()
	new_item.type=input_type
	scn.limb_map_index=len(scn.limb_map)-1
	if len(bpy.context.selected_editable_bones):
		active_bone=bpy.context.selected_editable_bones[0]
		if input_type== "LEG":
			thigh_bone=active_bone
			thigh_twist_bone=None
			thigh_twist2_bone=None
			thigh_twist3_bone=None
			thigh_twist4_bone=None
			thigh_twist5_bone=None
			thigh_twist6_bone=None
			thigh_twist7_bone=None
			thigh_twist_count=0
			calf_bone=None
			calf_twist_bone=None
			calf_twist2_bone=None
			calf_twist3_bone=None
			calf_twist4_bone=None
			calf_twist5_bone=None
			calf_twist6_bone=None
			calf_twist7_bone=None
			calf_twist_count=0
			foot_bone=None
			toes_bone=None
			toes_end_bone=None
			if thigh_bone.children:
				for child in thigh_bone.children:
					if child.children:
						calf_bone=child
				for thigh_child in thigh_bone.children:
					if "twist" in thigh_child.name.lower():
						if thigh_twist_count==0:
							thigh_twist_bone=thigh_child
						elif thigh_twist_count==1:
							thigh_twist2_bone=thigh_child
						elif thigh_twist_count==2:
							thigh_twist3_bone=thigh_child
						elif thigh_twist_count==3:
							thigh_twist4_bone=thigh_child
						elif thigh_twist_count==4:
							thigh_twist5_bone=thigh_child
						elif thigh_twist_count==5:
							thigh_twist6_bone=thigh_child
						elif thigh_twist_count==6:
							thigh_twist7_bone=thigh_child
						thigh_twist_count +=1
			if calf_bone:
				for calf_child in calf_bone.children:
					if "twist" in calf_child.name.lower():
						if calf_twist_count==0:
							calf_twist_bone=calf_child
						elif calf_twist_count==1:
							calf_twist2_bone=calf_child
						elif calf_twist_count==2:
							calf_twist3_bone=calf_child
						elif calf_twist_count==3:
							calf_twist4_bone=calf_child
						elif calf_twist_count==4:
							calf_twist5_bone=calf_child
						elif calf_twist_count==5:
							calf_twist6_bone=calf_child
						elif calf_twist_count==6:
							calf_twist7_bone=calf_child
						calf_twist_count +=1
					if calf_child.children and not "twist" in calf_child.name.lower():
						foot_bone=calf_child
			if thigh_bone:
				new_item.bone_01=thigh_bone.name
			if thigh_twist_bone:
				new_item.bone_02=thigh_twist_bone.name
			if thigh_twist2_bone:
				new_item.bone_twist_02_01=thigh_twist2_bone.name
			if thigh_twist3_bone:
				new_item.bone_twist_03_01=thigh_twist3_bone.name
			if thigh_twist4_bone:
				new_item.bone_twist_04_01=thigh_twist4_bone.name
			if thigh_twist5_bone:
				new_item.bone_twist_05_01=thigh_twist5_bone.name
			if thigh_twist6_bone:
				new_item.bone_twist_06_01=thigh_twist6_bone.name
			if thigh_twist7_bone:
				new_item.bone_twist_07_01=thigh_twist7_bone.name
			if calf_bone:
				new_item.bone_03=calf_bone.name
			if calf_twist_bone:
				new_item.bone_04=calf_twist_bone.name
			if calf_twist2_bone:
				new_item.bone_twist_02_02=calf_twist2_bone.name
			if calf_twist3_bone:
				new_item.bone_twist_03_02=calf_twist3_bone.name
			if calf_twist4_bone:
				new_item.bone_twist_04_02=calf_twist4_bone.name
			if calf_twist5_bone:
				new_item.bone_twist_05_02=calf_twist5_bone.name
			if calf_twist6_bone:
				new_item.bone_twist_06_02=calf_twist6_bone.name
			if calf_twist7_bone:
				new_item.bone_twist_07_02=calf_twist7_bone.name
			if foot_bone:
				new_item.bone_05=foot_bone.name
				if len(foot_bone.children):
					toes_bone=foot_bone.children[0]
			if toes_bone:
				new_item.bone_06=toes_bone.name
				if len (toes_bone.children)==1:
					toes_end_bone=toes_bone.children[0]
			if toes_end_bone:
				new_item.bone_07=toes_end_bone.name
			new_item.twist_bones_amount=thigh_twist_count if thigh_twist_count > calf_twist_count else calf_twist_count
			if foot_bone:
				evaluate_foot_up_axis(new_item,foot_bone)
			if foot_bone:
				par_list=[foot_bone]
				if toes_bone:
					par_list.append(toes_bone)
				for par in par_list:
					if len(par.children):
						found_toe_finger=False
						for finger_bone in par.children:
							if "THUMB" in finger_bone.name.upper():
								new_item.thumb=finger_bone.name
								found_toe_finger=True
							elif "MIDDLE" in finger_bone.name.upper() or "MID" in finger_bone.name.upper():
								new_item.middle=finger_bone.name
								found_toe_finger=True
							elif "INDEX" in finger_bone.name.upper():
								new_item.index=finger_bone.name
								found_toe_finger=True
							elif "RING" in finger_bone.name.upper():
								new_item.ring=finger_bone.name
								found_toe_finger=True
							elif "PINKY" in finger_bone.name.upper():
								new_item.pinky=finger_bone.name
								found_toe_finger=True
						if found_toe_finger:
							new_item.fingers= '3'
							break
		elif input_type== "ARM":
			shoulder_bone=active_bone
			arm_bone=None
			arm_twist_bone=None
			arm_twist2_bone=None
			arm_twist3_bone=None
			arm_twist4_bone=None
			arm_twist5_bone=None
			arm_twist6_bone=None
			arm_twist7_bone=None
			arm_twist_count=0
			forearm_bone=None
			forearm_twist_bone=None
			forearm_twist2_bone=None
			forearm_twist3_bone=None
			forearm_twist4_bone=None
			forearm_twist5_bone=None
			forearm_twist6_bone=None
			forearm_twist7_bone=None
			forearm_twist_count=0
			hand_bone=None
			if len(shoulder_bone.children)==1:
				arm_bone=shoulder_bone.children[0]
			if arm_bone:
				if arm_bone.children:
					for arm_child in arm_bone.children:
						if "twist" in arm_child.name.lower():
							if arm_twist_count==0:
								arm_twist_bone=arm_child
							elif arm_twist_count==1:
								arm_twist2_bone=arm_child
							elif arm_twist_count==2:
								arm_twist3_bone=arm_child
							elif arm_twist_count==3:
								arm_twist4_bone=arm_child
							elif arm_twist_count==4:
								arm_twist5_bone=arm_child
							elif arm_twist_count==5:
								arm_twist6_bone=arm_child
							elif arm_twist_count==6:
								arm_twist7_bone=arm_child
							arm_twist_count +=1
				for arm_child in arm_bone.children:
					if len(arm_child.children) and not "twist" in arm_child.name.lower():
						forearm_bone=arm_child
			if forearm_bone:
				for forearm_child in forearm_bone.children:
					if "twist" in forearm_child.name.lower():
						if forearm_twist_count==0:
							forearm_twist_bone=forearm_child
						elif forearm_twist_count==1:
							forearm_twist2_bone=forearm_child
						elif forearm_twist_count==2:
							forearm_twist3_bone=forearm_child
						elif forearm_twist_count==3:
							forearm_twist4_bone=forearm_child
						elif forearm_twist_count==4:
							forearm_twist5_bone=forearm_child
						elif forearm_twist_count==5:
							forearm_twist6_bone=forearm_child
						elif forearm_twist_count==6:
							forearm_twist7_bone=forearm_child
						forearm_twist_count +=1
					if len(forearm_child.children) and not "twist" in forearm_child.name.lower():
						hand_bone=forearm_child
			if hand_bone:
				if len(hand_bone.children):
					new_item.fingers= "3"# determining if the fingers are made of 3 or 4 bones is tricky since there may be "end" bones at the tip
					for finger_bone in hand_bone.children:
						if "THUMB" in finger_bone.name.upper():
							new_item.thumb=finger_bone.name
						elif "MIDDLE" in finger_bone.name.upper() or "MID" in finger_bone.name.upper():
							new_item.middle=finger_bone.name
						elif "INDEX" in finger_bone.name.upper():
							new_item.index=finger_bone.name
						elif "RING" in finger_bone.name.upper():
							new_item.ring=finger_bone.name
						elif "PINKY" in finger_bone.name.upper():
							new_item.pinky=finger_bone.name
			if shoulder_bone:
				new_item.bone_01=shoulder_bone.name
			if arm_bone:
				new_item.bone_02=arm_bone.name
			if arm_twist_bone:
				new_item.bone_03=arm_twist_bone.name
			if arm_twist2_bone:
				new_item.bone_twist_02_01=arm_twist2_bone.name
			if arm_twist3_bone:
				new_item.bone_twist_03_01=arm_twist3_bone.name
			if arm_twist4_bone:
				new_item.bone_twist_04_01=arm_twist4_bone.name
			if arm_twist5_bone:
				new_item.bone_twist_05_01=arm_twist5_bone.name
			if arm_twist6_bone:
				new_item.bone_twist_06_01=arm_twist6_bone.name
			if arm_twist7_bone:
				new_item.bone_twist_07_01=arm_twist7_bone.name
			if forearm_bone:
				new_item.bone_04=forearm_bone.name
			if forearm_twist_bone:
				new_item.bone_05=forearm_twist_bone.name
			if forearm_twist2_bone:
				new_item.bone_twist_02_02=forearm_twist2_bone.name
			if forearm_twist3_bone:
				new_item.bone_twist_03_02=forearm_twist3_bone.name
			if forearm_twist4_bone:
				new_item.bone_twist_04_02=forearm_twist4_bone.name
			if forearm_twist5_bone:
				new_item.bone_twist_05_02=forearm_twist5_bone.name
			if forearm_twist6_bone:
				new_item.bone_twist_06_02=forearm_twist6_bone.name
			if forearm_twist7_bone:
				new_item.bone_twist_07_02=forearm_twist7_bone.name
			if hand_bone:
				new_item.bone_06=hand_bone.name
			new_item.twist_bones_amount=arm_twist_count if arm_twist_count > forearm_twist_count else forearm_twist_count
			if hand_bone:
				evaluate_hand_up_axis(new_item,hand_bone,arm_bone)
			if arm_bone and hand_bone:
				evaluate_arm_up_axis(new_item,hand_bone,arm_bone)
		elif input_type== "SPINE":
			pelvis=active_bone
			spine_01_bone=None
			spine_02_bone=None
			spine_03_bone=None
			spine_04_bone=None
			spine_05_bone=None
			spine_06_bone=None
			def is_a_spine_name(bone):
				if "spine" in bone.name.lower() or "abdomen" in bone.name.lower() or "chest" in bone.name.lower():
					return True
				return False
			spine_bones_list=[spine_01_bone,spine_02_bone,spine_03_bone,spine_04_bone,spine_05_bone,spine_06_bone]
			if len(active_bone.children):
				for pelvis_child in active_bone.children:
					if "spine" in pelvis_child.name.lower() or "hips" in pelvis_child.name.lower():
						spine_01_bone=pelvis_child
						break
				if spine_01_bone==None:
					for pelvis_child in active_bone.children:
						if (rig.matrix_world @ pelvis_child.tail)[2] > (rig.matrix_world @ active_bone.tail)[2]:
							spine_01_bone=pelvis_child
							break
				spine_bones_list=[spine_01_bone,spine_02_bone,spine_03_bone,spine_04_bone,spine_05_bone,spine_06_bone]
				for i,spine_bone in enumerate(spine_bones_list):
					if i==len(spine_bones_list)-1:
						break
					next_spine_bone=spine_bones_list[i+1]
					if spine_bone:
						print("发现脊椎骨骼")
						if len(spine_bone.children)==1:
							spine_bones_list[i+1]=spine_bone.children[0]
						else:
							for spine_child in spine_bone.children:
								if is_a_spine_name(spine_child):
									spine_bones_list[i+1]=spine_child
									break
			new_item.bone_01=pelvis.name if pelvis else ""
			if spine_bones_list[0]:
				new_item.bone_02=spine_bones_list[0].name
			if spine_bones_list[1]:
				new_item.bone_03=spine_bones_list[1].name
			if spine_bones_list[2]:
				new_item.bone_04=spine_bones_list[2].name
			if spine_bones_list[3]:
				new_item.bone_05=spine_bones_list[3].name
			if spine_bones_list[4]:
				new_item.bone_06=spine_bones_list[4].name
			if spine_bones_list[5]:
				new_item.bone_07=spine_bones_list[5].name
			spine_count=1
			for spine_bone in spine_bones_list:
				print('spine_bone',spine_bone)
				if spine_bone !=None:
					spine_count +=1
			new_item.spine_amount=spine_count
		elif input_type== "HEAD":
			neck_bone=active_bone
			neck_name=active_bone.name
			neck2_bone=None
			neck2_name= ""
			head_bone=None
			head_name= ""
			head_end_bone=None
			head_end_name= ""
			if len(neck_bone.children):
				neck_child=neck_bone.children[0]
				if "neck" in neck_child.name.lower():
					neck2_bone=neck_child
					neck2_name=neck2_bone.name
			head_parent=neck2_bone if neck2_bone else neck_bone
			if len(head_parent.children):
				if len(head_parent.children)==1:
					head_bone=head_parent.children[0]
					head_name=head_bone.name
			if head_bone:
				if len(head_bone.children):
					for cbone in head_bone.children:
						if "head" in cbone.name.lower():
							head_end_bone=cbone
							head_end_name=head_end_bone.name
							break
			new_item.bone_01=neck_name
			new_item.bone_04=neck2_name
			new_item.bone_02=head_name
			new_item.bone_03=head_end_name
		elif input_type== 'TAIL':
			new_item.bone_01=active_bone.name
		if active_bone.name.upper().endswith(".L") or active_bone.name.upper().endswith("_L") or active_bone.name.upper().endswith("-L") or "LEFT" in active_bone.name.upper() or "_L_" in active_bone.name.upper() or " L " in active_bone.name.upper() or active_bone.name.upper().startswith("L_"):
			new_item.side= "LEFT"
		elif active_bone.name.upper().endswith(".R") or active_bone.name.upper().endswith("_R") or active_bone.name.upper().endswith("-R") or "RIGHT" in active_bone.name.upper() or "_R_" in active_bone.name.upper() or " R " in active_bone.name.upper() or active_bone.name.upper().startswith("R_"):
			new_item.side= "RIGHT"
		else:
			new_item.side= "CENTER"
	restore_current_mode(current_mode)
	rig.data.use_mirror_x=xmirror_state
def _remove_limb():
	scn=bpy.context.scene
	scn.limb_map.remove(scn.limb_map_index)
	if scn.limb_map_index > len(scn.limb_map)-1:
		scn.limb_map_index=len(scn.limb_map)-1
def update_arp_tab():
	interface_classes=(ARP_PT_quick_rig_menu,ARP_PT_quick_rig_update)
	UCL(interface_classes)
	QuickRigPanel.bl_category=P().C
	RCL(interface_classes)
def update_quick_presets():
	presets_directory=P().custom_presets_path
	if not (presets_directory.endswith("\\") or presets_directory.endswith('/')):
		presets_directory += '/'
	try:
		os.listdir(presets_directory)
	except:
		return
	for file in os.listdir(presets_directory):
		if not file.endswith(".py"):
			continue
		preset_name=file.replace('.py', '')
		if preset_name in ARP_MT_quick_import.custom_presets:
			continue
		ARP_MT_quick_import.custom_presets.append(preset_name)
class QuickRigPanel:
	bl_space_type= 'VIEW_3D';bl_region_type="UI";bl_category=TB
class ARP_PT_quick_rig_menu(bpy.types.Panel):
	bl_label=BT;bl_idname="ARP_PT_quick_rig_menu";bl_options={'DEFAULT_CLOSED'};bl_category=TB;bl_space_type='VIEW_3D';bl_region_type='UI'
	def draw_header_preset(S,_):DHP(S,_,S.layout)
	def draw_header(S,_):DIC(S,_)
	def draw(self,context):
		layout=self.layout
		DH(self,context,layout)
		A=layout.row();A.scale_y=2;CKA(A,"auto_rig_pro_master","BV1VkPxzsEY3")
		object=context.active_object
		scene=context.scene
		has_rigged=False
		if object:
			if object.type== "ARMATURE":
				if len(object.data.keys()):
					if "arp_qr_data" in object.data.keys():
						has_rigged=True
		col=layout.column(align=True);col.enabled=CKD("auto_rig_pro_master")
		col.scale_y=1.3
		if has_rigged:
			GO(col,"arp.quick_revert",text="Revert",icon='RECOVER_LAST')
		else:
			GO(col,"arp.quick_make_rig",text="Quick Rig!")
		col.separator()
		col=layout.column(align=True)
		row=col.row(align=True)
		GO(row,"arp.quick_import_mapping",text="Import")
		GM(row,'ARP_MT_quick_import',text="",icon='DOWNARROW_HLT')
		row=row.row(align=True)
		GO(row,"arp.quick_export_mapping",text="Export")
		GM(row,'ARP_MT_quick_export',text="",icon='DOWNARROW_HLT')
		col.separator()
		row=col.row()
		row.template_list("ARP_UL_quick_limbs_list", "",scene, "limb_map",scene, "limb_map_index",rows=5)
		col=row.column(align=True)
		col.operator("arp.quick_add_limb",text='',icon='ADD')
		col.operator("arp.quick_remove_limb",text='',icon='REMOVE')
		col.operator("arp.quick_mirror_limb",text='',icon='MOD_MIRROR')
		col.separator()
		col.separator()
		col.operator("arp.quick_limbs_move",text="",icon="TRIA_UP").direction= 'UP'
		col.operator("arp.quick_limbs_move",text="",icon="TRIA_DOWN").direction= 'DOWN'
		'''# disable for now. Zeroing out the armature does not seem necessary anymore in latest Blender and QR versions
		if scene.arp_quick_freeze_check:
			GL(layout,"Armature transforms not frozen",icon="ERROR")
			GL(layout,"Freeze it first below:")
			col=layout.column(align=True)
			GO(col,"arp.quick_freeze_armature",text="Freeze Armature")
			return
		'''
		layout.separator()
		col=layout.column(align=True)
		if len(scene.limb_map):
			slimb=scene.limb_map[scene.limb_map_index]
			GE(col,slimb,"type",text="Type")
			GE(col,slimb,"side",text="Side")
			col.separator()
			if slimb.type== "LEG":
				GP(col,slimb, "leg_type",text="Leg Type")
				col.separator()
				GP(col,slimb, "twist_bones_amount",text="Twist Bones Amount")
				col.separator()
				row=col.row(align=True)
				if slimb.leg_type.startswith("3"):
					GP(row,slimb, "upper_thigh",text="UpThigh")
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "upper_thigh"
					if slimb.weights_override:
						row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "upper_thigh"
				row=col.row(align=True)
				GP(row,slimb, "bone_01",text="Thigh")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_01"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_01"
				if slimb.twist_bones_amount >=1:
					row=col.row(align=True)
					GP(row,slimb, "bone_02",text="Twist")
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_02"
					if slimb.weights_override:
						row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_02"
				if slimb.twist_bones_amount >=2:
					for i in range(2,slimb.twist_bones_amount+1):
						id= '%02d' % (i)
						row=col.row(align=True)
						GP(row,slimb, 'bone_twist_'+id+'_01',text="Twist "+str(i))
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= 'bone_twist_'+id+'_01'
				row=col.row(align=True)
				GP(row,slimb, "bone_03",text="Calf")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_03"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_03"
				if slimb.twist_bones_amount >=1:
					row=col.row(align=True)
					GP(row,slimb, "bone_04",text="Twist")
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_04"
					if slimb.weights_override:
						row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_04"
				if slimb.twist_bones_amount >=2:
					for i in range(2,slimb.twist_bones_amount+1):
						id= '%02d' % (i)
						row=col.row(align=True)
						GP(row,slimb, 'bone_twist_'+id+'_02',text='Twist '+str(i))
						row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'bone_twist_'+id+'_02'
				row=col.row(align=True)
				GP(row,slimb, "bone_05",text="Foot")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_05"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_05"
				row=col.row(align=True)
				GP(row,slimb, "bone_06",text="Toes")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_06"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_06"
				row=col.row(align=True)
				GP(row,slimb, "bone_07",text="Toes End")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_07"
				row=col.row().split(factor=0.35)
				GL(row,'Toes Fingers:')
				row.prop(slimb, 'fingers',text='')
				if slimb.fingers != "NONE":
					GP(col,slimb, 'manual_phalanges',text='Manual Phalanges')
					row=col.row(align=True)
					GP(row,slimb, 'thumb',text='Thumb Meta' if slimb.fingers== '4' else 'Thumb')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "thumb"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "thumb2",text="thumb2")
						row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= "thumb2"
					if slimb.manual_phalanges and slimb.fingers== '4':
						row=col.row(align=True)
						GP(row,slimb, "thumb3",text="thumb3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "thumb3"
					row=col.row(align=True)
					GP(row,slimb, "index",text='Index Meta' if slimb.fingers== '4' else 'Index')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "index1",text="index1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "index2",text="index2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "index3",text="index3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index3"
					row=col.row(align=True)
					GP(row,slimb, "middle",text='Middle Meta' if slimb.fingers== '4' else 'Middle')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "middle1",text="middle1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "middle2",text="middle2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "middle3",text="middle3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle3"
					row=col.row(align=True)
					GP(row,slimb, "ring",text='Ring Meta' if slimb.fingers== '4' else 'Ring')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "ring1",text="ring1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "ring2",text="ring2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "ring3",text="ring3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring3"
					row=col.row(align=True)
					GP(row,slimb, "pinky",text='Pinky Meta' if slimb.fingers== '4' else 'Pinky')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "pinky1",text="pinky1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "pinky2",text="pinky2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "pinky3",text="pinky3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky3"
				col.separator()
				GP(col,slimb, "weights_override",text="Enable Weights Override")
				col.separator()
				GL(col,"Foot Up Axis:")
				col=layout.column()
				col.enabled=slimb.fingers== "NONE"
				GP(col,slimb, "force_up_axis",text="Use World Z")
				col=layout.column(align=True)
				row=col.row().split(factor=0.6,align=True)
				row.prop(slimb, "up_axis",text="")
				op=GO(row,"arp.quick_eval_axis",text="Evaluate")
				op.type= "foot_up_axis"
				op.foot_bone_name=slimb.bone_05
				col.enabled=not slimb.force_up_axis or slimb.fingers != "NONE"
				col=layout.column(align=True)
				GL(col,"Foot Dir Axis:")
				col.prop(slimb, "foot_dir_axis",text="")
				col.separator()
				GP(col,slimb, "auto_knee",text="Auto-Knee Direction")
				GP(col,slimb, "connect_foot_to_calf",text="Connect Foot to Calf")
				GP(col,slimb, 'auto_ik_roll',text='Auto IK Roll')
			elif slimb.type== "ARM":
				GP(col,slimb, "twist_bones_amount",text="Twist Bones Amount")
				col.separator()
				row=col.row(align=True)
				GP(row,slimb, "bone_01",text="Shoulder")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_01"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_01"
				row=col.row(align=True)
				GP(row,slimb, "bone_02",text="Arm")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_02"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_02"
				if slimb.twist_bones_amount >=1:
					row=col.row(align=True)
					GP(row,slimb, "bone_03",text="Twist")
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_03"
					if slimb.weights_override:
						row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_03"
				if slimb.twist_bones_amount >=2:
					for i in range(2,slimb.twist_bones_amount+1):
						id= '%02d' % (i)
						row=col.row(align=True)
						GP(row,slimb, 'bone_twist_'+id+'_01',text='Twist '+str(i))
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= 'bone_twist_'+id+'_01'
				row=col.row(align=True)
				GP(row,slimb, "bone_04",text="Forearm")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_04"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_04"
				if slimb.twist_bones_amount >=1:
					row=col.row(align=True)
					GP(row,slimb, "bone_05",text="Twist")
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_05"
					if slimb.weights_override:
						row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_05"
				if slimb.twist_bones_amount >=2:
					for i in range(2,slimb.twist_bones_amount+1):
						id= '%02d' % (i)
						row=col.row(align=True)
						GP(row,slimb, 'bone_twist_'+id+'_02',text='Twist '+str(i))
						row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'bone_twist_'+id+'_02'
				row=col.row(align=True)
				GP(row,slimb, "bone_06",text="Hand")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_06"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_06"
				GP(col,slimb, "fingers",text="Fingers")
				if slimb.fingers != "NONE":
					GP(col,slimb, 'manual_phalanges',text='Manual Phalanges')
					row=col.row(align=True)
					GP(row,slimb, 'thumb',text='Thumb')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "thumb"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "thumb2",text="thumb2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "thumb2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "thumb3",text="thumb3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "thumb3"
					row=col.row(align=True)
					GP(row,slimb, "index",text='Index Meta' if slimb.fingers== '4' else 'Index')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "index1",text="index1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "index2",text="index2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "index3",text="index3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "index3"
					row=col.row(align=True)
					GP(row,slimb, "middle",text='Middle Meta' if slimb.fingers== '4' else 'Middle')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "middle1",text="middle1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "middle2",text="middle2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "middle3",text="middle3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "middle3"
					row=col.row(align=True)
					GP(row,slimb, "ring",text='Ring Meta' if slimb.fingers== '4' else 'Ring')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "ring1",text="ring1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "ring2",text="ring2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "ring3",text="ring3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "ring3"
					row=col.row(align=True)
					GP(row,slimb, "pinky",text='Pinky Meta' if slimb.fingers== '4' else 'Pinky')
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky"
					if slimb.manual_phalanges:
						if slimb.fingers== '4':
							row=col.row(align=True)
							GP(row,slimb, "pinky1",text="pinky1")
							row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky1"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "pinky2",text="pinky2")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky2"
					if slimb.manual_phalanges:
						row=col.row(align=True)
						GP(row,slimb, "pinky3",text="pinky3")
						row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "pinky3"
				col.separator()
				GP(col,slimb, "weights_override",text="Enable Weights Override")
				col.separator()
				GL(col,"Arms Up Axis:")
				row=col.row().split(factor=0.6,align=True)
				row.prop(slimb, "up_axis_arm",text="")
				op=GO(row,"arp.quick_eval_axis",text="Evaluate")
				op.type= "up_axis_arm"
				op.hand_bone_name=slimb.bone_06
				op.arm_bone_name=slimb.bone_02
				GL(col,"Hand and Fingers Up Axis:")
				row=col.row().split(factor=0.6,align=True)
				row.prop(slimb, "up_axis",text="")
				op=GO(row,"arp.quick_eval_axis",text="Evaluate")
				op.type= "up_axis"
				op.hand_bone_name=slimb.bone_06
				op.arm_bone_name=slimb.bone_02
				col.separator()
				GP(col,slimb, "primary_axis_auto",text="Auto Primary Axis")
				col=layout.column(align=True)
				col.enabled=not slimb.primary_axis_auto
				col.prop(slimb, "primary_axis",text="")
				col=layout.column(align=True)
				GL(col,'Elbow Axis Correction:')
				col.prop(slimb, 'IK_axis_correc',text='')
				GP(col,slimb, "auto_elbow",text="Auto-Elbow Direction")
				GP(col,slimb, 'auto_ik_roll',text='Auto IK Roll')
			elif slimb.type== "SPINE":
				GP(col,slimb, 'spine_amount',text='Spine Amount')
				col.separator()
				row=col.row(align=True)
				GP(row,slimb, "bone_01",text="Pelvis")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_01"
				if slimb.weights_override:
					row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_01"
				for spinei in range(2,slimb.spine_amount+1):
					row=col.row(align=True)
					GP(row,slimb, "bone_"+'%02d' % spinei,text="Spine"+str(spinei-1))
					row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_"+'%02d' % spinei
					if slimb.weights_override:
						row.operator("arp.quick_set_weight_override",text="",icon='GROUP_BONE').value= "bone_"+'%02d' % spinei
				col=layout.column()
				GP(col,slimb, "weights_override",text="Enable Weights Override")
				col.separator()
				GL(col,"Spine Z Axis:")
				GP(col,slimb, "force_z_axis",text="Use World Y")
				col.separator()
				GP(col,slimb, "primary_axis_auto",text="Auto Primary Axis")
				col=layout.column(align=True)
				col.enabled=not slimb.primary_axis_auto
				col.prop(slimb, "primary_axis",text="")
				col=layout.column(align=True)
				if not slimb.primary_axis_auto:
					col.enabled=False
				GP(col,slimb, "connect",text="Connect")
				GP(col,slimb, 'pelvis_up',text="Force Pelvis Up")
				col=layout.column(align=True)
			elif slimb.type== "HEAD":
				GP(col,slimb, "neck_bones_amount",text="Neck Bones Amount")
				col.separator()
				row=col.row(align=True)
				GP(row,slimb, "bone_01",text="Neck")
				row.operator("arp.quick_pick_bone",text="",icon='EYEDROPPER').value= "bone_01"
				if slimb.neck_bones_amount > 1:
					for i in range(2,slimb.neck_bones_amount+1):
						row=col.row(align=True)
						pname= 'neck'+str(i)
						if i==2:
							pname= 'bone_04'# backward-compatibility
						GP(row,slimb,pname,text='Neck '+str(i))
						row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value=pname
				row=col.row(align=True)
				GP(row,slimb, 'bone_02',text='Head')
				row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'bone_02'
				row=col.row(align=True)
				GP(row,slimb, 'bone_03',text='Head End')
				row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'bone_03'
				col.separator()
				GP(col,slimb, 'straight_head',text='Vertical Head')
				col.separator()
				GP(col,slimb, 'facial',text='Facial',toggle=True)
				if slimb.facial:
					row=col.row(align=True)
					GP(row,slimb, 'facial_right',text='Right Side',toggle=True)
					GP(row,slimb, 'facial_left',text='Left Side',toggle=True)
					col.separator()
					GO(col,"arp.quick_mirror_facial",text='Mirror',icon='MOD_MIRROR')
					def show_eyebrows_ui(panel):
						if panel:
							col=panel.column(align=True)
						else:
							box=layout.box()
							col=box.column(align=True)
							GP(col,slimb, 'facial_eyebrows',text='Eyebrows')
						if slimb.facial_eyebrows:
							GP(col,slimb, 'facial_eyebrows_amount',text='Eyebrows Amount')
							for side in ['left', 'right']:
								if (side== 'left' and not slimb.facial_left) or (side== 'right' and not slimb.facial_right): continue
								GL(col,'------'+side.title()+' Eyebrows ------')
								for i in range(1,slimb.facial_eyebrows_amount+1):
									row=col.row(align=True)
									GP(row,slimb, 'eyebrow_'+'%02d' % i+'_'+side,text='Brow '+str(i))
									row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'eyebrow_'+'%02d' % i+'_'+side
									row.prop(slimb, 'eyebrow_'+'%02d' % i+'_sk_'+side,toggle=True,icon='SHAPEKEY_DATA',text='')
									if getattr(slimb, 'eyebrow_'+'%02d' % i+'_sk_'+side):
										GP(col,slimb, 'eyebrow_'+'%02d' % i+'_sk_up_'+side,text='Brow Up')
										GP(col,slimb, 'eyebrow_'+'%02d' % i+'_sk_down_'+side,text='Brow Down')
							col.separator()
					if bpy.app.version >=(4,1,0):
						header_eyebrows,panel_eyebrows=layout.panel("qr_ui_eyebrows",default_closed=True)
						GP(header_eyebrows,slimb, 'facial_eyebrows',text='Eyebrows')
						if panel_eyebrows:
							show_eyebrows_ui(panel_eyebrows)
					else: show_eyebrows_ui(None)
					def show_eyes_ui(panel):
						if panel:
							col=panel.column()
						else:
							box=layout.box()
							col=box.column()
							GP(col,slimb, 'facial_eyes',text='Eyes')
						col=col.column(align=True)
						if slimb.facial_eyes:
							for side in ['left', 'right']:
								if (side== 'left' and not slimb.facial_left) or (side== 'right' and not slimb.facial_right): continue
								GL(col,'------'+ side.title()+' Eye:------')
								row=col.row(align=True)
								GP(row,slimb, 'eye_'+side,text='Eyeball')
								row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'eye_'+side
								col.separator()
								GP(col,slimb, 'eye_cor_sk_'+side,text='Eyelid Corrective Shapes',icon='SHAPEKEY_DATA',toggle=True)
								if getattr(slimb, 'eye_cor_sk_'+side):
									GP(col,slimb, 'eye_cor_sk_up_'+side,text='Up')
									GP(col,slimb, 'eye_cor_sk_down_'+side,text='Down')
									GP(col,slimb, 'eye_cor_sk_in_'+side,text='In')
									GP(col,slimb, 'eye_cor_sk_out_'+side,text='Out')
							col.separator()
							col.separator()
							GP(col,slimb, 'facial_eyelids',text='Eyelids Amount')
							col.separator()
							if slimb.facial_eyelids > 0:
								GP(col,slimb, 'eyelids_align_engine',text='Eyelids Align')
								for side in ['left', 'right']:
									if (side== 'left' and not slimb.facial_left) or (side== 'right' and not slimb.facial_right):
										continue
									GL(col,'------'+side.title()+' Eyelids ------')
									for i in range(1,slimb.facial_eyelids+1):
										row=col.row(align=True)
										GP(row,slimb, 'eyelid_top_'+'%02d' % i+'_'+side,text='Lid '+str(i)+' Up')
										row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'eyelid_top_'+'%02d' % i+'_'+side
										if i==1:
											row.prop(slimb, 'eyelid_top_sk_'+side,toggle=True,icon='SHAPEKEY_DATA',text='')
											if getattr(slimb, 'eyelid_top_sk_'+side):
												GP(col,slimb, 'eyelid_top_sk_up_'+side,text='Blink Up')
												GP(col,slimb, 'eyelid_top_sk_down_'+side,text='Blink Down')
										row=col.row(align=True)
										GP(row,slimb, 'eyelid_bot_'+'%02d' % i+'_'+side,text='Lid '+str(i)+' Low')
										row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'eyelid_bot_'+'%02d' % i+'_'+side
										if i==1:
											row.prop(slimb, 'eyelid_bot_sk_'+side,toggle=True,icon='SHAPEKEY_DATA',text='')
											if getattr(slimb, 'eyelid_bot_sk_'+side):
												GP(col,slimb, 'eyelid_bot_sk_up_'+side,text='Blink Up')
												GP(col,slimb, 'eyelid_bot_sk_down_'+side,text='Blink Down')
									row=col.row(align=True)
									GP(row,slimb, 'eyelid_corner_in_'+side,text='Corner In')
									row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'eyelid_corner_in_'+side
									row=col.row(align=True)
									GP(row,slimb, 'eyelid_corner_out_'+side,text='Corner Out')
									row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'eyelid_corner_out_'+side
								col.separator()
					if bpy.app.version >=(4,1,0):
						header_eyes,panel_eyes=layout.panel("qr_ui_eyes",default_closed=True)
						GP(header_eyes,slimb, 'facial_eyes',text='Eyes')
						if panel_eyes:
							show_eyes_ui(panel_eyes)
					else: show_eyes_ui(None)
					def show_cheeks_ui(panel):
						if panel:
							col=panel.column(align=True)
						else:
							box=layout.box()
							col=box.column(align=True)
							GP(col,slimb, 'facial_cheeks',text='Cheeks')
						if slimb.facial_cheeks:
							for side in ['left', 'right']:
								if (side== 'left' and not slimb.facial_left) or (side== 'right' and not slimb.facial_right): continue
								GL(col,'------'+ side.title()+' Cheeks:------')
								row=col.row(align=True)
								GP(row,slimb, 'cheek_'+side,text='Cheek Main')
								row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'cheek_'+side
								row.prop(slimb, 'cheek_sk_'+side,toggle=True,icon='SHAPEKEY_DATA',text='')
								if getattr(slimb, 'cheek_sk_'+side):
									GP(col,slimb, 'cheek_sk_inflate_'+side,text='Inflate')
								row=col.row(align=True)
								GP(row,slimb, 'cheek_smile_'+side,text='Cheek Up')
								row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'cheek_smile_'+side
								row.prop(slimb, 'cheek_smile_sk_'+side,toggle=True,icon='SHAPEKEY_DATA',text='')
								if getattr(slimb, 'cheek_smile_sk_'+side):
									GP(col,slimb, 'cheek_smile_sk_up_'+side,text='Move Up')
									GP(col,slimb, 'cheek_smile_sk_down_'+side,text='Move Down')
					if bpy.app.version >=(4,1,0):
						header_cheeks,panel_cheeks=layout.panel('qr_ui_cheek',default_closed=True)
						GP(header_cheeks,slimb, 'facial_cheeks',text='Cheeks')
						if panel_cheeks:
							show_cheeks_ui(panel_cheeks)
					else: show_cheeks_ui(None)
					def show_nose_ui(panel):
						if panel:
							col=panel.column(align=True)
						else:
							box=layout.box()
							col=box.column(align=True)
							GP(col,slimb, 'facial_nose',text='Nose')
						if slimb.facial_nose:
							GL(col,'Nose:')
							row=col.row(align=True)
							GP(row,slimb, 'nose_root',text='Root')
							row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'nose_root'
							row=col.row(align=True)
							GP(row,slimb, 'nose_tip1',text='Tip 1')
							row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'nose_tip1'
							row=col.row(align=True)
							GP(row,slimb, 'nose_tip2',text='Tip 2')
							row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'nose_tip2'
					if bpy.app.version >=(4,1,0):
						header_nose,panel_nose=layout.panel('qr_ui_nose',default_closed=True)
						GP(header_nose,slimb, 'facial_nose',text='Nose')
						if panel_nose:
							show_nose_ui(panel_nose)
					else: show_nose_ui(None)
					def show_mouth_ui(panel):
						if panel:
							col=panel.column(align=True)
						else:
							box=layout.box()
							col=box.column(align=True)
							GP(col,slimb, 'facial_mouth',text='Mouth')
						if slimb.facial_mouth:
							row=col.row(align=True)
							GP(row,slimb, 'jaw',text='Jaw')
							row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'jaw'
							row.prop(slimb, 'jaw_sk',toggle=True,icon='SHAPEKEY_DATA',text='')
							if getattr(slimb, 'jaw_sk'):
								GP(col,slimb, 'jaw_sk_open',text='Jaw Open')
								GP(col,slimb, 'jaw_sk_left',text='Jaw Left')
								GP(col,slimb, 'jaw_sk_right',text='Jaw Right')
							col.separator()
							row=col.row(align=True)
							GP(row,slimb, 'lips_offset',text='Lips Offset')
							if slimb.lips_offset:
								row.prop(slimb, 'lips_offset_sk',toggle=True,icon='SHAPEKEY_DATA',text='')
								if slimb.lips_offset_sk:
									GP(col,slimb, 'lips_offset_sk_up',text='Move Up')
									GP(col,slimb, 'lips_offset_sk_down',text='Move Down')
									GP(col,slimb, 'lips_offset_sk_left',text='Move Left')
									GP(col,slimb, 'lips_offset_sk_right',text='Move Right')
									GP(col,slimb, 'lips_offset_sk_forward',text='Move Forw')
							col.separator()
							GP(col,slimb, 'lips_roll_sk',text='Lips Roll Shapes',icon='SHAPEKEY_DATA')
							if slimb.lips_roll_sk:
								GP(col,slimb, 'lips_roll_sk_up_in',text='Roll Up In')
								GP(col,slimb, 'lips_roll_sk_up_out',text='Roll Up Out')
								GP(col,slimb, 'lips_roll_sk_low_in',text='Roll Low In')
								GP(col,slimb, 'lips_roll_sk_low_out',text='Roll Low Out')
							col.separator()
							GP(col,slimb, 'lips_amount',text='Lips Amount')
							col.separator()
							if slimb.lips_amount > 0:
								col=col.column(align=True)
								row=col.row(align=True)
								GP(row,slimb, 'lip_top_mid',text='Up Mid')
								row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'lip_top_mid'
								row.prop(slimb, 'lip_top_mid_sk',toggle=True,icon='SHAPEKEY_DATA',text='')
								if getattr(slimb, 'lip_top_mid_sk'):
									GP(col,slimb, 'lip_top_mid_sk_up',text='Move Up')
									GP(col,slimb, 'lip_top_mid_sk_down',text='Move Down')
								row=col.row(align=True)
								GP(row,slimb, 'lip_bot_mid',text='Low Mid')
								row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'lip_bot_mid'
								row.prop(slimb, 'lip_bot_mid_sk',toggle=True,icon='SHAPEKEY_DATA',text='')
								if getattr(slimb, 'lip_bot_mid_sk'):
									GP(col,slimb, 'lip_bot_mid_sk_up',text='Move Up')
									GP(col,slimb, 'lip_bot_mid_sk_down',text='Move Down')
								col=col.column(align=True)
								col.separator()
								for side in ['left', 'right']:
									GL(col,'------'+side.title()+' Lips------')
									row=col.row(align=True)
									GP(row,slimb, 'lip_corner_'+side,text='Corner')
									row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'lip_corner_'+side
									row.prop(slimb, 'lip_corner_'+side+'_sk',text='',icon='SHAPEKEY_DATA',toggle=True)
									if getattr(slimb, 'lip_corner_'+side+'_sk'):
										GP(col,slimb, 'lip_corner_'+side+'_sk_up',text='Move Up')
										GP(col,slimb, 'lip_corner_'+side+'_sk_down',text='Move Down')
										GP(col,slimb, 'lip_corner_'+side+'_sk_in',text='Move In')
										GP(col,slimb, 'lip_corner_'+side+'_sk_out',text='Move Out')
										col.separator()
									for i in range(1,slimb.lips_amount+1):
										row=col.row(align=True)
										GP(row,slimb, 'lip_top_'+'%02d' % i+'_'+side,text=str(i)+' Up')
										row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'lip_top_'+'%02d' % i+'_'+side
										row.prop(slimb, 'lip_top_'+'%02d' % i+'_sk_'+side,toggle=True,icon='SHAPEKEY_DATA',text='')
										if getattr(slimb, 'lip_top_'+'%02d' % i+'_sk_'+side):
											GP(col,slimb, 'lip_top_'+'%02d' % i+'_sk_up_'+side,text='Move Up')
											GP(col,slimb, 'lip_top_'+'%02d' % i+'_sk_down_'+side,text='Move Down')
										row=col.row(align=True)
										GP(row,slimb, 'lip_bot_'+'%02d' % i+'_'+side,text=str(i)+' Low')
										row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'lip_bot_'+'%02d' % i+'_'+side
										row.prop(slimb, 'lip_bot_'+'%02d' % i+'_sk_'+side,toggle=True,icon='SHAPEKEY_DATA',text='')
										if getattr(slimb, 'lip_bot_'+'%02d' % i+'_sk_'+side):
											GP(col,slimb, 'lip_bot_'+'%02d' % i+'_sk_up_'+side,text='Move Up')
											GP(col,slimb, 'lip_bot_'+'%02d' % i+'_sk_down_'+side,text='Move Down')
									col.separator()
							col.separator()
							GP(col,slimb, 'tongues_amount',text='Tongues Amount')
							col.separator()
							if slimb.tongues_amount > 0:
								for i in range(1,slimb.tongues_amount+1):
									row=col.row(align=True)
									GP(row,slimb, 'tongue_'+'%02d' % i,text=str(i))
									row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'tongue_'+'%02d' % i
							col.separator()
							GP(col,slimb, 'facial_teeth',text='Teeth')
							if slimb.facial_teeth:
								for lvl in ['top', 'bot']:
									row=col.row(align=True)
									GP(row,slimb, 'teeth_'+lvl+'_mid',text=lvl.title()+' Mid')
									row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'teeth_'+lvl+'_mid'
									for side in ['left', 'right']:
										row=col.row(align=True)
										GP(row,slimb, 'teeth_'+lvl+'_'+side,text=lvl.title()+' '+side.title())
										row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'teeth_'+lvl+'_'+side
					if bpy.app.version >=(4,1,0):
						header_mouth,panel_mouth=layout.panel('qr_ui_mouth',default_closed=True)
						GP(header_mouth,slimb, 'facial_mouth',text='Mouth')
						if panel_mouth:
							show_mouth_ui(panel_mouth)
					else: show_mouth_ui(None)
					def show_chin_ui(panel):
						if panel:
							col=panel.column(align=True)
						else:
							box=layout.box()
							col=box.column(align=True)
							GP(col,slimb, 'facial_chin',text='Chin')
						if slimb.facial_chin:
							row=col.row(align=True)
							GP(row,slimb, 'chin_01',text='Chin 01')
							row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'chin_01'
							row=col.row(align=True)
							GP(row,slimb, 'chin_02',text='Chin 02')
							row.operator("arp.quick_pick_bone",text='',icon='EYEDROPPER').value= 'chin_02'
							col.separator()
					if bpy.app.version >=(4,1,0):
						header_chin,panel_chin=layout.panel('qr_ui_chin',default_closed=True)
						GP(header_chin,slimb, 'facial_chin',text='Chin')
						if panel_chin:
							show_chin_ui(panel_chin)
					else: show_chin_ui(None)
				col=layout.column()
				col.separator()
				GL(col,'Head Z Axis:')
				GP(col,slimb, "force_z_axis",text='Use World Y')
				col.separator()
				GP(col,slimb, 'primary_axis_auto',text='Auto Primary Axis')
				col=layout.column(align=True)
				col.enabled=not slimb.primary_axis_auto
				col.prop(slimb, 'primary_axis',text='')
			elif slimb.type== 'TAIL':
				GP(col,slimb, 'bone_01',text='Tail Root')
				GP(col,slimb, 'bone_02',text='Tail Tip (Optional)')
				col.separator()
				GP(col,slimb, "primary_axis_auto",text="Auto Primary Axis")
				col=layout.column(align=True)
				col.enabled=not slimb.primary_axis_auto
				col.prop(slimb, "primary_axis",text="")
				col=layout.column(align=True)
				if not slimb.primary_axis_auto:
					col.enabled=False
				GP(col,slimb, "connect",text="Connect")
class ARP_PT_quick_rig_update(Panel,QuickRigPanel):
	bl_idname="ARP_PT_quick_rig_update";bl_label= "Updates";bl_parent_id= "ARP_PT_quick_rig_menu";bl_space_type= 'VIEW_3D';bl_region_type="UI";bl_category=TB;bl_options={'DEFAULT_CLOSED'}
	def draw(self,context):
		layout=self.layout
		GO(layout,"arp.quick_check_for_update",text='Check for Updates')
classes=(ARP_OT_quick_report_message,ARP_OT_quick_import_mapping,ARP_OT_quick_export_mapping,ARP_UL_quick_limbs_list,LimbProp,ARP_OT_quick_add_limb,ARP_OT_quick_remove_limb,ARP_OT_quick_mirror_limb,ARP_OT_quick_mirror_facial,ARP_OT_quick_pick_bone,ARP_PT_quick_rig_menu,ARP_PT_quick_rig_update,ARP_OT_quick_make_rig,ARP_OT_quick_revert,ARP_OT_quick_set_weight_override,ARP_OT_quick_freeze_armature,ARP_MT_quick_import,ARP_OT_quick_limbs_move,ARP_OT_quick_eval_axis,ARP_MT_quick_export,ARP_OT_quick_import_preset,ARP_OT_quick_export_preset,ARP_OT_quick_check_for_update,ARP_OT_reimport_preset_fuzzy)
def register():
	RCL(classes)
	update_arp_tab()
	update_quick_presets()
	bpy.types.Scene.limb_map=bpy.props.CollectionProperty(name="Limb Map",type=LimbProp,description="肢体列表")
	bpy.types.Scene.limb_map_index=IntProperty(name="List Index",description="列表的索引",default=0)
	bpy.types.Scene.arp_quick_freeze_check=BoolProperty(default=False,description="")
	bpy.types.Scene.arp_quick_hold_update=BoolProperty(default=False)
def unregister():
	from bpy.utils import unregister_class
	for cls in reversed(classes):
		UCL(cls)
	DAS(("limb_map","limb_map_index"),"Scene")
	DAS(("arp_quick_freeze_check","arp_quick_hold_update"),"Scene")
if __name__== "__main__":
	register()