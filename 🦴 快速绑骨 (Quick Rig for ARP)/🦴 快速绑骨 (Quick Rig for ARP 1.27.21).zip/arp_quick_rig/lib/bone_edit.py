import bpy
from math import *
from mathutils import *
from .maths_geo import *
def copy_bone_transforms(bone1,bone2):
	if bone1==None or bone2==None:
		return
	bone2.head=bone1.head.copy()
	bone2.tail=bone1.tail.copy()
	bone2.roll=bone1.roll
def get_bone_children(bname,single_child_only=False,tip_child=''):
	children_list=[]
	children_list=get_bone_children_recursive(bname,list=children_list,single=single_child_only,tip_name=tip_child)
	return children_list
def get_bone_children_recursive(bname,list=None,single=False,tip_name=''):
	_b=bpy.context.active_object.data.bones.get(bname)
	if _b.children:
		for _bi,child in enumerate(_b.children):
			if single:
				if _bi > 0:
					break
			list.append(child.name)
			if tip_name != '':
				if child.name==tip_name:
					print('Has hit chain tip:',tip_name)
					break
			get_bone_children_recursive(child.name,list=list,single=single,tip_name=tip_name)
	return list
def get_edit_bone(name):
	if name==None:
		return None
	return bpy.context.object.data.edit_bones.get(name)
def align_bone_x_axis(edit_bone,new_x_axis):
	new_x_axis=new_x_axis.cross(edit_bone.y_axis)
	new_x_axis.normalize()
	dot=max(-1.0,min(1.0,edit_bone.z_axis.dot(new_x_axis)))
	angle=acos(dot)
	edit_bone.roll +=angle
	dot1=edit_bone.z_axis.dot(new_x_axis)
	edit_bone.roll -=angle * 2.0
	dot2=edit_bone.z_axis.dot(new_x_axis)
	if dot1 > dot2:
		edit_bone.roll +=angle * 2.0
def align_bone_z_axis(edit_bone,new_z_axis):
	new_z_axis=-(new_z_axis.cross(edit_bone.y_axis))
	new_z_axis.normalize()
	dot=max(-1.0,min(1.0,edit_bone.x_axis.dot(new_z_axis)))
	angle=acos(dot)
	edit_bone.roll +=angle
	dot1=edit_bone.x_axis.dot(new_z_axis)
	edit_bone.roll -=angle * 2.0
	dot2=edit_bone.x_axis.dot(new_z_axis)
	if dot1 > dot2:
		edit_bone.roll +=angle * 2.0