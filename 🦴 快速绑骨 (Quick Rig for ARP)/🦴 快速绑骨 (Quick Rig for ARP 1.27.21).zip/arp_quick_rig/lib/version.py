import bpy,addon_utils
from bpy_extras import anim_utils
class ARP_blender_version:
	_string=bpy.app.version_string
	blender_v=bpy.app.version
	_float=blender_v[0]*100+blender_v[1]+blender_v[2]*0.01
blender_version=ARP_blender_version()
def get_quickrig_version():return 12646
def ver_int_to_str(version_int):return "1.26.46"
def get_prefs():return P()
def delete_fcurve(act,fc,slot_idx=0):
	if bpy.app.version >=(5,0,0):
		cb=anim_utils.action_ensure_channelbag_for_slot(act,act.slots[slot_idx])
		cb.fcurves.remove(fc)
	else:
		act.fcurves.remove(fc)
def create_fcurve(act,dp,slot_idx=0,fc_index=0,action_group=''):
	if bpy.app.version >=(5,0,0):
		if len(act.slots)==0:
			print("Warning,this action has not slots,cannot create fcurve:",act.name)
			return None
		cb=anim_utils.action_ensure_channelbag_for_slot(act,act.slots[slot_idx])
		return cb.fcurves.new(dp,index=fc_index,group_name=action_group)
	else:
		return act.fcurves.new(dp,index=fc_index,action_group=action_group)
def find_fcurve(act,dp,slot_idx=0,fc_index=0):
	if bpy.app.version >=(5,0,0):
		if len(act.slots)==0:
			print("Warning,this action has not slots,skipped:",act.name)
			return None
		cb=anim_utils.action_get_channelbag_for_slot(act,act.slots[slot_idx])
		if cb==None: return None
		return cb.fcurves.find(dp,index=fc_index)
	else:
		return act.fcurves.find(data_path=dp,index=fc_index)
def get_action_fcurves(act,slot_idx=0,as_list=True):
	if bpy.app.version >=(5,0,0):
		if len(act.slots)==0:
			print("Warning,this action has not slots,skipped:",act.name)
			return []
		cb=anim_utils.action_ensure_channelbag_for_slot(act,act.slots[slot_idx])
		if cb:
			if as_list:
				return [_fc for _fc in cb.fcurves if _fc !=None]
			else:
				return cb.fcurves
		else:
			print("No fcurves found in this slot:",slot_idx)
			return []
	else:
		return act.fcurves