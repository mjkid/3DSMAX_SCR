import bpy
def get_shape_key_index(shape_key_name,keyblocks):
	for skidx in range(0,len(keyblocks)):
		if keyblocks[skidx].name==shape_key_name:
			return skidx
	return None