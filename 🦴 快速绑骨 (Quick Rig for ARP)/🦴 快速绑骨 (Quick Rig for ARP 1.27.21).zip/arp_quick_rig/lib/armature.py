import bpy
from .version_arm_collec import *
def get_arm_col_idx(armature,name):
	for i,coll in enumerate(get_armature_collections(armature)):
		if coll.name==name:
			return i
'''
def sort_armature_collections(armature,only_collection=None):
	order={'Main':0, 'Secondary':1, 'Orphan Bones':2, 'Deform':3, 'Reference':4}
	for col_name in order:
		if only_collection:
			if only_collection !=col_name:
				continue
		col=armature.data.collections.get(col_name)
		cur_idx=get_arm_col_idx(armature,col_name)
		to_idx=order[col_name]
		armature.data.collections.move(cur_idx,to_idx)
'''
def sort_armature_collections(armature,only_collection=None):
	order={'Main':0, 'Secondary':1, 'Orphan Bones':2, 'Deform':3, 'Reference':4}
	for col_name in order:
		if only_collection:
			if only_collection !=col_name:
				continue
		cur_idx=get_arm_col_idx(armature,col_name)
		to_idx=order[col_name]
		col=get_armature_collections(armature).get(col_name)
		if col.parent:
			first_idx=1000000
			for _c in get_armature_collections(armature):
				if _c.parent==col.parent and _c.index < first_idx:
					first_idx=_c.index
			to_idx +=first_idx
		armature.data.collections.move(cur_idx,to_idx)
def is_bone_in_layer(bone_name,layer_type,idx=None):
	if bpy.app.version >=(4,0,0):
		if bpy.context.mode== 'EDIT_ARMATURE':
			in_collection=[ebone.name for ebone in bpy.context.active_object.data.edit_bones if layer_type in ebone.collections]
			return bone_name in in_collection
		else:
			return layer_type in bpy.context.active_object.data.bones.get(bone_name).collections
	else:
		if bpy.context.mode== 'EDIT_ARMATURE':
			return bpy.context.active_object.data.edit_bones.get(bone_name).layers[idx]
		else:
			return bpy.context.active_object.data.bones.get(bone_name).layers[idx]
def enable_layer(layer_type,idx=None):
	if bpy.app.version >=(4,0,0):
		col=get_armature_collections(bpy.context.active_object).get(layer_type)
		col.is_visible=True
	else:
		bpy.context.active_object.data.layers[idx]=True
def hide_layer(layer_type,idx=None):
	if bpy.app.version >=(4,0,0):
		col=bpy.context.active_object.data.collections.get(layer_type)
		col.is_visible=False
	else:
		bpy.context.active_object.data.layers[idx]=False
def set_bone_layer(bone,layer_type,idx=None,multi=False):
	if bpy.app.version >=(4,0,0):
		arma=bpy.context.active_object
		col=arma.data.collections.get(layer_type)
		if col==None:
			col=arma.data.collections.new(layer_type)
			col.is_visible=False
		if bpy.context.mode== 'EDIT_ARMATURE':
			col.assign(bone)
		else:
			col.assign(arma.data.bones[bone.name])
		if multi:
			return
		for col in arma.data.collections:
			if col.name !=layer_type:
				if bpy.context.mode== 'EDIT_ARMATURE':
					col.unassign(bone)
				else:
					col.unassign(arma.data.bones[bone.name])
	else:
		bone.layers[idx]=True
		if multi:
			return
		for i,lay in enumerate(bone.layers):
			if i !=idx:
				bone.layers[i]=False